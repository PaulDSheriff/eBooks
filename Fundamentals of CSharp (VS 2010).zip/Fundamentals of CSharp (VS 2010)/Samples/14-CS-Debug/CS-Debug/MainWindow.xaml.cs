﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows;
using System.Xml.Linq;

namespace CS_Debug
{
	public partial class MainWindow : Window
	{
		private Employee _EmpObject = new Employee();
		private bool _IsValueOk = true;
		private int _FieldValue = 10;

		public MainWindow()
		{
			InitializeComponent();
		}

		#region Locals Window
		private void btnLocalsWindow_Click(object sender, RoutedEventArgs e)
		{
			LocalsWindowSample();
		}

		private void LocalsWindowSample()
		{
			bool IsValueOk = false;
			char aChar = '\0';
			byte MyByte = 0;
			DateTime BeginDate = default(System.DateTime);
			DateTime StartTime = default(System.DateTime);
			short index = 0;
			int pk = 0;
			long pkLong = 0;
			float quantity = 0;

			Debugger.Break();
		}
		#endregion

		#region Autos Window
		private void btnAutosWindow_Click(object sender, RoutedEventArgs e)
		{
			AutosWindow();
		}

		public void AutosWindow()
		{
			bool IsValueOk = false;
			char aChar = '\0';
			byte MyByte = 0;
			DateTime BeginDate = default(System.DateTime);
			DateTime StartTime = default(System.DateTime);
			short index = 0;
			int pk = 0;
			long pkLong = 0;
			float quantity = 0;
			double amount = 0;
			decimal price = default(decimal);
			string name = null;

			aChar = Convert.ToChar("A");
			IsValueOk = true;
			MyByte = 1;
			BeginDate = Convert.ToDateTime("01/09/2011");
			StartTime = Convert.ToDateTime("01/01/0001");
			index = 10;
			pk = 100000;
			pkLong = 29393838383L;
			quantity = Convert.ToSingle(2.5);
			amount = 3.2233;
			price = Convert.ToDecimal(500.65);
			name = "Paul";

			Debugger.Break();
		}

		#endregion

		#region Call Stack Window
		private void btnCallStack_Click(object sender, RoutedEventArgs e)
		{
			FirstMethod();
		}

		private void FirstMethod()
		{
			SecondMethod();
		}

		private void SecondMethod()
		{
			ThirdMethod();
		}

		private void ThirdMethod()
		{
			FourthMethod();
		}

		private void FourthMethod()
		{
			FifthMethod();
		}

		private void FifthMethod()
		{
			// When you get here go to Debug | Windows | Call Stack to see how you got here.
			Debugger.Break();
		}
		#endregion

		#region Drag & Drop into Watch Window
		private void btnWatchWindow_Click(object sender, RoutedEventArgs e)
		{
			Debugger.Break();

			// Show drag & drop & changing values
			WatchvsImmediate();
		}
		#endregion

		#region Autos Window: Working with Classes
		private void btnWorkingWithClasses_Click(object sender, RoutedEventArgs e)
		{
			WorkingWithClasses();
		}

		private void WorkingWithClasses()
		{
			Employee emp = new Employee() { FirstName = "John", LastName = "Smith", id = 1 };

			// Drag & Drop Emp into Watch window
			Debugger.Break();
		}
		#endregion

		#region Watch vs Immediate Window
		private static int mNumber = 0;

		private void btnWatchVsImmediate_Click(object sender, RoutedEventArgs e)
		{
			Debugger.Break();

			WatchvsImmediate();
		}

		private void WatchvsImmediate()
		{
			mNumber = 1;
			MainWindow.IncrementNumber();
		}

		private static int IncrementNumber()
		{
			mNumber += 1;

			if (mNumber == 4)
				Console.WriteLine("mNumber = 4");

			return mNumber;
		}
		#endregion

		#region Command Window
		private void btnCommandWindow_Click(object sender, RoutedEventArgs e)
		{
			int index = 0;

			Debugger.Break();

			index += 1;
			// Open the Command Window and try entering some commands
			// For example: ? 1 + 3
			//              ? index
			//              index = 4;  // Sets the local variable
			//              ? index     // Will now print 4
		}
		#endregion

		#region Immediate Window
		private void btnImmediateWindow_Click(object sender, RoutedEventArgs e)
		{
			int index = 0;

			Debugger.Break();

			index += 1;
			// Open the Immediate Window and try entering some commands
			// For example: ? 1 + 3
			//              ? index
			//              index = 4;  // Sets the local variable
			//              ? index     // Will now print 4
		}
		#endregion

		#region Thread Window
		private void btnThreadWindow_Click(object sender, RoutedEventArgs e)
		{
			// Open the Threads Window
			Debugger.Break();
		}
		#endregion

		#region Modules Window
		private void btnModulesWindow_Click(object sender, RoutedEventArgs e)
		{
			// Open the Modules Window
			Debugger.Break();
		}
		#endregion



		#region ForLoop Breakpoints
		private void btnForLoopBreakPoints_Click(object sender, RoutedEventArgs e)
		{
			ForLoopBreaks();
		}

		private void ForLoopBreaks()
		{
			for (int index = 0; index < 10; index++)
			{
				Console.WriteLine("Loop index: " + index.ToString());
			}
		}
		#endregion

		#region Break at Function
		private void btnBreakAtFunction_Click(object sender, RoutedEventArgs e)
		{
			// Select Debug | New Breakpoint | Break at Function...
			BreakHereSample();
		}

		private void BreakHereSample()
		{
			MessageBox.Show("Hello");
		}

		private void BreakHere(string msg)
		{
			MessageBox.Show(msg);
		}

		private void BreakHere(string msg, string caption)
		{
			MessageBox.Show(msg, caption);
		}

		private void BreakHere(string msg, string caption, string writeMsg)
		{
			MessageBox.Show(msg, caption);
			Console.WriteLine(writeMsg);
		}
		#endregion

		#region Hit Count Sample
		private void btnHitCount_Click(object sender, RoutedEventArgs e)
		{
			HitCountSample();
		}

		private void HitCountSample()
		{
			// Set Hit count on index variable
			for (int index = 0; index < 10; index++)
			{
				Console.WriteLine("Loop index: " + index.ToString());
			}
		}
		#endregion

		#region Conditional Break Sample
		private void btnConditionalBreaks_Click(object sender, RoutedEventArgs e)
		{
			ConditionalBreakSample();
		}

		private void ConditionalBreakSample()
		{
			StringBuilder sb = new StringBuilder(1024);
			int lastId;

			var xElem = XElement.Load(GetEmployeeFile());

			// Get All Employees 
			var emps = from emp in xElem.Descendants("Employee")
								 select new Employee
								 {
									 id = Convert.ToInt32(emp.Element("id").Value),
									 FirstName = emp.Element("FirstName").Value,
									 LastName = emp.Element("LastName").Value
								 };

			// Break where emp.id==3
			foreach (Employee emp in emps)
			{
				lastId = emp.id;
				sb.AppendFormat("id={0}", emp.id.ToString());
				sb.AppendFormat(" - FirstName={0}", emp.FirstName);
				sb.AppendFormat(" - LastName={0}", emp.LastName);
				sb.Append(Environment.NewLine);
			}
		}
		#endregion

		#region Support Methods
		public static string GetCurrentDirectory()
		{
			string ret;

			ret = AppDomain.CurrentDomain.BaseDirectory;
			if (ret.IndexOf(@"\bin") > 0)
			{
				ret = ret.Substring(0, ret.LastIndexOf(@"\bin"));
			}

			return ret;
		}

		public static string GetEmployeeFile()
		{
			string strFile;

			strFile = GetCurrentDirectory();
			strFile += @"\XML\Employee.xml";

			return strFile;
		}
		#endregion

		#region Change Value Sample
		private void btnChangeValues_Click(object sender, RoutedEventArgs e)
		{
			ChangeValue();
		}

		private void ChangeValue()
		{
			// Set breakpoint and change index on the fly using the Immediate Window
			for (int index = 0; index < 10; index++)
			{
				Console.WriteLine("Loop index: " + index.ToString());
			}
		}
		#endregion

		#region Call Method Sample
		private void btnCallMethod_Click(object sender, RoutedEventArgs e)
		{
			CallMethodSample();
		}

		private void CallMethodSample()
		{
			Employee emp = new Employee() { FirstName = "John", LastName = "Smith", id = 1 };

			// Set a conditional breakpoint here by calling emp.IsValid() == false
			Console.WriteLine(emp.LastName);

			emp.LastName = string.Empty;

			// Set a conditional breakpoint here by calling emp.IsValid() == false
			Console.WriteLine(emp.LastName);
		}
		#endregion

		#region Tracepoint Sample
		private void btnTracePoints_Click(object sender, RoutedEventArgs e)
		{
			TracepointSample();
		}

		private void TracepointSample()
		{
			// Set Tracepoint
			for (int index = 0; index < 10; index++)
			{
				Console.WriteLine("Loop index: " + index.ToString());
			}
		}
		#endregion

		#region DataTips Sample
		private void btnDataTips_Click(object sender, RoutedEventArgs e)
		{
			DataTipsSample();
		}

		private void DataTipsSample()
		{
			var xElem = XElement.Load(GetEmployeeFile());

			Debugger.Break();
		}
		#endregion

		#region Set Next Statement
		private void btnSetNextStatement_Click(object sender, RoutedEventArgs e)
		{
			SetNextStatement();
		}

		private void SetNextStatement()
		{
			StringBuilder sb = new StringBuilder(1024);
			var xElem = XElement.Load(GetEmployeeFile());

			// Get All Employees 
			var emps = from emp in xElem.Descendants("Employee")
								 select new Employee
								 {
									 id = Convert.ToInt32(emp.Element("id").Value),
									 FirstName = emp.Element("FirstName").Value,
									 LastName = emp.Element("LastName").Value
								 };

			Debugger.Break();

			foreach (Employee emp in emps)
			{
				sb.AppendFormat("id={0}", emp.id.ToString());
				sb.AppendFormat(" - FirstName={0}", emp.FirstName);
				sb.AppendFormat(" - LastName={0}", emp.LastName);
				sb.Append(Environment.NewLine);
			}

			Console.WriteLine("Finished");
		}
		#endregion

		#region Debug Class
		private void btnDebugClass_Click(object sender, RoutedEventArgs e)
		{
			winDebugClass win = new winDebugClass();

			win.Show();
		}
		#endregion

		#region Trace Class
		private void btnTraceClass_Click(object sender, RoutedEventArgs e)
		{
			TraceSample();
		}

		private void TraceSample()
		{
			Trace.WriteLine("This is Trace 1");
			Trace.WriteLine("This is Trace 2");
		}
		#endregion

	}
}
