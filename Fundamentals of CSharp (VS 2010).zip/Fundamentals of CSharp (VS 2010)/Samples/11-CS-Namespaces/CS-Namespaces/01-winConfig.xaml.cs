﻿using System.Configuration;
using System.Windows;

namespace CS_Namespaces
{
	public partial class winConfig : Window
	{
		public winConfig()
		{
			InitializeComponent();
		}

		private void btnConfig_Click(object sender, RoutedEventArgs e)
		{
			txtStateCode.Text = ConfigurationManager.AppSettings["DefaultStateCode"];
			txtEmpType.Text = ConfigurationManager.AppSettings["DefaultEmployeeType"];
		}

		private void btnConnection_Click(object sender, RoutedEventArgs e)
		{
			txtSandbox.Text = ConfigurationManager.ConnectionStrings["Sandbox"].ConnectionString;
			txtNorthwind.Text = ConfigurationManager.ConnectionStrings["Northwind"].ConnectionString;
		}
	}
}
