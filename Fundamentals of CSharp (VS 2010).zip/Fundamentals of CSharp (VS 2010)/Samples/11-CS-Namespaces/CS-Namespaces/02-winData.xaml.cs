﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace CS_Namespaces
{
	public partial class winData : Window
	{
		public winData()
		{
			InitializeComponent();
		}

		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			txtConnectString.Text = ConfigurationManager.ConnectionStrings["Sandbox"].ConnectionString;
		}

		private void btnGetData_Click(object sender, RoutedEventArgs e)
		{
			GetData();
		}

		private void GetData()
		{
			DataTable dt = new DataTable();
			SqlDataAdapter da = null;

			da = new SqlDataAdapter("SELECT * FROM Product", txtConnectString.Text);

			da.Fill(dt);

			lstData.DataContext = dt;
		}
	}
}
