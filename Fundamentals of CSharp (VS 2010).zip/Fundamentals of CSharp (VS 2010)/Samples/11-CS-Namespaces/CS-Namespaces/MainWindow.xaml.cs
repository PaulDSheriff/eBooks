﻿using System.Windows;

namespace CS_Namespaces
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private void btnConfig_Click(System.Object sender, System.Windows.RoutedEventArgs e)
		{
			winConfig win = new winConfig();

			win.Show();
		}

		private void btnFile_Click(System.Object sender, System.Windows.RoutedEventArgs e)
		{
			winFile win = new winFile();

			win.Show();
		}

		private void btnData_Click(System.Object sender, System.Windows.RoutedEventArgs e)
		{
			winData win = new winData();

			win.Show();
		}
	}
}
