﻿using System;
using System.IO;
using System.Windows;

namespace CS_Namespaces
{
	public partial class winFile : Window
	{
		public winFile()
		{
			InitializeComponent();
		}

		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			txtFileName.Text = Environment.CurrentDirectory + @"\Test.txt";
			txtFolderName.Text = Environment.SystemDirectory;
		}

		private void btnWrite_Click(object sender, RoutedEventArgs e)
		{
			WriteFile();
		}

		private void WriteFile()
		{
			File.AppendAllText(txtFileName.Text, txtData.Text);
			MessageBox.Show("File Written.");
		}

		private void btnRead_Click(object sender, RoutedEventArgs e)
		{
			ReadFile();
		}

		private void ReadFile()
		{
			tbTextRead.Text = File.ReadAllText(txtFileName.Text);
		}

		private void btnGetFiles_Click(object sender, RoutedEventArgs e)
		{
			GetFilesFromFolder();
		}

		private void GetFilesFromFolder()
		{
			lstFiles.ItemsSource = Directory.GetFiles(txtFolderName.Text);
		}
	}
}
