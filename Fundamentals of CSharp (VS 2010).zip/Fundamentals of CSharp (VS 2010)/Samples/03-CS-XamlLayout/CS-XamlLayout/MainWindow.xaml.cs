﻿using System.Windows;

namespace CS_XamlLayout
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnGridMargins_Click(object sender, RoutedEventArgs e)
    {
      GridUsingMargins win = new GridUsingMargins();

      win.Show();
    }

    private void btnGridRowsColumns_Click(object sender, RoutedEventArgs e)
    {
      GridUsingRowsColumns win = new GridUsingRowsColumns();

      win.Show();
    }

    private void btnCanvas_Click(object sender, RoutedEventArgs e)
    {
      UsingCanvas win = new UsingCanvas();

      win.Show();
    }

    private void btnStackPanel_Click(object sender, RoutedEventArgs e)
    {
      UsingStackPanel win = new UsingStackPanel();

      win.Show();
    }
  }
}
