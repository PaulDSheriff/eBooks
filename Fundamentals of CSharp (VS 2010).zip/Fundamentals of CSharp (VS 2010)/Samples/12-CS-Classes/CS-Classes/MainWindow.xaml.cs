﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Classes
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private void btnDateThings_Click(object sender, RoutedEventArgs e)
		{
			winDate win = new winDate();

			win.Show();
		}

		private void btnLinq_Click(object sender, RoutedEventArgs e)
		{
			winLinq win = new winLinq();

			win.Show();
		}

		private void btnLinqToXml_Click(object sender, RoutedEventArgs e)
		{
			winXml win = new winXml();

			win.Show();
		}

		private void btnCollections_Click(object sender, RoutedEventArgs e)
		{
			winCollections win = new winCollections();

			win.Show();
		}
	}
}
