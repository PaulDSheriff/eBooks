﻿namespace CS_Classes
{
	public class Product
	{
		public int ProductId { get; set; }
		public string ProductName { get; set; }
		public string ProductType { get; set; }
		public decimal Price { get; set; }
		public string Image { get; set; }
		public bool IsOnSpecial { get; set; }
	}
}
