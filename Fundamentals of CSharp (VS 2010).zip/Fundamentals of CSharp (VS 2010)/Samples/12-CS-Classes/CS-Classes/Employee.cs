﻿
namespace CS_Classes
{
	public class Employee
	{
		public string FirstName { get; set; }
		public string LastName { get; set; }
	}
}
