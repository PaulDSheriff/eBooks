﻿using System.Windows;

namespace CS_WPF_UI
{
  /// <summary>
  /// Interaction logic for frmMain.xaml
  /// </summary>
  public partial class frmMain : Window
  {
    public frmMain()
    {
      InitializeComponent();
    }

    #region First Samples
    private void btnSample1_Click(object sender, RoutedEventArgs e)
    {
      frmSample1 frm = new frmSample1();

      frm.Show();
    }

    private void btnSample2_Click(object sender, RoutedEventArgs e)
    {
      frmSample2 frm = new frmSample2();

      frm.Show();
    }

    private void btnSample3_Click(object sender, RoutedEventArgs e)
    {
      frmSample3 frm = new frmSample3();

      frm.Show();
    }

    private void btnSample4_Click(object sender, RoutedEventArgs e)
    {
      frmSample4 frm = new frmSample4();

      frm.Show();
    }

    private void btnSample5_Click(object sender, RoutedEventArgs e)
    {
      frmSample5 frm = new frmSample5();

      frm.Show();
    }

    private void btnMarginPadding_Click(object sender, RoutedEventArgs e)
    {
      frmMarginPadding frm = new frmMarginPadding();

      frm.Show();
    }
    #endregion

    #region Input/Display Controls
    private void btnCheckBoxes_Click(object sender, RoutedEventArgs e)
    {
      frmCheckBoxes frm = new frmCheckBoxes();

      frm.Show();
    }

    private void btnRadioButtons_Click(object sender, RoutedEventArgs e)
    {
      frmRadioButtons frm = new frmRadioButtons();

      frm.Show();
    }

    private void btnPasswordBox_Click(object sender, RoutedEventArgs e)
    {
      frmPasswordBox frm = new frmPasswordBox();

      frm.Show();
    }

    private void btnMenus_Click(object sender, RoutedEventArgs e)
    {
      frmMenu frm = new frmMenu();

      frm.Show();
    }

    private void btnMedia_Click(object sender, RoutedEventArgs e)
    {
      frmMedia frm = new frmMedia();

      frm.Show();
    }

    private void btnTextBlock_Click(object sender, RoutedEventArgs e)
    {
      frmTextBlock frm = new frmTextBlock();

      frm.Show();
    }

    private void btnImage_Click(object sender, RoutedEventArgs e)
    {
      frmImage frm = new frmImage();

      frm.Show();
    }
    #endregion

    #region List Controls
    private void btnComboBox_Click(object sender, RoutedEventArgs e)
    {
      frmComboBoxes frm = new frmComboBoxes();

      frm.Show();
    }

    private void btnListBox_Click(object sender, RoutedEventArgs e)
    {
      frmListBox frm = new frmListBox();

      frm.Show();
    }

    private void btnListView_Click(object sender, RoutedEventArgs e)
    {
      frmListView frm = new frmListView();

      frm.Show();
    }
    #endregion

    #region Container Controls
    private void btnWrapPanel_Click(object sender, RoutedEventArgs e)
    {
      frmWrapPanel frm = new frmWrapPanel();

      frm.Show();
    }

    private void btnExpander_Click(object sender, RoutedEventArgs e)
    {
      frmExpander frm = new frmExpander();

      frm.Show();
    }

    private void btnUniformGrid_Click(object sender, RoutedEventArgs e)
    {
      frmUniformGrid frm = new frmUniformGrid();

      frm.Show();
    }

    private void btnGroupBox_Click(object sender, RoutedEventArgs e)
    {
      frmGroupBox frm = new frmGroupBox();

      frm.Show();
    }

       private void btnScrollViewer_Click(object sender, RoutedEventArgs e)
    {
      frmScrollViewer frm = new frmScrollViewer();

      frm.Show();
    }

    private void btnTabs_Click(object sender, RoutedEventArgs e)
    {
      frmTabs frm = new frmTabs();

      frm.Show();
    }

    private void btnBorder_Click(object sender, RoutedEventArgs e)
    {
      frmBorder frm = new frmBorder();

      frm.Show();
    }
    #endregion

    #region Styles & Resources
    private void btnStyle1_Click(object sender, RoutedEventArgs e)
    {
      frmStackPanelResource frm = new frmStackPanelResource();

      frm.Show();
    }

    private void btnStyle2_Click(object sender, RoutedEventArgs e)
    {
      frmWindowResource frm = new frmWindowResource();

      frm.Show();
    }
    #endregion
  }
}
