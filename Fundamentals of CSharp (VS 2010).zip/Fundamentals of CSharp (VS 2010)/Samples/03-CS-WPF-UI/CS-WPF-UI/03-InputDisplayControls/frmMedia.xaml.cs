﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CS_WPF_UI
{
  /// <summary>
  /// Interaction logic for frmMedia.xaml
  /// </summary>
  public partial class frmMedia : Window
  {
    private bool IsPaused = false;
    public frmMedia()
    {
      InitializeComponent();
    }

    private void btnPlay_Click(object sender, RoutedEventArgs e)
    {
      if (IsPaused == false)
      {
        medPlayer.Source = new Uri(txtMediaFile.Text);
        medPlayer.LoadedBehavior = MediaState.Manual;
      }
      IsPaused = false;
      medPlayer.Play();
    }

    private void btnPause_Click(object sender, RoutedEventArgs e)
    {
      IsPaused = true;
      medPlayer.Pause();
    }
  }
}

/* VB.NET CODE
  Private IsPaused As Boolean = False

  Private Sub btnPlay_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnPlay.Click
    If IsPaused = False Then
      medPlayer.Source = New Uri(txtMediaFile.Text)
      medPlayer.LoadedBehavior = MediaState.Manual
    End If

    IsPaused = False
    medPlayer.Play()
  End Sub

  Private Sub btnPause_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnPause.Click
    IsPaused = True
    medPlayer.Pause()
  End Sub

*/