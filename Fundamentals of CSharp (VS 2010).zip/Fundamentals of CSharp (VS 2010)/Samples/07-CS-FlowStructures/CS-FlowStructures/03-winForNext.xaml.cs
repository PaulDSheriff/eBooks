﻿using System.Diagnostics;
using System.Windows;

namespace CS_FlowStructures
{
	/// <summary>
	/// Interaction logic for winForNext.xaml
	/// </summary>
	public partial class winForNext : Window
	{
		public winForNext()
		{
			InitializeComponent();
		}

		private void btnForNext_Click(object sender, RoutedEventArgs e)
		{
			ForNext();
		}

		private void ForNext()
		{
			int intLoop = 0;

			for (intLoop = 0; intLoop <= 10; intLoop++)
			{
				Debug.WriteLine(intLoop);
			}
		}

		private void btnForNext2_Click(object sender, RoutedEventArgs e)
		{
			ForNext2();
		}

		private void ForNext2()
		{
			int intLoop = 0;

			for (intLoop = 0; intLoop <= 20; intLoop += 2)
			{
				Debug.WriteLine(intLoop);
			}
		}

		private void btnForNextMinus_Click(object sender, RoutedEventArgs e)
		{
			ForNextMinus();
		}

		private void ForNextMinus()
		{
			int intLoop = 0;

			for (intLoop = 50; intLoop >= 0; intLoop -= 5)
			{
				Debug.WriteLine(intLoop);
			}
		}

		private void btnForEach_Click(object sender, RoutedEventArgs e)
		{
			ForEach();
		}

private void ForEach()
{
	Employees list = new Employees();
	Employee emp = default(Employee);

	emp = new Employee();
	emp.FirstName = "Paul";
	emp.LastName = "Sheriff";

	list.Add(emp);

	emp = new Employee();
	emp.FirstName = "Ken";
	emp.LastName = "Getz";

	list.Add(emp);

	emp = new Employee();
	emp.FirstName = "Bill";
	emp.LastName = "Gates";

	list.Add(emp);

	foreach (Employee item in list)
	{
		Debug.WriteLine(item.FirstName);
	}
}
	}
}
