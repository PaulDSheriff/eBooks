﻿
namespace CS_FlowStructures
{
	public class Employee
	{
		public string FirstName { get; set; }
		public string LastName { get; set; }
	}
}
