﻿using System.Collections.Generic;

namespace CS_FlowStructures
{
	public class Employees : List<Employee>
	{
	}
}
