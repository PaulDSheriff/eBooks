﻿#define CON_LANGUAGE

using System;
using System.Windows;

namespace CS_FlowStructures
{
	public partial class winDecision : Window
	{
		public winDecision()
		{
			InitializeComponent();
		}

		private void DisplayMessage(string msg)
		{
			tbMessage.Text = msg;
		}

		private void btnSingleLineIf_Click(object sender, RoutedEventArgs e)
		{
			SingeLineIf();
		}

		private void SingeLineIf()
		{
			if (string.IsNullOrEmpty(txtLastName.Text)) DisplayMessage("Last Name Must Be Filled in");
		}

		private void btnNormalIf_Click(object sender, RoutedEventArgs e)
		{
			NormalIf();
		}

		private void NormalIf()
		{
			if (string.IsNullOrEmpty(txtLastName.Text))
			{
				DisplayMessage("Last Name Must Be Filled in");
			}
		}

		private void btnElse_Click(object sender, RoutedEventArgs e)
		{
			ElseIfSample();
		}

		private void ElseIfSample()
		{
			if (string.IsNullOrEmpty(txtLastName.Text))
			{
				DisplayMessage("Last Name Must Be Filled in");
			}
			else
			{
				DisplayMessage("Thank you for a Last Name");
			}
		}

		private void btnElseIf_Click(object sender, RoutedEventArgs e)
		{
			ElseIfElse();
		}

		private void ElseIfElse()
		{
			if (txtLastName.Text == "Sheriff")
			{
				DisplayMessage("Hello Paul");
			}
			else if (txtLastName.Text == "Getz")
			{
				DisplayMessage("Hello Ken");
			}
			else if (txtLastName.Text == "Gates")
			{
				DisplayMessage("Hello Bill");
			}
		}

		private void btnConditionalOperator_Click(object sender, RoutedEventArgs e)
		{
			ConditionalOperatorSample();
		}

		private void ConditionalOperatorSample()
		{
			DisplayMessage(Convert.ToString((txtLastName.Text == "Gates" ? "Hello Bill" : "Hello Whoever")));
		}

		private void btnSwitch_Click(object sender, RoutedEventArgs e)
		{
			SwitchSample();
		}

		private void SwitchSample()
		{
			switch (txtLastName.Text)
			{
				case "Sheriff":
					DisplayMessage("Hello Paul");
					break;
				case "Getz":
					DisplayMessage("Hello Ken");
					break;
				case "Gates":
					DisplayMessage("Hello Bill");
					break;
				default:
					DisplayMessage("Hello Whoever");
					break;
			}
		}

		private void btnSwitchMultiple_Click(object sender, RoutedEventArgs e)
		{
			SwitchMultipleSample();
		}

		private void SwitchMultipleSample()
		{
			switch (txtLastName.Text)
			{
				case "Sheriff":
				case "Getz":
				case "Gates":
					DisplayMessage("Hello " + txtLastName.Text);
					break;
				default:
					DisplayMessage("Hello Whoever");
					break;
			}
		}

		private void btnConditionalCompile_Click(object sender, RoutedEventArgs e)
		{
			ConditionalCompile();
		}

#if DEBUG
		private void ConditionalCompile()
		{
			DisplayMessage("We have compiled to Debug mode");
#else
	    DisplayMessage("We have compiled to Release mode");
#endif
		}


		private void btnLanguage_Click(object sender, RoutedEventArgs e)
		{
			LanguageExample();
		}

		private void LanguageExample()
		{
			// Defined at top of the file
#if CON_LANGUAGE
			DisplayMessage("Good Morning, Mr. Gates");
#else
			DisplayMessage("Guten Morgen, Herr Gates");
#endif
		}
	}
}
