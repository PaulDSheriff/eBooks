﻿using System.Diagnostics;
using System.Windows;

namespace CS_FlowStructures
{
	public partial class winDoLoops : Window
	{
		public winDoLoops()
		{
			InitializeComponent();
		}

		private void btnWhile_Click(object sender, RoutedEventArgs e)
		{
			WhileSample();
		}

		private void WhileSample()
		{
			int index = 0;

			while (index < 10)
			{
				index += 1;

				Debug.WriteLine(index);
			}
		}

		private void btnDoWhile_Click(object sender, RoutedEventArgs e)
		{
			DoWhileSample();
		}

		private void DoWhileSample()
		{
			int index = 0;

			do
			{
				index += 1;

				Debug.WriteLine(index);
			} while (index < 10);
		}
	}
}
