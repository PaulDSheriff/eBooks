﻿using System.Windows;

namespace CS_FlowStructures
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private void btnDecision_Click(object sender, RoutedEventArgs e)
		{
			winDecision win = new winDecision();

			win.Show();
		}

		private void btnDoLoops_Click(object sender, RoutedEventArgs e)
		{
			winDoLoops win = new winDoLoops();

			win.Show();
		}

		private void btnForNext_Click(object sender, RoutedEventArgs e)
		{
			winForNext win = new winForNext();

			win.Show();
		}
	}
}
