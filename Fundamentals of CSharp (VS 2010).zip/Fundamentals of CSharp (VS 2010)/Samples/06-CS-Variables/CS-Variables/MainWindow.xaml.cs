﻿using System;
using System.Diagnostics;
using System.Windows;

namespace CS_Variables
{
	public partial class MainWindow : Window
	{
		private string mName = "Paul";

		public MainWindow()
		{
			InitializeComponent();
		}

		private void btnDeclarations_Click(object sender, RoutedEventArgs e)
		{
      Debugger.Break();

      // Step into the following to see the code
			VariableDeclaration();
      VariableDeclarationAssign();
		}

		public void VariableDeclaration()
		{
			bool IsValueOk = false;
			char aChar = '\0';
			byte MyByte = 0;
			DateTime BeginDate = default(System.DateTime);
			DateTime StartTime = default(System.DateTime);
			short index = 0;
			int pk = 0;
			long pkLong = 0;
			float quantity = 0;
			double amount = 0;
			decimal price = default(decimal);
			string name = null;

			aChar = Convert.ToChar("A");
			IsValueOk = true;
			MyByte = 1;
			BeginDate = Convert.ToDateTime("01/09/2011");
			StartTime = Convert.ToDateTime("01/01/0001");
			index = 10;
			pk = 100000;
			pkLong = 29393838383L;
			quantity = Convert.ToSingle(2.5);
			amount = 3.2233;
			price = Convert.ToDecimal(500.65);
			name = "Paul";
		}

		public void VariableDeclarationAssign()
		{
			bool IsValueOk = true;
			char aChar = 'a';
			byte MyByte = 1;
			DateTime BeginDate = DateTime.Parse("1/1/2008");
			DateTime StartTime = DateTime.Parse("11:00:00 AM");
			short index = 10;
			int pk = 100;
			long pkLong = 2000;
			float quantity = 10.3F;
			double amount = 100.00D;
			decimal price = 2.5m;
			string name = "Bruce";
		}

		private void btnProcedureScope_Click(object sender, RoutedEventArgs e)
		{
      Debugger.Break();

      // Step into the following to see the code
      ProcedureScope();
		}

		private void ProcedureScope()
		{
			int index = 0;

			for (index = 0; index <= 10; index++)
			{
				Debug.WriteLine(index);
			}

			// You can still see intLoop
			Debug.WriteLine(index);
		}

		private void btnBlockScope_Click(object sender, RoutedEventArgs e)
		{
      Debugger.Break();

      // Step into the following to see the code
      BlockScope();
		}

		private void BlockScope()
		{
			if (true)
			{
				int index = 0;

				for (index = 0; index <= 10; index++)
				{
					Debug.WriteLine(index);
				}
			}

			// index is not visible, the following will not compile
			// Debug.WriteLine(index)
		}

		private void btnMemberScope_Click(object sender, RoutedEventArgs e)
		{
      Debugger.Break();

      // Step into the following to see the code
      MemberExample();
		}

		private void MemberExample()
		{
			Debug.WriteLine(mName);

			mName = "John";

			Debug.WriteLine(mName);
		}

		private void btnObject_Click(object sender, RoutedEventArgs e)
		{
      Debugger.Break();

      // Step into the following to see the code
      ObjectExample();
		}

		private void ObjectExample()
		{
			object value = null;

			value = 10;

			Debug.WriteLine(value);

			value = "Hi There";
			Debug.WriteLine(value);
		}
	}
}
