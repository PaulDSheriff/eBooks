﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_Variables
{
	public class Employee
	{
		private string _FirstName;
		private string _LastName;
		private string _FullName;

		private void CreateFullName()
		{
			_FullName = _FirstName + " " + _LastName;
		}
	}
}
