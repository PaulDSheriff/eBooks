﻿using System;
// StringBuilder is in the System.Text namespace
using System.Text;
using System.Windows;

namespace CS_StringBuilder
{
	public partial class MainWindow : Window
	{
		private StringBuilder msb;

		public MainWindow()
		{
			InitializeComponent();
		}

		private void DisplayMessage(string msg)
		{
			tbMessage.Text = msg;
		}

		private void btnCreate_Click(object sender, RoutedEventArgs e)
		{
			CreateSample(txtSentence.Text);
		}

		private void CreateSample(string value)
		{
			// Create string and put in initial value
			msb = new StringBuilder(value);

			DisplayMessage(msb.ToString());
		}

		private void btnCreate2_Click(object sender, RoutedEventArgs e)
		{
			CreateSample2(txtSentence.Text);
		}

		private void CreateSample2(string value)
		{
			// Allocate 100 bytes of storage to start
			msb = new StringBuilder(value, 100);

			DisplayMessage(msb.ToString());
		}

		private void btnCreate3_Click(object sender, RoutedEventArgs e)
		{
			CreateSample3();
		}

		private void CreateSample3()
		{
			// Allocate 100 bytes of storage to start and 200 maximum
			msb = new StringBuilder(100, 200);

			DisplayMessage(msb.ToString());
		}

		private void btnAppend_Click(object sender, RoutedEventArgs e)
		{
			AppendSample(txtSentence.Text);
		}

		private void AppendSample(string value)
		{
			msb = new StringBuilder();

			msb.Append(value);

			DisplayMessage(msb.ToString());
		}

		private void btnCapacity_Click(object sender, RoutedEventArgs e)
		{
			CapacitySample(txtSentence.Text);
		}

		private void CapacitySample(string value)
		{
			msb = new StringBuilder(value);

			msb.Append(Environment.NewLine);
			msb.Append("Length is: " + msb.Length.ToString());
			msb.Append(Environment.NewLine);
			msb.Append("Capacity is: " + msb.Capacity.ToString());
			msb.Append(Environment.NewLine);
			msb.Append("Maximum Capacity is: " + msb.MaxCapacity.ToString());

			DisplayMessage(msb.ToString());
		}

		private void btnAppendFormat_Click(object sender, RoutedEventArgs e)
		{
			AppendFormatSample(txtSentence.Text);
		}

		private void AppendFormatSample(string value)
		{
			msb = new StringBuilder(value);

			msb.Append(Environment.NewLine);
			msb.AppendFormat("{0}: {1}", "Capacity is", msb.Capacity);
			msb.Append(Environment.NewLine);
			msb.AppendFormat("{0}: {1}", "Length is", msb.Length);

			DisplayMessage(msb.ToString());
		}

		private void btnChars_Click(object sender, RoutedEventArgs e)
		{
			CharsSample(txtSentence.Text);
		}

		private void CharsSample(string value)
		{
			msb = new StringBuilder(value);

			// Change some individual characters
			msb[0] = Convert.ToChar(",");
			msb[10] = Convert.ToChar(".");

			DisplayMessage(msb.ToString());
		}

		private void btnInsert_Click(object sender, RoutedEventArgs e)
		{
			InsertSample(txtSentence.Text);
		}

		private void InsertSample(string value)
		{
			msb = new StringBuilder(value);

			msb.Insert(0, "PREFIXED: ");

			DisplayMessage(msb.ToString());
		}

		private void btnRemove_Click(object sender, RoutedEventArgs e)
		{
			RemoveSample(txtSentence.Text);
		}

		private void RemoveSample(string value)
		{
			msb = new StringBuilder(value);

			msb.Remove(0, 10);

			DisplayMessage(msb.ToString());
		}

		private void btnReplace_Click(object sender, RoutedEventArgs e)
		{
			ReplaceSample(txtSentence.Text);
		}

		private void ReplaceSample(string value)
		{
			msb = new StringBuilder(value);

			// Change some values
			msb.Replace(".", ".PERIOD.");
			msb.Replace("This ", "Changed ");

			DisplayMessage(msb.ToString());
		}
	}
}
