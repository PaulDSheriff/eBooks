﻿using System;
using System.IO;
using System.Security;
using System.Text;
using System.Windows;

namespace CS_Exceptions
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		#region Display Message Methods
		private void DisplayMessage(string msg)
		{
			tbMessage.Text = msg;
		}

		private void DisplayMessage(Exception ex)
		{
			StringBuilder sb = new StringBuilder();

			sb.Append("Data: " + ex.Data + Environment.NewLine);
			sb.Append("HelpLink: " + ex.HelpLink + Environment.NewLine);
			sb.Append("Message: " + ex.Message + Environment.NewLine);
			sb.Append("Source: " + ex.Source + Environment.NewLine);
			sb.Append("StackTrace: " + ex.StackTrace + Environment.NewLine);
			sb.Append("TargetSite: " + ex.TargetSite + Environment.NewLine);

			tbMessage.Text = sb.ToString();
		}
		#endregion

		#region No Exception Handling
		private void btnNoHandling_Click(object sender, RoutedEventArgs e)
		{
			NoExceptionHandling();
		}

		private void NoExceptionHandling()
		{
			long fileSize;
			FileStream fs;

			// No error handling? If there's an error, 
			// you just get an unhandled exception.    
			fs = File.Open(txtFileName.Text, FileMode.Open);
			fileSize = fs.Length;
			fs.Close();
		}
		#endregion

		#region Simple Catch
		private void btnCatch_Click(object sender, RoutedEventArgs e)
		{
			SimpleCatch();
		}

		private void SimpleCatch()
		{
			long fileSize;
			FileStream fs;

			// This is better, but not much. You
			// don't really have any idea what 
			// went wrong!
			try
			{
				fs = File.Open(txtFileName.Text, FileMode.Open);
				fileSize = fs.Length;
				fs.Close();
			}
			catch
			{
				DisplayMessage("Error occurred!");
			}
		}
		#endregion

		#region Simple Exception
		private void btnSimple_Click(object sender, RoutedEventArgs e)
		{
			SimpleException();
		}

		private void SimpleException()
		{
			long fileSize;
			FileStream fs;

			// Display the entire contents of the Exception object.
			try
			{
				fs = File.Open(txtFileName.Text, FileMode.Open);
				fileSize = fs.Length;
				fs.Close();
			}
			catch (Exception ex)
			{
				// DisplayMessage(ex.ToString();
				DisplayMessage(ex.Message);
			}
		}
		#endregion

		#region Display Exception Properties
		private void btnProperties_Click(object sender, RoutedEventArgs e)
		{
			DisplayExceptionProperties();
		}

		private void DisplayExceptionProperties()
		{
			long fileSize;
			FileStream fs;

			// Display the entire contents of the Exception object.
			try
			{
				fs = File.Open(txtFileName.Text, FileMode.Open);
				fileSize = fs.Length;
				fs.Close();
			}
			catch (Exception ex)
			{
				DisplayMessage(ex);
			}
		}
		#endregion

		#region Exception Bubbling
		private void btnBubbling_Click(object sender, RoutedEventArgs e)
		{
			ExceptionBubbling();
		}

		private void ExceptionBubbling()
		{
			// What happens to unhandled errors?
			try
			{
				MethodOne();
			}
			catch
			{
				DisplayMessage("An error bubbled up from lower level procedure!");
			}
		}

		private void MethodOne()
		{
			MethodTwo();
		}

		private void MethodTwo()
		{
			MethodThree();
		}

		private void MethodThree()
		{
			long fileSize;
			FileStream fs;

			// No error handling here!
			fs = File.Open(txtFileName.Text, FileMode.Open);
			fileSize = fs.Length;
			fs.Close();
		}
		#endregion

		#region Finally Block
		private void btnFinally_Click(object sender, RoutedEventArgs e)
		{
			TestFinally();
		}

		private void TestFinally()
		{
			long fileSize;
			FileStream fs = null;

			try
			{
				fs = File.Open(txtFileName.Text, FileMode.Open);
				fileSize = fs.Length;
			}
			catch (Exception ex)
			{
				DisplayMessage(ex.Message);
			}
			finally
			{
				// Close the file here
				if (fs != null)
					fs.Close();
			}
		}
		#endregion

		#region Multiple Catch Blocks
		private void btnMultiple_Click(object sender, RoutedEventArgs e)
		{
			MultipleExceptions();
		}

		private void MultipleExceptions()
		{
			long fileSize;
			FileStream fs = null;

			// Use the most specific exception that you can.
			// To test this, change the file name to be:

			// 1.) In a good location, but the file doesn't exist.
			// 2.) On a drive that doesn't exist.
			// 3.) In a path that doesn't exist.
			// 4.) On a drive that isn't ready.

			try
			{
				fs = File.Open(txtFileName.Text, FileMode.Open);
				fileSize = fs.Length;

				// The code will match against the most specific error
				// it can. Both FileNotFoundException and 
				// DirectoryNotFoundException inherit from 
				// IOException, and the code will use those first. 
				// If they weren't here, the code would always fall 
				// into(IOException) for those errors.        
			}
			catch (ArgumentNullException ex)
			{
				DisplayMessage("You passed in a Null argument." + ex.Message);
			}
			catch (ArgumentException ex)
			{
				DisplayMessage(
					"You specified an invalid filename. " +
					"Make sure you enter something besides spaces." + ex.Message);
			}
			catch (FileNotFoundException ex)
			{
				DisplayMessage(
					"The file you specified can't be found. " +
					"Please try again." + ex.Message);
			}
			catch (UnauthorizedAccessException ex)
			{
				DisplayMessage(
					"You specified a folder name, not a file name." + ex.Message);
			}
			catch (DirectoryNotFoundException ex)
			{
				DisplayMessage(
				"You specified a folder that doesn't exist " +
					"or can't be found." + ex.Message);
			}
			catch (SecurityException ex)
			{
				DisplayMessage("You don't have sufficient rights " +
					"to open the selected file." + ex.Message);
			}
			catch (IOException ex)
			{
				// A generic exception handler, for any IO error
				// that hasn't been caught yet. Here, it ought
				// to just be that the drive isn't ready.
				DisplayMessage("The drive you selected is not ready. " +
					"Make sure the drive contains valid media." + ex.Message);
			}
			catch (Exception ex)
			{
				DisplayMessage("An unknown error occurred." + ex.Message);
			}
			finally
			{
				// Close the file here
				if (fs != null)
					fs.Close();
			}
		}
		#endregion

		#region Throw Exception
		private void btnThrow_Click(object sender, RoutedEventArgs e)
		{
			ThrowException();
		}

		private void ThrowException()
		{
			// Catch an exception thrown by the called procedure.
			try
			{
				TestThrow();
			}
			catch (FileNotFoundException ex)
			{
				DisplayMessage("Error occurred: " + ex.Message);
				// Use ex.InnerException to get to error
				// that triggered this one.

				try
				{
					DisplayMessage(ex.InnerException.Message);
				}
				catch
				{
					// DO nothing at all!
				}
			}
			catch (Exception ex)
			{
				DisplayMessage(ex.Message);
			}
		}

		private void TestThrow()
		{
			long fileSize;
			FileStream fs = null;

			// No matter what happens, throw back 
			// a File Not Found exception.
			try
			{
				fs = File.Open(txtFileName.Text, FileMode.Open);
				fileSize = fs.Length;
			}
			catch (Exception ex)
			{
				throw new
					FileNotFoundException("Unable to open the specified file.", ex);
			}
			finally
			{
				// Close the file here
				if (fs != null)
					fs.Close();
			}
		}
		#endregion

		#region Custom Exception
		private void btnCustom_Click(object sender, RoutedEventArgs e)
		{
			CustomException();
		}

		public void CustomException()
		{
			long fileSize = 0;
			FileStream fs = null;

			try
			{
				fs = File.Open(txtFileName.Text, FileMode.Open, FileAccess.Read);
				fileSize = fs.Length;
				if (fileSize > 100)
				{
					//  Pass back the new exception. There's no
					// inner exception to pass back, so pass null
					throw (new FileTooLargeException(
						"The file you selected is too large.",
						null, fileSize));
				}
			}
			catch (Exception ex)
			{
				DisplayMessage(ex.ToString());
			}
			finally
			{
				// Run this code no matter what happens.
				if (fs != null)
					fs.Close();   // Close file here
			}
		}
		#endregion

		#region Global Exception Handling
		private void btnGlobal_Click(object sender, RoutedEventArgs e)
		{
			GlobalExceptionHandling();
		}

		private void GlobalExceptionHandling()
		{
			// NOTE: In order to test the Global Exception Handling
			// you need to go into Tools | Options | Debugging | General
			// and turn off the "Enable Just My Code".
			(Application.Current as App).TurnOnGlobalExceptionHandling = true;

			NoExceptionHandling();
		}
		#endregion
	}
}
