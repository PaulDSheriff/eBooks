﻿using System;
using System.Text;

namespace CS_Exceptions
{
	public class FileTooLargeException : Exception
	{
		public string ClassName { get; set; }
		public string MethodName { get; set; }
		public long FileSize { get; set; }

		public FileTooLargeException(string message)
			: base(message)
		{
		}

		public FileTooLargeException(string message,
					Exception innerException)
			: base(message, innerException)
		{
		}

		public FileTooLargeException(string message,
					Exception innerException, long size)
			: base(message, innerException)
		{
			FileSize = size;
		}

		public override string ToString()
		{
			StringBuilder sb = new StringBuilder(256);

			sb.Append("Class Name: " + ClassName + Environment.NewLine);
			sb.Append("Method Name: " + MethodName + Environment.NewLine);
			sb.Append("File Size: " + FileSize.ToString() + Environment.NewLine);

			return sb.ToString();
		}
	}
}
