﻿using System.Windows;

namespace CS_MessageBox
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private void btnSimple_Click(object sender, RoutedEventArgs e)
		{
			MessageBox.Show("Do you want to quit?");
		}

		private void btnWithTitle_Click(object sender, RoutedEventArgs e)
		{
			MessageBox.Show("Do you want to quit?", "MessageBox Sample");
		}

		private void btnWithButtons_Click(object sender, RoutedEventArgs e)
		{
			MessageBox.Show("Do you want to quit?", "MessageBox Sample",
				MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.Yes);
		}

		private void btnWithResult_Click(object sender, RoutedEventArgs e)
		{
			MessageBoxResult dr = default(MessageBoxResult);

			dr = MessageBox.Show("Do you want to quit?", "MessageBox Sample", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.Yes);

			switch (dr)
			{
				case MessageBoxResult.Yes:
					this.Close();

					break;
				case MessageBoxResult.No:
					break;
				// Do Nothing at all

			}
		}
	}
}
