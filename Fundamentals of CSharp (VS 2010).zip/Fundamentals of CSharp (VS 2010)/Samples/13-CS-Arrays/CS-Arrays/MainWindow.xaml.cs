﻿using System.Windows;

namespace CS_Arrays
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private void btnUsingArrays_Click(object sender, RoutedEventArgs e)
		{
			winUsingArrays win = new winUsingArrays();

			win.Show();
		}

		private void btnCreatingArrays_Click(object sender, RoutedEventArgs e)
		{
			winCreatingArrays win = new winCreatingArrays();

			win.Show();
		}

		private void btnConstants_Click(object sender, RoutedEventArgs e)
		{
			winConstants win = new winConstants();

			win.Show();
		}
	}
}
