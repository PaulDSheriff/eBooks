﻿using System;
using System.Diagnostics;
using System.Windows;

namespace CS_Arrays
{
	public partial class winCreatingArrays : Window
	{
		public winCreatingArrays()
		{
			InitializeComponent();
		}

		private void btnFixedSize_Click(object sender, RoutedEventArgs e)
		{
			FixedArray();
		}

		private void FixedArray()
		{
			string[] names = new string[3];

			names[0] = "Ken";
			names[1] = "Paul";
			names[2] = "Michael";

			foreach (string name in names)
			{
				Debug.WriteLine(name);
			}
		}


		private void btnDynamic_Click(object sender, RoutedEventArgs e)
		{

		}

		private void DynamicArrays()
		{
			int[] values;

			// Dynamically create 3 elements
			values = new int[3];

			values[0] = 10;
			values[1] = 20;
			values[2] = 30;

			foreach (int value in values)
			{
				Debug.WriteLine(string.Format("value={0}", value));
			}
		}

		private void btnInitializing_Click(object sender, RoutedEventArgs e)
		{
			InitArray();
		}

		private void InitArray()
		{
			int[] values = { 10, 20, 30, 40 };

			foreach (int value in values)
			{
				Debug.WriteLine(string.Format("value={0}", value));
			}
		}

		private void btnReferences_Click(object sender, RoutedEventArgs e)
		{
			ArrayRef();
		}

		private void ArrayRef()
		{
			int[] values = new int[3];
			int[] newValues;

			values[0] = 10;
			values[1] = 20;
			values[2] = 30;

			newValues = values;

			newValues[0] = 50;

			foreach (int value in values)
			{
				Debug.WriteLine(string.Format("value={0}", value));
			}

			foreach (int value in newValues)
			{
				Debug.WriteLine(string.Format("value={0}", value));
			}
		}

		private void btnCopying_Click(object sender, RoutedEventArgs e)
		{
			CopyArray();
		}

		private void CopyArray()
		{
			int[] values = new int[3];
			int[] newValues;

			values[0] = 10;
			values[1] = 20;
			values[2] = 30;

			newValues = new int[values.Length];

			Array.Copy(values, newValues, values.Length);

			newValues[0] = 50;

			foreach (int value in values)
			{
				Debug.WriteLine(string.Format("value={0}", value));
			}

			foreach (int value in newValues)
			{
				Debug.WriteLine(string.Format("new value={0}", value));
			}
		}

		private void btnCloning_Click(object sender, RoutedEventArgs e)
		{
			CloneArray();
		}

		private void CloneArray()
		{
			int[] values = new int[3];
			int[] newValues;

			values[0] = 10;
			values[1] = 20;
			values[2] = 30;

			// Need to cast because Clone returns an object array
			newValues = ((int[])(values.Clone()));

			newValues[0] = 50;

			foreach (int value in values)
			{
				Debug.WriteLine(string.Format("values={0}", value));
			}

			foreach (int value in newValues)
			{
				Debug.WriteLine(string.Format("new value={0}", value));
			}
		}

		private void btnPassing_Click(object sender, RoutedEventArgs e)
		{
			ArrayPrintExample();
		}

		private void ArrayPrintExample()
		{
			string[] names = new string[3];

			names[0] = "Ken";
			names[1] = "Paul";
			names[2] = "Michael";

			ArrayWrite(names, "names");
		}

		private void ArrayWrite(object[] values, string arrayName)
		{
			int index;

			for (index = 0; index <= values.Length - 1; index++)
			{
				Debug.WriteLine(string.Format("{0}({1})={2}", arrayName, index, values[index]));
			}
		}

		private void btnSorting_Click(object sender, RoutedEventArgs e)
		{
			SortExample();
		}

		private void SortExample()
		{
			string[] names = new string[3];

			names[0] = "Ken";
			names[1] = "Paul";
			names[2] = "Michael";

			Array.Sort(names);

			ArrayWrite(names, "names");
		}

		private void btnSearching_Click(object sender, RoutedEventArgs e)
		{
			SearchExample();
		}

		private void SearchExample()
		{
			string[] names = new string[3];
			int index;

			names[0] = "Ken";
			names[1] = "Paul";
			names[2] = "Michael";

			index = Array.IndexOf(names, "Paul");

			MessageBox.Show("Found at position: " + index.ToString());
		}

		private void btnMultiDimensional_Click(object sender, RoutedEventArgs e)
		{
			MultiDimArray();
		}

		private void MultiDimArray()
		{
			decimal[,] sales = new decimal[3, 3];

			sales[0, 0] = 1;
			sales[0, 1] = 50000;

			sales[1, 0] = 2;
			sales[1, 1] = 55000;

			sales[2, 0] = 3;
			sales[2, 1] = 60000;

			Debug.WriteLine(string.Format("January Sales: {0}", sales[0, 1]));

			Debug.WriteLine(string.Format("February Sales: {0}", sales[1, 1]));
		}
	}
}
