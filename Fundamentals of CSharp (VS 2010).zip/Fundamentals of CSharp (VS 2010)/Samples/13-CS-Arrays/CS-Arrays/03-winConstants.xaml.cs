﻿using System.Diagnostics;
using System.Windows;

namespace CS_Arrays
{
	public partial class winConstants : Window
	{
		private const int SECRET_VALUE = 42;

		public winConstants()
		{
			InitializeComponent();
		}

		private void btnLocal_Click(object sender, RoutedEventArgs e)
		{
			Constants();
		}

		private void Constants()
		{
			decimal[,] sales = new decimal[3, 3];
			const int MONTH = 0;
			const int SALES = 1;

			sales[0, MONTH] = 1;
			sales[0, SALES] = 50000;

			sales[1, MONTH] = 2;
			sales[1, SALES] = 55000;

			sales[2, MONTH] = 3;
			sales[2, SALES] = 60000;

			Debug.WriteLine(string.Format("January Sales: {0}", sales[0, SALES]));

			Debug.WriteLine(string.Format("February Sales: {0}", sales[1, SALES]));
		}

		private void btnMember_Click(object sender, RoutedEventArgs e)
		{
			MessageBox.Show("The Secret Value is: " + SECRET_VALUE.ToString());
		}
	}
}
