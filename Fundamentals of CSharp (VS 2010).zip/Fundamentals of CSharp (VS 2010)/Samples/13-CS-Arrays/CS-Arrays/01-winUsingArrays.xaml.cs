﻿using System;
using System.Diagnostics;
using System.Windows;

namespace CS_Arrays
{
	public partial class winUsingArrays : Window
	{
		public winUsingArrays()
		{
			InitializeComponent();
		}

		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			txtLines.Text = "This is line 1" + Environment.NewLine;
			txtLines.Text += "This is line 2" + Environment.NewLine;
			txtLines.Text += "This is line 3" + Environment.NewLine;
			txtLines.Text += "This is line 4" + Environment.NewLine;
		}

		private void btnStringToArray_Click(object sender, RoutedEventArgs e)
		{
			StringToArray();
		}

		private void StringToArray()
		{
			string[] values = null;
			string names = null;
			int index = 0;

			names = "Ken,Michael,Bruce,Paul";

			values = names.Split(",".ToCharArray());

			for (index = 0; index <= values.Length - 1; index++)
			{
				Debug.WriteLine(values[index]);
			}
		}

		private void btnFiles_Click(object sender, RoutedEventArgs e)
		{
			GetFiles();
		}

		private void GetFiles()
		{
			string[] files = null;

			files = System.IO.Directory.GetFiles("D:\\");

			foreach (string name in files)
			{
				Debug.WriteLine(name);
			}
		}

		private void btnFolders_Click(object sender, RoutedEventArgs e)
		{
			GetFolders();
		}

		private void GetFolders()
		{
			string[] folders = null;

			folders = System.IO.Directory.GetDirectories("D:\\");

			foreach (string name in folders)
			{
				Debug.WriteLine(name);
			}
		}

		private void btnLinesInTextBox_Click(object sender, RoutedEventArgs e)
		{
			LinesInTextBox();
		}

		private void LinesInTextBox()
		{
			string[] lines = null;

			// Create Array to size of lines
			lines = new string[txtLines.LineCount + 1];

			for (int index = 0; index <= txtLines.LineCount - 1; index++)
			{
				lines[index] = txtLines.GetLineText(index);
			}

			// Display Each Line
			foreach (string line in lines)
			{
				Debug.Write(line);
			}
		}
	}
}
