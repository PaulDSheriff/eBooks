﻿using System.Windows;

namespace CS_Methods
{
	public partial class winFunctions : Window
	{
		public winFunctions()
		{
			InitializeComponent();
		}

		private void btnDisplay_Click(object sender, RoutedEventArgs e)
		{
			EmployeeDisplay();
		}

		private void EmployeeDisplay()
		{
			string name = null;

			name = EmployeeName("Bill", "Gates");
			MessageBox.Show(name);

			MessageBox.Show(EmployeeName(txtFirst.Text, txtLast.Text));
		}

		public string EmployeeName(string firstName, string lastName)
		{
			string ret = null;

			ret = "My Last Name is " + lastName;
			ret += " and my first name is " + firstName;

			return ret;
		}
	}
}
