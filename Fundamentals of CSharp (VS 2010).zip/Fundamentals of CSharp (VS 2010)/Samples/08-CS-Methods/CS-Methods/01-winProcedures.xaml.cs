﻿using System.Windows;

namespace CS_Methods
{
	public partial class winProcedures : Window
	{
		public winProcedures()
		{
			InitializeComponent();
		}
		
		private void btnDisplay_Click(object sender, RoutedEventArgs e)
		{
			EmployeeName(txtFirst.Text, txtLast.Text);
		}

		public void EmployeeName(string firstName, string lastName)
		{
			string empName = null;

			empName = "My Last Name is " + lastName;
			empName += " and my First Name is " + firstName;

			MessageBox.Show(empName);
		}
	}
}
