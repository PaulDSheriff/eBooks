﻿using System;
using System.Diagnostics;
using System.Windows;

namespace CS_Methods
{
	public partial class winMethods : Window
	{
		public winMethods()
		{
			InitializeComponent();
		}

		private void btnString_Click(object sender, RoutedEventArgs e)
		{
			StringMethods();
		}

		private void StringMethods()
		{
			string value = null;

			value = "Bill";

			Debug.WriteLine(value.Length);
			Debug.WriteLine(value.IndexOf("i"));
			Debug.WriteLine(value.LastIndexOf("l"));
			Debug.WriteLine(value.EndsWith("g"));
			Debug.WriteLine(value.Insert(4, " Gates"));
			value = value.Insert(4, " Gates");
			Debug.WriteLine(value.Remove(4, 5));
			Debug.WriteLine(value.PadLeft(10));
			Debug.WriteLine(value.PadRight(10));
			Debug.WriteLine(value.Replace("i", "TT"));
			Debug.WriteLine(value.Replace("TT", "i"));
			Debug.WriteLine(value.Substring(2, 2));
			Debug.WriteLine(value.ToLower());
			Debug.WriteLine(value.ToUpper());
			Debug.WriteLine(value.Trim());
		}

		private void btnNumeric_Click(object sender, RoutedEventArgs e)
		{
			NumericMethods();
		}

		private void NumericMethods()
		{
			int value = 0;
			int outValue;
			string valueString = "25";

			// Convert a string to a numeric
			value = int.Parse(valueString);

			// See if you can convert a value
			valueString = "no";
			if (int.TryParse(valueString, out outValue))
				value = outValue;

			value = 10;

			Debug.WriteLine(int.MaxValue);
			Debug.WriteLine(int.MinValue);
			Debug.WriteLine(value.ToString());
		}

		private void btnDate_Click(object sender, RoutedEventArgs e)
		{
			DateMethods();
		}

		private void DateMethods()
		{
			DateTime value = default(System.DateTime);
			DateTime outValue;

			value = Convert.ToDateTime("01/01/2011");

			Debug.WriteLine(value.AddDays(10));
			Debug.WriteLine(value.AddYears(2));
			Debug.WriteLine(value.AddMinutes(10));
			Debug.WriteLine(value.Date);
			Debug.WriteLine(value.Day);
			Debug.WriteLine(value.DayOfWeek);
			Debug.WriteLine(value.DayOfYear);
			Debug.WriteLine(value.Hour);
			Debug.WriteLine(value.Minute);
			Debug.WriteLine(value.Month);
			Debug.WriteLine(value.Year);
			Debug.WriteLine(value.ToString());

			// Check for a Valid Date
			if (DateTime.TryParse("01/01/2011", out outValue))
				MessageBox.Show("Valid Date");
			else
				MessageBox.Show("Invalid Date");
		}
	}
}
