﻿using System.Diagnostics;
using System.Windows;

namespace CS_Methods
{
	public partial class winByValByRef : Window
	{
		public winByValByRef()
		{
			InitializeComponent();
		}

		private void btnByVal_Click(object sender, RoutedEventArgs e)
		{
			ByValExample();
		}

		private void ByValExample()
		{
			int ret = 0;
			string value = null;

			ret = 10;
			value = "Bill";

			ByValProcedure(ret, value);

			Debug.WriteLine("ret = " + ret.ToString());
			Debug.WriteLine("value = " + value.ToString());
		}

		private void ByValProcedure(int arg1, string arg2)
		{
			arg1 = 20;
			arg2 = "Gates";
		}

		private void btnByRef_Click(object sender, RoutedEventArgs e)
		{
			ByRefExample();
		}

		private void ByRefExample()
		{
			int ret = 0;
			string value = null;

			ret = 10;
			value = "Bill";

			ByRefProcedure(ref ret, ref value);

			Debug.WriteLine("ret = " + ret.ToString());
			Debug.WriteLine("value = " + value.ToString());
		}

		private void ByRefProcedure(ref int arg1, ref string arg2)
		{
			arg1 = 20;
			arg2 = "Gates";
		}

		private void btnOutParams_Click(object sender, RoutedEventArgs e)
		{
			OutputExample();
		}

		private void OutputExample()
		{
			string twoWords;
			string wordOne;
			string wordTwo;

			twoWords = "BillGates";

			SplitIntoTwo(twoWords, out wordOne, out wordTwo);

			Debug.WriteLine("Word One = " + wordOne);
			Debug.WriteLine("Word Two = " + wordTwo);
		}

		private void SplitIntoTwo(string words, out string firstWord,
													out string secondWord)
		{
			firstWord = string.Empty;
			secondWord = string.Empty;

			for (int i = 0; i < words.Length - 1; i++)
			{
				if (firstWord.Length > 0 && char.IsUpper(words[i]))
				{
					secondWord = words.Substring(i);
					break;
				}
				else
				{
					firstWord += words[i].ToString();
				}
			}
		}
	}
}
