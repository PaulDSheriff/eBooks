﻿using System.Windows;

namespace CS_DialogWindows
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private void btnLogin_Click(object sender, RoutedEventArgs e)
		{
			winLogin win = new winLogin();

			win.Owner = this;
			win.ShowDialog();
			if (win.DialogResult.HasValue & win.DialogResult.Value)
				MessageBox.Show("User Logged In");
			else
				this.Close();
		}
	}
}
