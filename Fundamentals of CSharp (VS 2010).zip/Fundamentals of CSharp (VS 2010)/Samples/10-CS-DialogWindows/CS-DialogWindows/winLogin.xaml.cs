﻿using System.Windows;

namespace CS_DialogWindows
{
	public partial class winLogin : Window
	{
		public winLogin()
		{
			InitializeComponent();
		}

		private void btnLogin_Click(object sender, RoutedEventArgs e)
		{
			// Must set this to get window to close
			DialogResult = true;

			// NOTE: It is not necessary to write any code 
			//       in the Cancel button Click event procedure
		}
	}
}
