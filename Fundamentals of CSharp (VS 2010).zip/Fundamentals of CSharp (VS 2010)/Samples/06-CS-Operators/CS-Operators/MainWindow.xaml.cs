﻿using System;
using System.Windows;

namespace CS_Operators
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private void btnAddition_Click(object sender, RoutedEventArgs e)
		{
			AdditionSample();
		}

		private void AdditionSample()
		{
			int value1 = 2;
			int value2 = 2;

			tbAddition.Text = Convert.ToString(value1 + value2);
		}

		private void btnSubtraction_Click(object sender, RoutedEventArgs e)
		{
			SubtractionSample();
		}

		private void SubtractionSample()
		{
			int value1 = 2;
			int value2 = 2;

			tbSubtraction.Text = Convert.ToString(value1 - value2);
		}

		private void btnMultiplication_Click(object sender, RoutedEventArgs e)
		{
			MultiplicationSample();
		}

		private void MultiplicationSample()
		{
			int value1 = 2;
			int value2 = 2;

			tbMultiplication.Text = Convert.ToString(value1 * value2);
		}

		private void btnDivision_Click(object sender, RoutedEventArgs e)
		{
			DivisionSample();
		}

		private void DivisionSample()
		{
			int value1 = 10;
			int value2 = 2;

			tbDivision.Text = Convert.ToString(value1 / value2);
		}

		private void btnIntegerDivision_Click(object sender, RoutedEventArgs e)
		{
			IntegerDivisionSample();
		}

		private void IntegerDivisionSample()
		{
			int value1 = 9;
			int value2 = 2;

			tbIntegerDivision.Text = Convert.ToString(value1 / value2);
		}

		private void btnModulus_Click(object sender, RoutedEventArgs e)
		{
			ModulusSample();
		}

		private void ModulusSample()
		{
			int value1 = 9;
			int value2 = 2;

			tbModulus.Text = Convert.ToString(value1 % value2);
		}

		private void btnExponentiation_Click(object sender, RoutedEventArgs e)
		{
			ExponentiationSample();
		}

		private void ExponentiationSample()
		{
			int value1 = 2;
			int value2 = 4;

			tbExponentiation.Text = Convert.ToString(Math.Pow(value1, value2));
		}
	}
}
