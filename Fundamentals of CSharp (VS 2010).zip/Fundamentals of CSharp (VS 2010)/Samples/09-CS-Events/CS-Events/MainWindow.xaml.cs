﻿using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;

namespace CS_Events
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private void Window_Loaded(System.Object sender, RoutedEventArgs e)
		{
			this.WindowState = WindowState.Maximized;
			DisplayMessage("Window_Loaded Event");
		}

		private void Window_Activated(System.Object sender, System.EventArgs e)
		{
			DisplayMessage("Window_Activated Event");
		}

		private void Window_SizeChanged(System.Object sender, SizeChangedEventArgs e)
		{
			DisplayMessage("Window_SizeChanged Event");
		}

		private void Window_Closing(System.Object sender, System.ComponentModel.CancelEventArgs e)
		{
			DisplayMessage("Window_Closing Event");
		}

		private void txtFirst_TextChanged(System.Object sender, TextChangedEventArgs e)
		{
			DisplayMessage("txtFirst_TextChanged Event");
		}

		private void cboStates_SelectionChanged(System.Object sender, SelectionChangedEventArgs e)
		{
			DisplayMessage("cboStates_SelectionChanged Event: " + ((ComboBoxItem)cboStates.SelectedItem).Content.ToString());
		}

		private void rdoMale_Checked(System.Object sender, RoutedEventArgs e)
		{
			DisplayMessage("rdoMale_Checked Event");
		}

		private void rdoFemale_Checked(System.Object sender, RoutedEventArgs e)
		{
			DisplayMessage("rdoFemale_Checked Event");
		}

		private void Radio_Checked(System.Object sender, RoutedEventArgs e)
		{
			if (sender.Equals(rdoFemale))
				DisplayMessage("Female Event");
			else if (sender.Equals(rdoMale))
				DisplayMessage("Male Event");
		}

		private void chkHealthCare_Checked(System.Object sender, RoutedEventArgs e)
		{
			DisplayMessage("chkHealthCare_Checked Event");
		}

		private void chk401k_Checked(System.Object sender, RoutedEventArgs e)
		{
			DisplayMessage("chk401k_Checked Event");
		}

		private void chkBonus_Checked(System.Object sender, RoutedEventArgs e)
		{
			DisplayMessage("chkBonus_Checked Event");
		}

		private void chkHealthCare_Unchecked(System.Object sender, RoutedEventArgs e)
		{
			DisplayMessage("chkHealthCare_Unchecked Event");
		}

		private void chk401k_Unchecked(System.Object sender, RoutedEventArgs e)
		{
			DisplayMessage("chk401k_Unchecked Event");
		}

		private void chkBonus_Unchecked(System.Object sender, RoutedEventArgs e)
		{
			DisplayMessage("chkBonus_Unchecked Event");
		}

		private void tabEmployee_SelectionChanged(System.Object sender, SelectionChangedEventArgs e)
		{
			DisplayMessage("tabEmployee_SelectionChanged Event");
			if (tabGeneral.IsSelected)
			{
				DisplayMessage("General Tab Item Selected");
			}
			else if (tabOther.IsSelected)
			{
				DisplayMessage("Other Tab Item Selected");
			}
		}

		private void DisplayMessage(string msg)
		{
			Debug.WriteLine(msg);
		}
	}
}
