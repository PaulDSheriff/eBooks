﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls

Partial Public Class CCDisplay
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)
		Dim cc As PDSACreditCard = Nothing

		If Session("PDSACC") IsNot Nothing Then
			cc = DirectCast(Session("PDSACC"), PDSACreditCard)

			Me.ucCreditCardDisplay1.SetUserData(cc)
		End If

	End Sub
End Class