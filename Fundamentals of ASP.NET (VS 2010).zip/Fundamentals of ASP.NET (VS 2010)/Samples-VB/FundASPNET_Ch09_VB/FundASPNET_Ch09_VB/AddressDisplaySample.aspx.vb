﻿Public Class AddressDisplaySample1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
		Me.ucAddressDisplay1.SetUserData(DirectCast(Session("PDSAAddress"), PDSAAddress))
    End Sub

End Class