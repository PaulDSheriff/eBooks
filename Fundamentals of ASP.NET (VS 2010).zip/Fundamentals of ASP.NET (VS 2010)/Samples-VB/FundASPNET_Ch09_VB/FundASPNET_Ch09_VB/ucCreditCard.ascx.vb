﻿Partial Public Class ucCreditCard
	Inherits System.Web.UI.UserControl
	Protected Sub Page_Load(sender As Object, e As EventArgs)
		If Not (Page.IsPostBack) Then
			CardTypesLoad()
			MonthLoad()
			YearLoad()
		End If

	End Sub
	Private Sub CardTypesLoad()
		Dim ds As New DataSet()

		ds.ReadXml(Server.MapPath("~/Xml-Common/CreditCardTypes.xml"))

		ddlCreditCards.DataTextField = "Name"
		ddlCreditCards.DataValueField = "Name"
		ddlCreditCards.DataSource = ds
		ddlCreditCards.DataBind()
	End Sub


	Private Sub MonthLoad()
		Dim intLoop As Integer = 0

		For intLoop = 1 To 12
			ddlMonth.Items.Add(intLoop.ToString() + "-" + GetMonthName(intLoop))
		Next
	End Sub

	Private Sub YearLoad()
		Dim intLoop As Integer = 0

		For intLoop = DateTime.Now.Year To (DateTime.Now.Year + 12)
			ddlYear.Items.Add(intLoop.ToString())
		Next
	End Sub

	Private Function GetMonthName(Value As Integer) As String
		Dim dtfi As New System.Globalization.DateTimeFormatInfo()
		Dim arr As String() = Nothing

		arr = dtfi.MonthNames

		Return arr(Value - 1)
	End Function

	Public Function GetUserData() As PDSACreditCard
		Dim cc As New PDSACreditCard()
		Dim strCC As String = Nothing

		strCC = txtCardNumber.Text.Trim()
		strCC = strCC.Replace(" ", "")
		strCC = strCC.Replace("-", "")
		strCC = strCC.Replace("/", "")
		strCC = strCC.Replace("\", "")
		strCC = strCC.Replace(".", "")

		cc.CreditCardNumber = strCC
		If ddlCreditCards.SelectedItem IsNot Nothing Then
			cc.CreditCardType = ddlCreditCards.SelectedItem.Text
		End If
		cc.CVCode = txtCVCode.Text
		cc.NameOnCard = txtName.Text
		If ddlMonth.SelectedItem IsNot Nothing Then
			cc.ExpMonth = ddlMonth.SelectedItem.Text
		End If
		If ddlYear.SelectedItem IsNot Nothing Then
			cc.ExpYear = ddlYear.SelectedItem.Text
		End If
		cc.BillingPostalCode = txtZipCode.Text

		Return cc
	End Function

	Public Sub SetUserData(cc As PDSACreditCard)
		Dim strCC As String = Nothing

		strCC = cc.CreditCardNumber.Trim()

		If strCC.Length > 4 Then
			txtCardNumber.Text = "**********" + strCC.Substring(strCC.Length - 4)
		Else
			If strCC.Length = 0 Then
				txtCardNumber.Text = ""
			Else
				txtCardNumber.Text = "*********************"
			End If
		End If
		PDSAWebList.DropDownFindByText(ddlCreditCards, cc.CreditCardType)
		txtName.Text = cc.NameOnCard
		txtCVCode.Text = cc.CVCode
		PDSAWebList.DropDownFindByText(ddlMonth, cc.ExpMonth)
		PDSAWebList.DropDownFindByText(ddlYear, cc.ExpYear)
		txtZipCode.Text = cc.BillingPostalCode
	End Sub
End Class


