﻿<Serializable()> _
Public Class PDSACreditCard
	Private _CreditCardType As String = "Visa"
	Private mstrNameOnCard As String = String.Empty
	Private mstrCreditCardNumber As String = String.Empty
	Private mstrExpMonth As String = String.Empty
	Private mstrExpYear As String = String.Empty
	Private mstrCVCode As String = String.Empty
	Private mstrBillingPostalCode As String = String.Empty

	Public Property BillingPostalCode() As String
		Get
			Return mstrBillingPostalCode
		End Get
		Set(value As String)
			mstrBillingPostalCode = value
		End Set
	End Property

	Public Property CreditCardType() As String
		Get
			Return _CreditCardType
		End Get
		Set(value As String)
			_CreditCardType = value
		End Set
	End Property

	Public Property NameOnCard() As String
		Get
			Return mstrNameOnCard
		End Get
		Set(value As String)
			mstrNameOnCard = value
		End Set
	End Property

	Public Property CreditCardNumber() As String
		Get
			Return mstrCreditCardNumber
		End Get
		Set(value As String)
			mstrCreditCardNumber = value
		End Set
	End Property

	Public Property ExpMonth() As String
		Get
			Return mstrExpMonth
		End Get
		Set(value As String)
			mstrExpMonth = value
		End Set
	End Property

	Public Property ExpYear() As String
		Get
			Return mstrExpYear
		End Get
		Set(value As String)
			mstrExpYear = value
		End Set
	End Property

	Public Property CVCode() As String
		Get
			Return mstrCVCode
		End Get
		Set(value As String)
			mstrCVCode = value
		End Set
	End Property
End Class
