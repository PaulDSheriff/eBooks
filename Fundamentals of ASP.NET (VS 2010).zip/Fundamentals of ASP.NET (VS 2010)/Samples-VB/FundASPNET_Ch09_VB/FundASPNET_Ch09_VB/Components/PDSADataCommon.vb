﻿Imports System.Web
Imports System.Data
Imports System.Configuration
Imports System.EnterpriseServices
Imports System.Drawing

Public Class PDSADataCommon
#Region "Common Methods"
	Public Shared Function FileToDataSet(FileName As String) As DataSet
		Dim ds As DataSet = Nothing

		ds = New DataSet()

		ds.ReadXml(FileName)

		Return ds
	End Function


	Public Shared Function GetCountries() As DataSet
		Return FileToDataSet(HttpContext.Current.Server.MapPath("~/XML-Common/Countries.xml"))
	End Function


	Public Shared Function GetUSStates() As DataSet
		Return FileToDataSet(HttpContext.Current.Server.MapPath("~/XML-Common/USStates.xml"))
	End Function


	Public Shared Function GetCanadianProvinces() As DataSet
		Return FileToDataSet(HttpContext.Current.Server.MapPath("~/XML-Common/CanadianProvinces.xml"))
	End Function
#End Region
End Class
