﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Web


Public Class PDSAAddress
	Public Enum PDSAAddressTypeEnum As Integer
		US
		Canadian
		UK
		Other
	End Enum

	Private mObjectId As Guid = Guid.NewGuid()
	Private mType As PDSAAddressTypeEnum = PDSAAddressTypeEnum.US
	Private mstrAddress1 As String = String.Empty
	Private mstrAddress2 As String = String.Empty
	Private mstrAddress3 As String = String.Empty
	Private mstrCity As String = String.Empty
	Private mstrVillage As String = String.Empty
	Private mintStateId As Integer = Integer.MinValue
	Private mstrStateCode As String = String.Empty
	Private mstrStateName As String = String.Empty
	Private mintCountryId As Integer = Integer.MinValue
	Private mstrCountryCode As String = String.Empty
	Private mstrCountryName As String = String.Empty
	Private mstrPostalCode As String = String.Empty
	Private mstrPostalCodeExt As String = String.Empty

	Public ReadOnly Property ObjectId() As Guid
		Get
			Return Me.mObjectId
		End Get
	End Property

	Public Property Type() As PDSAAddressTypeEnum
		Get
			Return Me.mType
		End Get
		Set(value As PDSAAddressTypeEnum)
			Me.mType = value
		End Set
	End Property

	Public Property Address1() As String
		Get
			Return Me.mstrAddress1
		End Get
		Set(value As String)
			Me.mstrAddress1 = value
		End Set
	End Property

	Public Property Address2() As String
		Get
			Return Me.mstrAddress2
		End Get
		Set(value As String)
			Me.mstrAddress2 = value
		End Set
	End Property

	Public Property Address3() As String
		Get
			Return Me.mstrAddress3
		End Get
		Set(value As String)
			Me.mstrAddress3 = value
		End Set
	End Property

	Public Property City() As String
		Get
			Return Me.mstrCity
		End Get
		Set(value As String)
			Me.mstrCity = value
		End Set
	End Property

	Public Property Village() As String
		Get
			Return Me.mstrVillage
		End Get
		Set(value As String)
			Me.mstrVillage = value
		End Set
	End Property

	Public Property StateId() As Integer
		Get
			Return Me.mintStateId
		End Get
		Set(value As Integer)
			Me.mintStateId = value
		End Set
	End Property

	Public Property StateCode() As String
		Get
			Return Me.mstrStateCode
		End Get
		Set(value As String)
			Me.mstrStateCode = value
		End Set
	End Property

	Public Property StateName() As String
		Get
			Return Me.mstrStateName
		End Get
		Set(value As String)
			Me.mstrStateName = value
		End Set
	End Property

	Public Property CountryId() As Integer
		Get
			Return Me.mintCountryId
		End Get
		Set(value As Integer)
			Me.mintCountryId = value
		End Set
	End Property

	Public Property CountryCode() As String
		Get
			Return Me.mstrCountryCode
		End Get
		Set(value As String)
			Me.mstrCountryCode = value
		End Set
	End Property

	Public Property CountryName() As String
		Get
			Return Me.mstrCountryName
		End Get
		Set(value As String)
			Me.mstrCountryName = value
		End Set
	End Property

	Public Property PostalCode() As String
		Get
			Return Me.mstrPostalCode
		End Get
		Set(value As String)
			Me.mstrPostalCode = value
		End Set
	End Property

	Public Property PostalCodeExt() As String
		Get
			Return Me.mstrPostalCodeExt
		End Get
		Set(value As String)
			Me.mstrPostalCodeExt = value
		End Set
	End Property

	Public Overridable Function Validate() As Boolean
		Dim isValid As Boolean = True

		'  Require Address1
		If Me.mstrAddress1.Length = 0 Then
			isValid = False
		End If

		'  Require City
		If Me.mstrCity.Length = 0 Then
			isValid = False
		End If

		' Require State for Canada and US
		If Me.mType = PDSAAddressTypeEnum.Canadian Or Me.mType = PDSAAddressTypeEnum.US Then
			If Me.mstrStateName.Length = 0 And Me.mstrStateCode.Length = 0 And Me.mintStateId > 0 Then
				isValid = False
			End If
		End If

		'  Require Postal Code
		If Me.mstrPostalCode.Length = 0 Then
			isValid = False
		End If

		Return isValid
	End Function

	Public Function GetFullAddress() As String
		' Returns an strAddr in the following format
		' 1234 Street
		' PO Box 1234
		' Route(4)
		' City, State 90210-1234

		Dim strAddr As String = Nothing

		strAddr = Me.mstrAddress1

		If Me.mstrAddress2.Length > 0 Then
			strAddr += vbCr & vbLf & Me.mstrAddress2
		End If

		If Me.mstrAddress3.Length > 0 Then
			strAddr += vbCr & vbLf & Me.mstrAddress3
		End If

		strAddr += vbCr & vbLf & Me.mstrCity

		If Me.mType <> PDSAAddressTypeEnum.Other Then
			If Me.mstrStateName.Trim() <> "" Then
				strAddr += ", " & Me.mstrStateName
			Else
				strAddr += ", " & Me.mstrStateCode
			End If
		End If

		strAddr += "  " & Me.mstrPostalCode

		If Me.mType <> PDSAAddressTypeEnum.Other And Me.mstrPostalCodeExt.Trim() <> String.Empty Then
			strAddr += " - " & Me.mstrPostalCodeExt
		End If

		Return strAddr
	End Function

	Public Overrides Function ToString() As String
		Return GetFullAddress()
	End Function
End Class

