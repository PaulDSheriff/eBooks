﻿Imports System.Web
Imports System.Web.UI.WebControls

Public Class PDSAWebList
	Public Shared Sub DropDownFindByText(ByRef ddl As DropDownList, Value As String)
		Dim di As ListItem = Nothing

		di = ddl.Items.FindByText(Value)
		If Not ((di Is Nothing)) Then
			di.Selected = True
		End If
	End Sub

	Public Shared Sub DropDownFindByValue(ByRef ddl As DropDownList, Value As Integer)
		Dim di As ListItem = Nothing

		di = ddl.Items.FindByValue(Value.ToString())
		If Not ((di Is Nothing)) Then
			di.Selected = True
		End If
	End Sub

	Public Shared Sub DropDownFindByValue(ByRef ddl As DropDownList, Value As String)
		Dim di As ListItem = Nothing

		di = ddl.Items.FindByValue(Value)
		If Not ((di Is Nothing)) Then
			di.Selected = True
		End If
	End Sub
End Class
