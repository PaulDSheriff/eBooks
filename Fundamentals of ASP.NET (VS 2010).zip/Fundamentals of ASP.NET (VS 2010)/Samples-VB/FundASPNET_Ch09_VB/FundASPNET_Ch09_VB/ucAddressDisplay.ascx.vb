﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Text

Partial Public Class ucAddressDisplay
	Inherits System.Web.UI.UserControl
	Protected Sub Page_Load(sender As Object, e As EventArgs)

	End Sub
	Public Sub SetUserData(address As PDSAAddress)
		Dim sb As New StringBuilder(1024)

		sb.Append(address.Address1)
		sb.Append("<br />")
		If address.Address2.Trim() <> String.Empty Then
			sb.Append(address.Address2)
			sb.Append("<br />")
		End If
		If address.Address3.Trim() <> String.Empty Then
			sb.Append(address.Address3)
			sb.Append("<br />")
		End If
		If address.City.Trim() <> String.Empty Then
			sb.Append(address.City)
		End If
		If address.Village.Trim() <> String.Empty Then
			sb.Append(address.Village)
		End If
		If address.StateName.Trim() <> String.Empty Then
			sb.Append(", " & Convert.ToString(address.StateName))
		ElseIf address.StateCode.Trim() <> String.Empty Then
			sb.Append(", " & Convert.ToString(address.StateCode))
		End If
		If address.PostalCode.Trim() <> String.Empty Then
			sb.Append(" " & Convert.ToString(address.PostalCode))
			If address.PostalCodeExt <> String.Empty Then
				sb.Append("-" & Convert.ToString(address.PostalCodeExt))
			End If
			sb.Append("<br />")
		End If
		If address.CountryName.Trim() <> String.Empty Then
			sb.Append(address.CountryName)
			sb.Append("<br />")
		ElseIf address.CountryCode.Trim() <> String.Empty Then
			sb.Append(address.CountryCode)
			sb.Append("<br />")
		End If

		lblAddress.Text = sb.ToString()
	End Sub

End Class

