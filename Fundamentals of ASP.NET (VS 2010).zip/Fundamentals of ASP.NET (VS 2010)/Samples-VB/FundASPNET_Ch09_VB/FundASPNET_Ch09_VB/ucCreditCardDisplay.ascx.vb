﻿Partial Public Class ucCreditCardDisplay
	Inherits System.Web.UI.UserControl
	Protected Sub Page_Load(sender As Object, e As EventArgs)

	End Sub
	Public Sub SetUserData(cc As PDSACreditCard)
		SetUserData(cc, False)
	End Sub

	Public Sub SetUserData(cc As PDSACreditCard, DisplayRealCCNumber As Boolean)
		lblCCType.Text = cc.CreditCardType
		If DisplayRealCCNumber Then
			lblCCNumber.Text = cc.CreditCardNumber
		Else
			If cc.CreditCardNumber.Length > 4 Then
				lblCCNumber.Text = "***************" + cc.CreditCardNumber.Substring(cc.CreditCardNumber.Length - 4)
			Else
				lblCCNumber.Text = "***************"
			End If
		End If
		lblName.Text = cc.NameOnCard
		lblExpDate.Text = cc.ExpMonth + "/" + cc.ExpYear
		lblPostalCode.Text = cc.BillingPostalCode
	End Sub
End Class


