﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls


Partial Public Class ucAddress
	Inherits System.Web.UI.UserControl
	Protected Sub Page_Load(sender As Object, e As EventArgs)
		If Not (Page.IsPostBack) Then
			Me.InitControlVisiblity()
			LoadDropDowns()
		End If

	End Sub
	Private Sub InitControlVisiblity()
		Me.divPDSAAddrAddress3.Visible = False
		Me.divPDSAAddrState.Visible = True
		Me.divPDSAAddrVillage.Visible = False
		Me.lblZipHypen.Visible = True
		Me.txtZipExension.Visible = True
		Me.lblZipPostal.Text = "Zip Code"
		Me.lblStateProvince.Text = "State"
		Me.lblZipHypen.Visible = True
		Me.txtZipExension.Visible = True
	End Sub

	Public Sub LoadDropDowns()
		If ddlCountry.Items.Count = 0 Then
			CountryLoad()
			ShowCountry()
			ShowDetails(PDSAAddress.PDSAAddressTypeEnum.US)
		End If
	End Sub

	Private Sub CountryLoad()
		ddlCountry.DataTextField = "sName"
		ddlCountry.DataValueField = "sCode"
		ddlCountry.DataSource = PDSADataCommon.GetCountries().Tables(0)
		ddlCountry.DataBind()
	End Sub

	Private Sub StateLoad()
		ddlStateProvince.DataTextField = "StateName"
		ddlStateProvince.DataValueField = "StateCode"
		Me.ddlStateProvince.DataSource = PDSADataCommon.GetUSStates().Tables(0)
		Me.ddlStateProvince.DataBind()
	End Sub

	Private ReadOnly Property AddressType() As PDSAAddress.PDSAAddressTypeEnum
		Get
			If Me.ddlCountry.SelectedItem.Value = "USA" Then
				Return PDSAAddress.PDSAAddressTypeEnum.US
			ElseIf Me.ddlCountry.SelectedItem.Value = "CAN" Then
				Return PDSAAddress.PDSAAddressTypeEnum.Canadian
			ElseIf Me.ddlCountry.SelectedItem.Value = "GBR" Then
				Return PDSAAddress.PDSAAddressTypeEnum.UK
			Else
				Return PDSAAddress.PDSAAddressTypeEnum.Other
			End If
		End Get
	End Property

	Protected Sub ddlCountry_SelectedIndexChanged(sender As System.Object, e As System.EventArgs)
		Me.ShowDetails(Me.AddressType)
	End Sub


	Public Sub ShowCountry()
		Me.divPDSAAddrCountry.Visible = True
		Me.divPDSAAddrDetails.Visible = True
	End Sub

	Public Sub ShowDetails(addressType As PDSAAddress.PDSAAddressTypeEnum)
		Me.divPDSAAddrDetails.Visible = True

		ddlStateProvince.DataSource = Nothing
		ddlStateProvince.Items.Clear()
		If Me.AddressType = PDSAAddress.PDSAAddressTypeEnum.Other Then
			Me.divPDSAAddrVillage.Visible = False
			Me.lblZipPostal.Text = "Postal Code"
			Me.divPDSAAddrAddress3.Visible = True
			Me.divPDSAAddrState.Visible = False
			Me.lblZipHypen.Visible = False
			Me.txtZipExension.Visible = False
			rfvStateProvince.Enabled = False
		ElseIf Me.AddressType = PDSAAddress.PDSAAddressTypeEnum.UK Then
			Me.divPDSAAddrVillage.Visible = True
			Me.lblZipPostal.Text = "Postal Code"
			Me.lblZipHypen.Visible = False
			Me.txtZipExension.Visible = False
			Me.divPDSAAddrState.Visible = False
			rfvStateProvince.Enabled = False
		ElseIf Me.AddressType = PDSAAddress.PDSAAddressTypeEnum.Canadian Then
			Me.divPDSAAddrVillage.Visible = False
			Me.lblZipPostal.Text = "Postal Code"
			Me.lblStateProvince.Text = "Province"
			Me.lblZipHypen.Visible = False
			Me.txtZipExension.Visible = False
			ddlStateProvince.DataTextField = "Name"
			ddlStateProvince.DataValueField = "PostalAbbr"
			Me.ddlStateProvince.DataSource = PDSADataCommon.GetCanadianProvinces().Tables(0)
			Me.ddlStateProvince.DataBind()
			rfvStateProvince.Enabled = False
		ElseIf Me.AddressType = PDSAAddress.PDSAAddressTypeEnum.US Then
			Me.divPDSAAddrAddress3.Visible = False
			Me.divPDSAAddrState.Visible = True
			Me.divPDSAAddrVillage.Visible = False
			Me.lblZipHypen.Visible = True
			Me.txtZipExension.Visible = True
			Me.lblZipPostal.Text = "Zip Code"
			Me.lblStateProvince.Text = "State"
			Me.lblZipHypen.Visible = True
			Me.txtZipExension.Visible = True
			ddlStateProvince.DataTextField = "StateName"
			ddlStateProvince.DataValueField = "StateCode"
			Me.ddlStateProvince.DataSource = PDSADataCommon.GetUSStates().Tables(0)
			Me.ddlStateProvince.DataBind()
			rfvStateProvince.Enabled = True
		End If
	End Sub

	Public Function GetUserData() As PDSAAddress
		Dim address As New PDSAAddress()

		address.Address1 = Me.txtAddress1.Text
		address.Address2 = Me.txtAddress2.Text
		address.Address3 = Me.txtAddress3.Text
		address.City = Me.txtCity.Text

		If divPDSAAddrState.Visible Then
			address.StateCode = Me.ddlStateProvince.SelectedItem.Value
			address.StateName = Me.ddlStateProvince.SelectedItem.Text
		Else
			address.StateCode = ""
			address.StateName = ""
		End If
		address.CountryCode = Me.ddlCountry.SelectedItem.Value
		address.CountryName = Me.ddlCountry.SelectedItem.Text
		address.PostalCode = Me.txtZipPostal.Text

		If Me.txtZipExension.Text.Length > 0 Then
			address.PostalCodeExt = Me.txtZipExension.Text
		End If
		address.Type = Me.AddressType

		Return address
	End Function

	Public Sub SetUserData(address As PDSAAddress)

		Me.txtAddress1.Text = address.Address1
		Me.txtAddress2.Text = address.Address2
		Me.txtAddress3.Text = address.Address3
		Me.txtCity.Text = address.City

		If address.StateCode.Trim() <> "" Then
			ddlStateProvince.SelectedIndex = -1
			PDSAWebList.DropDownFindByValue(ddlStateProvince, address.StateCode)
		ElseIf address.StateName.Trim() <> "" Then
			ddlStateProvince.SelectedIndex = -1
			PDSAWebList.DropDownFindByText(ddlStateProvince, address.StateName)
		End If
		If address.CountryCode.Trim() <> "" Then
			ddlCountry.SelectedIndex = -1
			PDSAWebList.DropDownFindByValue(ddlCountry, address.CountryCode)
		ElseIf address.CountryName.Trim() <> "" Then
			ddlCountry.SelectedIndex = -1
			PDSAWebList.DropDownFindByValue(ddlCountry, address.CountryName)
		End If
		Me.txtZipPostal.Text = address.PostalCode

		Me.txtZipExension.Text = address.PostalCodeExt
	End Sub
End Class

