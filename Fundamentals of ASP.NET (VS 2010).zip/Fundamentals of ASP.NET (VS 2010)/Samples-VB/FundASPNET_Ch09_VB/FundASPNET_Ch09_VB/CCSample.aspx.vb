﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls


Partial Public Class CCSample
	Inherits System.Web.UI.Page
	Protected Sub btnSubmit_Click(sender As Object, e As EventArgs)
		Dim cc As PDSACreditCard = Nothing

		cc = Me.ucCreditCard1.GetUserData()

		Session("PDSACC") = cc

		Response.Redirect("CCDisplay.aspx")
	End Sub
End Class

