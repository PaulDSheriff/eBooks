﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls


Partial Public Class DataListSample
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)

	End Sub

	Protected Sub dlstEmps_CancelCommand(source As Object, e As System.Web.UI.WebControls.DataListCommandEventArgs)
		dlstEmps.EditItemIndex = -1
		dlstEmps.DataBind()
	End Sub

	Protected Sub dlstEmps_EditCommand(source As Object, e As System.Web.UI.WebControls.DataListCommandEventArgs)
		dlstEmps.EditItemIndex = e.Item.ItemIndex
		dlstEmps.DataBind()
	End Sub

	Protected Sub dlstEmps_UpdateCommand(source As Object, e As System.Web.UI.WebControls.DataListCommandEventArgs)
		dsEmps.UpdateParameters("EmployeeID").DefaultValue = DirectCast(e.Item.FindControl("btnUpdate"), LinkButton).CommandArgument
		dsEmps.UpdateParameters("LastName").DefaultValue = DirectCast(e.Item.FindControl("LastName"), TextBox).Text
		dsEmps.UpdateParameters("FirstName").DefaultValue = DirectCast(e.Item.FindControl("FirstName"), TextBox).Text
		dsEmps.UpdateParameters("HomePhone").DefaultValue = DirectCast(e.Item.FindControl("HomePhone"), TextBox).Text
		dsEmps.Update()

		dlstEmps.EditItemIndex = -1
		dlstEmps.DataBind()
	End Sub
End Class
