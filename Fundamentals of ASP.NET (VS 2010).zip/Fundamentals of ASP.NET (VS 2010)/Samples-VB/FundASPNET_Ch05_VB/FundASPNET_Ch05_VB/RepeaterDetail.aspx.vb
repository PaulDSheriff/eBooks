﻿Partial Public Class RepeaterDetail
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)

	End Sub
	Protected Sub repProducts_ItemCommand(source As Object, e As System.Web.UI.WebControls.RepeaterCommandEventArgs)
		lblInventory.Text = String.Format("There are currently {0} units " & "of {1} in stock.", e.CommandArgument, e.CommandName)
	End Sub
End Class