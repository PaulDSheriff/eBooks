﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Data.SqlClient
Imports System.Data
Imports System.Configuration


Partial Public Class GridViewAdd
	Inherits System.Web.UI.Page

	Protected Sub Page_Load(sender As Object, e As System.EventArgs)
		If Not (Page.IsPostBack) Then
			ViewState("Adding") = False
		End If
	End Sub
	Protected Sub lnkAdd_Click(sender As Object, e As System.EventArgs)
		Dim ds As New DataSet()
		Dim da As SqlDataAdapter = Nothing
		Dim dr As DataRow = Nothing

		da = New SqlDataAdapter(dsProducts.SelectCommand, dsProducts.ConnectionString)

		ViewState("Adding") = True
		da.Fill(ds)

		'  Get a Blank Row
		dr = ds.Tables(0).NewRow()
		'  Always make it appear at the first row in the grid
		ds.Tables(0).Rows.InsertAt(dr, 0)

		'  Use Blank Row as DataSource to Grid
		grdProducts.DataSourceID = String.Empty
		grdProducts.DataSource = ds
		grdProducts.DataBind()

		'  Edit the first item
		grdProducts.EditIndex = 0
	End Sub

	Protected Sub grdProducts_RowCancelingEdit(sender As Object, e As System.Web.UI.WebControls.GridViewCancelEditEventArgs)
		grdProducts.EditIndex = -1
		grdProducts.DataSourceID = "dsProducts"
		grdProducts.DataBind()
	End Sub

	Protected Sub grdProducts_RowUpdating(sender As Object, e As System.Web.UI.WebControls.GridViewUpdateEventArgs)
		If Convert.ToBoolean(ViewState("Adding")) Then
			DataAdd()

			e.Cancel = True
			ViewState("Adding") = False

			grdProducts.EditIndex = -1
			grdProducts.DataSourceID = "dsProducts"
			grdProducts.DataBind()
		End If
	End Sub

	Private Sub DataAdd()
		Dim intRows As Integer = 0
		Dim cmd As New SqlCommand()
		Dim row As GridViewRow = grdProducts.Rows(0)

		cmd.CommandText = dsProducts.InsertCommand
		cmd.Connection = New SqlConnection(AppConfig.ConnectionString)

		cmd.Parameters.Add(New SqlParameter("ProductName", SqlDbType.VarChar))
		cmd.Parameters.Add(New SqlParameter("SupplierID", SqlDbType.Int))
		cmd.Parameters.Add(New SqlParameter("CategoryID", SqlDbType.Int))
		cmd.Parameters.Add(New SqlParameter("QuantityPerUnit", SqlDbType.NVarChar))
		cmd.Parameters.Add(New SqlParameter("UnitPrice", SqlDbType.Money))
		cmd.Parameters.Add(New SqlParameter("UnitsInStock", SqlDbType.SmallInt))
		cmd.Parameters.Add(New SqlParameter("UnitsOnOrder", SqlDbType.SmallInt))
		cmd.Parameters.Add(New SqlParameter("ReorderLevel", SqlDbType.SmallInt))
		cmd.Parameters.Add(New SqlParameter("Discontinued", SqlDbType.Bit))

		cmd.Parameters("ProductName").Value = DirectCast(row.Cells(2).Controls(0), TextBox).Text
		cmd.Parameters("SupplierID").Value = DirectCast(row.Cells(3).Controls(1), DropDownList).SelectedValue
		cmd.Parameters("CategoryID").Value = DirectCast(row.Cells(4).Controls(1), DropDownList).SelectedValue
		cmd.Parameters("QuantityPerUnit").Value = DirectCast(row.Cells(5).Controls(0), TextBox).Text
		cmd.Parameters("UnitPrice").Value = DirectCast(row.Cells(6).Controls(0), TextBox).Text
		cmd.Parameters("UnitsInStock").Value = DirectCast(row.Cells(7).Controls(0), TextBox).Text
		cmd.Parameters("UnitsOnOrder").Value = DirectCast(row.Cells(8).Controls(0), TextBox).Text
		cmd.Parameters("ReorderLevel").Value = DirectCast(row.Cells(9).Controls(0), TextBox).Text
		cmd.Parameters("Discontinued").Value = DirectCast(row.Cells(10).Controls(0), CheckBox).Checked

		cmd.Connection.Open()
		intRows = cmd.ExecuteNonQuery()

		cmd.Connection.Close()
		cmd.Connection.Dispose()
	End Sub

End Class

Public Class AppConfig
	Public Shared ReadOnly Property ConnectionString() As String
		Get
			Return ConfigurationManager.ConnectionStrings("NorthwindConnectionString").ConnectionString
		End Get
	End Property
End Class


