﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls


Partial Public Class DataBindingWithSearch
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)

	End Sub
	Protected Sub btnSearch_Click(sender As Object, e As System.EventArgs)
		RebindData()
	End Sub

	Private Sub RebindData()
		grdProducts.DataBind()
	End Sub
End Class

