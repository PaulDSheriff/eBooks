﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls


Partial Public Class GridViewDetailsView
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)

	End Sub
	Protected Sub grdProducts_SelectedIndexChanged(sender As Object, e As System.EventArgs)
		DetailsView1.DataSourceID = "SqlDataSource2"
		DetailsView1.DataBind()
	End Sub

	Protected Sub DetailsView1_ItemInserted(sender As Object, e As System.Web.UI.WebControls.DetailsViewInsertedEventArgs)
		e.KeepInInsertMode = False
		grdProducts.DataBind()
	End Sub

	Protected Sub DetailsView1_ItemInserting(sender As Object, e As System.Web.UI.WebControls.DetailsViewInsertEventArgs)
		' This event procedure must be defined, but does not have to do anything
	End Sub

	Protected Sub DetailsView1_ItemUpdated(sender As Object, e As System.Web.UI.WebControls.DetailsViewUpdatedEventArgs)
		grdProducts.DataBind()
	End Sub

	Protected Sub lnkAdd_Click(sender As Object, e As System.EventArgs)
		'  Have to bind before we change the mode if it is not already bound
		DetailsView1.DataSourceID = "SqlDataSource2"
		DetailsView1.DataBind()
		DetailsView1.ChangeMode(DetailsViewMode.Insert)
	End Sub
End Class

