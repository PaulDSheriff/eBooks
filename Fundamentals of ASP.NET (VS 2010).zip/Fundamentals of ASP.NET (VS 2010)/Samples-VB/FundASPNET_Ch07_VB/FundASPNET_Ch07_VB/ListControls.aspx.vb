﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.UI.WebControls


Partial Public Class ListControls
	Inherits System.Web.UI.Page
	Protected Sub btnRegionCheckList_Click(sender As System.Object, e As System.EventArgs)
		RegionLoad(clstRegions)
	End Sub

	Protected Sub btnRegionRadioList_Click(sender As System.Object, e As System.EventArgs)
		RegionLoad(rlstRegions)
	End Sub

	Private Sub RegionLoad(ctlRegions As ListControl)
		Dim strSQL As String = Nothing
		Dim ds As New DataSet()
		Dim da As SqlDataAdapter = Nothing

		strSQL = "SELECT RegionID, RegionDescription " + "FROM Region"
		da = New SqlDataAdapter(strSQL, AppConfig.ConnectionString)
		da.Fill(ds)

		ctlRegions.DataTextField = "RegionDescription"
		ctlRegions.DataValueField = "RegionID"
		ctlRegions.DataSource = ds
		ctlRegions.DataBind()
	End Sub
End Class



