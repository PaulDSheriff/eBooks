﻿Partial Public Class AdRotator
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As System.EventArgs)
		If Not (Page.IsPostBack) Then
			rblFilter.Items.FindByText("Both").Selected = True
		End If
	End Sub

	Protected Sub rblFilter_SelectedIndexChanged(sender As Object, e As System.EventArgs)
		Dim filter As String = Nothing

		filter = rblFilter.SelectedItem.Text
		If filter = "Both" Then
			filter = String.Empty
		End If

		adEmp.KeywordFilter = filter
	End Sub
End Class

