﻿Partial Public Class LiteralControl
	Inherits System.Web.UI.Page
	Protected Sub btnAssign_Click(sender As System.Object, e As System.EventArgs)
		litHTML.Text = txtHTML.Text
	End Sub
End Class

