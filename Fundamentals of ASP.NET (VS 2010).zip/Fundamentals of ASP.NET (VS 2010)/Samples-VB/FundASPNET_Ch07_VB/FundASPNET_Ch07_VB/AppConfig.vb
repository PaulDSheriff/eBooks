﻿Imports System.Configuration


Public Class AppConfig
	Public Shared ReadOnly Property ConnectionString() As String
		Get
			Return ConfigurationManager.ConnectionStrings("NorthwindConnectionString").ConnectionString
		End Get
	End Property
End Class

