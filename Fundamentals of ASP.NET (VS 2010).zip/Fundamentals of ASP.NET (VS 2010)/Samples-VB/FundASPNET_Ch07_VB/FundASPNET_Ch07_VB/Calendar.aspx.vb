﻿Partial Public Class Calendar
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As System.EventArgs)
		cal.SelectedDate = cal.TodaysDate
	End Sub

	Protected Sub cal_SelectionChanged(sender As Object, e As System.EventArgs)
		lblDate.Text = String.Format("Selected date: {0:d}", cal.SelectedDate)
	End Sub

	Protected Sub cal_VisibleMonthChanged(sender As Object, e As System.Web.UI.WebControls.MonthChangedEventArgs)
		lblMonth.Text = String.Format("Visible Month: {0:MMMM yyyy}", e.NewDate)
	End Sub
End Class

