﻿Imports System.Web.UI
Imports System.Web.UI.WebControls

Partial Public Class PlaceHolderSample
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles MyBase.Load

		If (Not (Page.IsPostBack)) Then
			LoadPlaceHolder()
		End If
	End Sub

	Private Sub LoadPlaceHolder()
		Dim txt As New TextBox()
		Dim lit As New Literal()
		Dim btn As New Button()
		Dim hyp As New HyperLink()

		txt.Text = String.Empty
		txt.Width = 200
		plcHold.Controls.Add(txt)

		btn.Text = "Click Me!"
		plcHold.Controls.Add(btn)

		lit.Text = "<br />"
		plcHold.Controls.Add(lit)

		hyp.NavigateUrl = "LiteralControl.aspx"
		hyp.Text = "Literal Control Sample Page"
		hyp.ID = "hypSample"
		plcHold.Controls.Add(hyp)
	End Sub
End Class

