﻿Public Partial Class AdRotatorClickThru
	Inherits System.Web.UI.Page
End Class