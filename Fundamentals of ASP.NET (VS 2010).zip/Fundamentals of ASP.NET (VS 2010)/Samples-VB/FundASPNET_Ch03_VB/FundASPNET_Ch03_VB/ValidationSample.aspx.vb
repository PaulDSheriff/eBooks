﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls

Partial Public Class ValidationSample
	Inherits System.Web.UI.Page

	Protected Sub Page_Load(sender As Object, e As System.EventArgs)
		If Not (Page.IsPostBack) Then
			rvalBirthDate.MinimumValue = DateTime.Now.AddYears(-70).ToShortDateString()
			rvalBirthDate.MaximumValue = DateTime.Now.AddYears(-17).ToShortDateString()
			rvalBirthDate.ErrorMessage = String.Format("Enter a date between {0} and {1}", rvalBirthDate.MinimumValue, rvalBirthDate.MaximumValue)
		End If
	End Sub


	Protected Sub cvalState_ServerValidate(source As Object, args As System.Web.UI.WebControls.ServerValidateEventArgs)
		Select Case args.Value
			Case "CA", "NV", "AZ"
				args.IsValid = True
				Exit Select
			Case Else
				args.IsValid = False
				Exit Select
		End Select
	End Sub

	Protected Sub btnSave_Click(sender As Object, e As System.EventArgs)
		If Page.IsValid Then
			Server.Transfer("~/Default.aspx")
		End If
	End Sub
End Class
