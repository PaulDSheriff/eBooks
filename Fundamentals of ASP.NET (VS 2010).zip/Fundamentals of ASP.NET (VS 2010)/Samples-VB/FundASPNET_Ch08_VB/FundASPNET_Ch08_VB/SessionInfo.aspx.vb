﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls


Partial Public Class SessionInfo
	Inherits System.Web.UI.Page

	Protected Sub Page_Load(sender As Object, e As System.EventArgs)
		lblCodePage.Text = Session.CodePage.ToString()
		lblContents.Text = Session.Contents.ToString()
		lblCount.Text = Session.Count.ToString()
		lblIsCookieless.Text = Session.IsCookieless.ToString()
		lblIsNewSession.Text = Session.IsNewSession.ToString()
		lblIsReadOnly.Text = Session.IsReadOnly.ToString()
		lblIsSynchronized.Text = Session.IsSynchronized.ToString()
		lblLCID.Text = Session.LCID.ToString()
		lblMode.Text = Session.Mode.ToString()
		lblSessionID.Text = Session.SessionID.ToString()
		lblTimeOut.Text = Session.Timeout.ToString()
	End Sub
End Class

