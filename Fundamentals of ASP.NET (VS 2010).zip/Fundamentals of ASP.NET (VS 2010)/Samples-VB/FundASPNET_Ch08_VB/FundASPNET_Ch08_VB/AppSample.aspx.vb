﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls


Partial Public Class AppSample
	Inherits System.Web.UI.Page

	Protected Sub Page_Load(sender As Object, e As System.EventArgs)
		If Application("FullName") IsNot Nothing Then
			txtName.Text = Application("FullName").ToString()
		End If
	End Sub

	Protected Sub btnSubmit_Click(sender As Object, e As System.EventArgs)
		Application("FullName") = txtName.Text
		lblMessage.Visible = True
	End Sub

	Protected Sub btnSubmitClass_Click(sender As Object, e As System.EventArgs)
		AppCache.FullName = txtName.Text
		lblMessage.Visible = True
	End Sub
End Class

