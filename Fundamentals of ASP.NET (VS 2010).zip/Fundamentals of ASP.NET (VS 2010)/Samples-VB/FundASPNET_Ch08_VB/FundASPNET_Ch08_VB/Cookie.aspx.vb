﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls


Partial Public Class Cookie
	Inherits System.Web.UI.Page

	Protected Sub Page_Load(sender As Object, e As System.EventArgs)
		If Request.Cookies.[Get]("EmailPerm") IsNot Nothing Then
			txtEMail.Text = Request.Cookies.[Get]("EmailPerm").Value
		End If
	End Sub

	Protected Sub btnSubmit_Click(sender As Object, e As System.EventArgs)
		Response.Cookies.[Get]("EmailPerm").Value = txtEMail.Text
		Response.Cookies.[Get]("EmailPerm").Expires = DateTime.Today.AddDays(30)

		Response.Redirect("Default.aspx")
	End Sub

	Protected Sub cmdReset_Click(sender As Object, e As System.EventArgs)
		Response.Cookies.[Get]("EmailPerm").Expires = DateTime.Today.AddDays(-1)
		Response.Redirect("Default.aspx")
	End Sub
End Class

