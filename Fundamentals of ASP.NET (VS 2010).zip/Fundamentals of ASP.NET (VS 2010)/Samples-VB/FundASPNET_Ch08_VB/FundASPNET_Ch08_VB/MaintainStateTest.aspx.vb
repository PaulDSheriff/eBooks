﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls


Partial Public Class MaintainStateTest
	Inherits System.Web.UI.Page

	Protected Sub Page_Load(sender As Object, e As System.EventArgs)
		'  Evals true first time browser hits the page	
		If Page.IsPostBack Then
			lblMsg.Text = "Back again"
		Else
			lblMsg.Text = "First Time"
		End If
	End Sub

	Protected Sub btnSubmit_Click(sender As Object, e As System.EventArgs)
		lblResult.Text = txtEMail.Text
	End Sub
End Class

