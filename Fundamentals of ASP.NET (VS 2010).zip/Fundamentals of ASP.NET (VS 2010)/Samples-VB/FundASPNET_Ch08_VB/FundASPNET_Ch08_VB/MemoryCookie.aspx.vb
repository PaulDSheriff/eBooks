﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls


Partial Public Class MemoryCookie
	Inherits System.Web.UI.Page

	Protected Sub Page_Load(sender As Object, e As System.EventArgs)
		If Request.Cookies.[Get]("Email") IsNot Nothing Then
			txtEMail.Text = Request.Cookies.[Get]("Email").Value
		End If
	End Sub

	Protected Sub btnSubmit_Click(sender As Object, e As System.EventArgs)
		Response.Cookies.[Get]("Email").Value = txtEMail.Text

		' Response.Cookies.Add(New HttpCookie("Email", txtEMail.Text))

		Response.Redirect("Default.aspx")
	End Sub
End Class

