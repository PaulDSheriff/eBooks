﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls


Partial Public Class PassData2
	Inherits System.Web.UI.Page

	Protected Sub Page_Load(sender As Object, e As System.EventArgs)
		If Request.QueryString("ID") IsNot Nothing Then
			lblID.Text = Request.QueryString("ID")
		End If
		If Request.QueryString("Name") IsNot Nothing Then
			lblName.Text = Request.QueryString("Name")
		End If
	End Sub
End Class

