﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Diagnostics

Partial Public Class SessionWrapper
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)

	End Sub

	Protected Sub btnSessionVars_Click(sender As Object, e As System.EventArgs)
		AppSession.CurrentEmployeeID = 10
		AppSession.LastMenuAccessed = "SessionVars.aspx"

		Debug.WriteLine(AppSession.CurrentEmployeeID)
	End Sub
End Class
Public Class AppSession
	Public Shared Property CurrentEmployeeID() As Integer
		Get
			Return Convert.ToInt32(HttpContext.Current.Session("CurrentEmployeeID"))
		End Get
		Set(value As Integer)
			HttpContext.Current.Session("CurrentEmployeeID") = value
		End Set
	End Property

	Public Shared Property LastMenuAccessed() As String
		Get
			Return HttpContext.Current.Session("LastMenuAccessed").ToString()
		End Get
		Set(value As String)
			HttpContext.Current.Session("LastMenuAccessed") = value
		End Set
	End Property
End Class

