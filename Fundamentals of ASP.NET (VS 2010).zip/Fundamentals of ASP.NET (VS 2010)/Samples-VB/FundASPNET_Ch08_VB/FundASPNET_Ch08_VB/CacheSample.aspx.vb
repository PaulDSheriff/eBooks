﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls


Partial Public Class CacheSample
	Inherits System.Web.UI.Page

	Protected Sub Page_Load(sender As Object, e As System.EventArgs)
		If Cache("Name") IsNot Nothing Then
			txtName.Text = Cache("Name").ToString()
		End If
	End Sub

	Protected Sub btnAppObject_Click(sender As Object, e As System.EventArgs)
		'  Just like Application Object
		Cache("Name") = txtName.Text

		lblMessage.Visible = True
	End Sub

	Protected Sub btnTimeOut2Hours_Click(sender As Object, e As System.EventArgs)
		'  Absolutely expire in 2 hours
		Cache.Insert("Name", txtName.Text, Nothing, DateTime.UtcNow.AddHours(2), System.Web.Caching.Cache.NoSlidingExpiration)

		lblMessage.Visible = True
	End Sub

	Protected Sub btnSlidingExpiration_Click(sender As Object, e As System.EventArgs)
		'  Sliding Expiration, expire in 10 seconds if no access
		Cache.Insert("Name", txtName.Text, Nothing, DateTime.MaxValue, TimeSpan.FromSeconds((10)))

		lblMessage.Visible = True
	End Sub

	Protected Sub btnSubmitClass_Click(sender As Object, e As System.EventArgs)
		AppCache.Name = txtName.Text

		'  Expire in exactly 2 hours
		AppCache.SetNameToExpireAbsolutely(txtName.Text, 2)

		'  Sliding Expiration, expire in 10 seconds if no access
		AppCache.SetNameToExpireSliding(txtName.Text, 10)
	End Sub
End Class
Public Class AppCache
	Public Shared Property FullName() As String
		Get
			Return HttpContext.Current.Application("FullName").ToString()
		End Get
		Set(value As String)
			HttpContext.Current.Application("FullName") = value
		End Set
	End Property

	Public Shared Property Name() As String
		Get
			Return HttpContext.Current.Cache("Name").ToString()
		End Get
		Set(value As String)
			HttpContext.Current.Cache("Name") = value
		End Set
	End Property

	Public Shared Sub SetNameToExpireSliding(Value As String, SecondsToExpire As Integer)
		HttpContext.Current.Cache.Insert("Name", Value, Nothing, System.DateTime.MaxValue, TimeSpan.FromSeconds((SecondsToExpire)))
	End Sub

	Public Shared Sub SetNameToExpireAbsolutely(Value As String, HoursToExpire As Integer)
		HttpContext.Current.Cache.Insert("Name", Value, Nothing, System.DateTime.UtcNow.AddHours(HoursToExpire), System.Web.Caching.Cache.NoSlidingExpiration)
		'  Absolutely expire in 2 hours
	End Sub
End Class

