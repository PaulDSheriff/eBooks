﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls


Partial Public Class ViewStateTest
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)

	End Sub
	Protected Sub btnSubmit_Click(sender As Object, e As System.EventArgs)
		ViewState("First") = txtFirst.Text
		ViewState("Last") = txtLast.Text
		ViewState("Password") = txtPassword.Text

		lblResult.Text = (txtLast.Text + ", " + txtFirst.Text & " (") + txtPassword.Text & ")"
		lblStateResult.Text = ViewState.Count.ToString()
	End Sub

	Protected Sub btnStateCheck_Click(sender As Object, e As System.EventArgs)
		If ViewState("First") Is Nothing Then
			lblResult.Text = "No ViewState Setup"
		Else
			lblResult.Text = "First=" & ViewState("First").ToString() & " - " & "Last=" & ViewState("Last").ToString() & " - " & "Password=" & ViewState("Password").ToString()

			lblStateResult.Text = ViewState.Count.ToString()
		End If
	End Sub
End Class

