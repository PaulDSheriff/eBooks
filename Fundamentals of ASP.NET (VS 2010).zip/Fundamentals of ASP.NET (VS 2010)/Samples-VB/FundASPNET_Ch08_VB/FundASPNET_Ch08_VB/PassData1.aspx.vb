﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls

Partial Public Class PassData1
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)

	End Sub
	Protected Sub btnSubmit_Click(sender As Object, e As System.EventArgs)
		Dim strPage As String = Nothing

		strPage = "frmPassData2.aspx?ID={0}&Name={1}"
		strPage = String.Format(strPage, txtID.Text, txtName.Text)

		Response.Redirect(strPage)
	End Sub
End Class

