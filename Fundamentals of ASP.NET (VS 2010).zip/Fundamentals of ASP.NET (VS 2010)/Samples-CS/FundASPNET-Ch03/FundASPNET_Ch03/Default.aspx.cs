﻿using System;
using System.Web.UI;

namespace FundASPNET_Ch03
{
  public partial class Default : System.Web.UI.Page
  {
    protected void Page_Load(object sender, EventArgs e)
    {
      if (!(Page.IsPostBack))
      {
        rvalBirthDate.MinimumValue = DateTime.Now.AddYears(-70).ToShortDateString();
        rvalBirthDate.MaximumValue = DateTime.Now.AddYears(-17).ToShortDateString();
        rvalBirthDate.ErrorMessage = string.Format("Enter a date between {0} and {1}", rvalBirthDate.MinimumValue, rvalBirthDate.MaximumValue);
      }
    }

    protected void cvalState_ServerValidate(object source, System.Web.UI.WebControls.ServerValidateEventArgs args)
    {
      switch (args.Value)
      {
        case "CA":
        case "NV":
        case "AZ":
          args.IsValid = true;
          break;
        default:
          args.IsValid = false;
          break;
      }
    }

    protected void btnSave_Click(object sender, System.EventArgs e)
    {
      if (Page.IsValid)
      {
        Server.Transfer("~/Default.aspx");
      }
    }
  }
}