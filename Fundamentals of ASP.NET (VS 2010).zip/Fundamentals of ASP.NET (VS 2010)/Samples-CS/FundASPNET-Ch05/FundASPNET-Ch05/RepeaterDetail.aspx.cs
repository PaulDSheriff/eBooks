﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace fundASPNET_Ch05
{
	public partial class RepeaterDetail : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}
		protected void repProducts_ItemCommand(object source, System.Web.UI.WebControls.RepeaterCommandEventArgs e)
		{
			lblInventory.Text = string.Format("There are currently {0} units " + "of {1} in stock.", e.CommandArgument, e.CommandName);
		}
	}
}