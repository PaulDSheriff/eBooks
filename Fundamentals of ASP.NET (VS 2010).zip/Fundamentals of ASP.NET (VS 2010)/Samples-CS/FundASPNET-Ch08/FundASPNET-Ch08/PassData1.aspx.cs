﻿
namespace FundASPNET_Ch08
{
  public partial class PassData1 : System.Web.UI.Page
  {
    protected void btnSubmit_Click(object sender, System.EventArgs e)
    {
      string page = null;

      page = "PassData2.aspx?ID={0}&Name={1}";
      page = string.Format(page, txtID.Text, txtName.Text);

      Response.Redirect(page);
    }
  }
}