﻿using System.Web.UI;

namespace FundASPNET_Ch08
{
	public partial class MaintainStateTest : System.Web.UI.Page
	{		
		protected void Page_Load(object sender, System.EventArgs e)
		{
			//  Evals true first time browser hits the page	
			if (Page.IsPostBack)
			{
				lblMsg.Text = "Back again";
			}
			else
			{
				lblMsg.Text = "First Time";
			}
		}

		protected void btnSubmit_Click(object sender, System.EventArgs e)
		{
			lblResult.Text = txtEMail.Text;
		}
	}
}