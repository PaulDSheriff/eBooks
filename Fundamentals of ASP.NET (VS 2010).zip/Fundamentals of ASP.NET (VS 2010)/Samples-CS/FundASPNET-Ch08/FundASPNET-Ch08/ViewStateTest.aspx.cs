﻿using System;

namespace FundASPNET_Ch08
{
  public partial class ViewStateTest : System.Web.UI.Page
  {
    protected void btnSubmit_Click(object sender, System.EventArgs e)
    {
      ViewState["First"] = txtFirst.Text;
      ViewState["Last"] = txtLast.Text;
      ViewState["Password"] = txtPassword.Text;

      lblResult.Text = txtLast.Text + ", " + txtFirst.Text + " (" + txtPassword.Text + ")";
      lblStateResult.Text = ViewState.Count.ToString();
    }

    protected void btnStateCheck_Click(object sender, System.EventArgs e)
    {
      if (ViewState["First"] == null)
      {
        lblResult.Text = "No ViewState Setup";
      }
      else
      {
        lblResult.Text = "First=" + ViewState["First"].ToString() + " - " + "Last=" + ViewState["Last"].ToString() + " - " + "Password=" + ViewState["Password"].ToString();

        lblStateResult.Text = ViewState.Count.ToString();
      }
    }
  }
}
