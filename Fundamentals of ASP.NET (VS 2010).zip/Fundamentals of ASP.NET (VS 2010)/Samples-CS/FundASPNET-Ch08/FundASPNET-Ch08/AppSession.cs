﻿using System;
using System.Web;

namespace FundASPNET_Ch08
{
  public class AppSession
  {
    public static int CurrentEmployeeID
    {
      get { return Convert.ToInt32(HttpContext.Current.Session["CurrentEmployeeID"]); }
      set { HttpContext.Current.Session["CurrentEmployeeID"] = value; }
    }

    public static string LastMenuAccessed
    {
      get { return HttpContext.Current.Session["LastMenuAccessed"].ToString(); }
      set { HttpContext.Current.Session["LastMenuAccessed"] = value; }
    }
  }
}