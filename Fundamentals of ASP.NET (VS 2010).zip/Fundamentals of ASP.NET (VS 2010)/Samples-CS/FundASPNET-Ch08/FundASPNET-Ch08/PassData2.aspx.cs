﻿
namespace FundASPNET_Ch08
{
	public partial class PassData2 : System.Web.UI.Page
	{
		protected void Page_Load(object sender, System.EventArgs e)
		{
			if (Request.QueryString["ID"] != null)
			{
				lblID.Text = Request.QueryString["ID"];
			}
			if (Request.QueryString["Name"] != null)
			{
				lblName.Text = Request.QueryString["Name"];
			}
		}
	}
}