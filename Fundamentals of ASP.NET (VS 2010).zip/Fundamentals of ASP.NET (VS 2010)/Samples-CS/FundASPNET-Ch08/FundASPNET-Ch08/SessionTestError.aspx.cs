﻿
namespace FundASPNET_Ch08
{
	public partial class SessionTestError : System.Web.UI.Page
	{		
		protected void Page_Load(object sender, System.EventArgs e)
		{
			if (Session["Email"] != null)
				txtEmail.Text = Session["Email"].ToString();
		}

		protected void btnSubmit_Click(object sender, System.EventArgs e)
		{
			Session["Email"] = txtEmail.Text;

			Response.Redirect("Default.aspx");
		}
	}
}