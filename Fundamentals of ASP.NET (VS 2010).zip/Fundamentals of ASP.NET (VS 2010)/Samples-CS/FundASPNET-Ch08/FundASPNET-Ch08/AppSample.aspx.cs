﻿
namespace FundASPNET_Ch08
{
	public partial class AppSample : System.Web.UI.Page
	{		
		protected void Page_Load(object sender, System.EventArgs e)
		{
			if (Application["FullName"] != null)
			{
				txtName.Text = Application["FullName"].ToString();
			}
		}

		protected void btnSubmit_Click(object sender, System.EventArgs e)
		{
			Application["FullName"] = txtName.Text;
			lblMessage.Visible = true;
		}

    protected void btnSubmitClass_Click(object sender, System.EventArgs e)
    {
      AppCache.FullName = txtName.Text;
      lblMessage.Visible = true;
    }
	}
}