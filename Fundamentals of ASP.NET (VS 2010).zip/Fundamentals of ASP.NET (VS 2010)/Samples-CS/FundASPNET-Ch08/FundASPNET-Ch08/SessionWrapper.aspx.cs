﻿using System.Diagnostics;

namespace FundASPNET_Ch08
{
  public partial class SessionWrapper : System.Web.UI.Page
  {
    protected void btnSessionVars_Click(object sender, System.EventArgs e)
    {
      AppSession.CurrentEmployeeID = 10;
      AppSession.LastMenuAccessed = "SessionVars.aspx";

      Debug.WriteLine(AppSession.CurrentEmployeeID);
    }
  }
}