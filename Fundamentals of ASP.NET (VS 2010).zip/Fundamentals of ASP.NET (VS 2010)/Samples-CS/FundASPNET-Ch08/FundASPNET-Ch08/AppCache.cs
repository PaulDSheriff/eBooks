﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FundASPNET_Ch08
{
  public class AppCache
  {
    public static string FullName
    {
      get { return HttpContext.Current.Application["FullName"].ToString(); }
      set { HttpContext.Current.Application["FullName"] = value; }
    }

    public static string Name
    {
      get { return HttpContext.Current.Cache["Name"].ToString(); }
      set { HttpContext.Current.Cache["Name"] = value; }
    }

    public static void SetNameToExpireSliding(string Value, int SecondsToExpire)
    {
      HttpContext.Current.Cache.Insert("Name", Value, null, System.DateTime.MaxValue, TimeSpan.FromSeconds((SecondsToExpire)));
    }

    public static void SetNameToExpireAbsolutely(string Value, int HoursToExpire)
    {
      HttpContext.Current.Cache.Insert("Name", Value, null, System.DateTime.UtcNow.AddHours(HoursToExpire), System.Web.Caching.Cache.NoSlidingExpiration); //  Absolutely expire in 2 hours
    }
  }
}