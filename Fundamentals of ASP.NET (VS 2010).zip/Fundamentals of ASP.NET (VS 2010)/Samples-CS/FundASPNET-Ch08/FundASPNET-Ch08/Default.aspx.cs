﻿
namespace FundASPNET_Ch08
{
	public partial class Default : System.Web.UI.Page
	{
	}
}