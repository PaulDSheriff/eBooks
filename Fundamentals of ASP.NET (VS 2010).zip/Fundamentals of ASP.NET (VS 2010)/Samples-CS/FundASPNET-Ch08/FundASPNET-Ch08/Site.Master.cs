﻿using System;

namespace FundASPNET_Ch08
{
	public partial class Site : System.Web.UI.MasterPage
	{
	}
}