﻿
namespace FundASPNET_Ch08
{
	public partial class Logout : System.Web.UI.Page
	{		
		protected void Page_Load(object sender, System.EventArgs e)
		{
			Session.Abandon();
		}
	}
}