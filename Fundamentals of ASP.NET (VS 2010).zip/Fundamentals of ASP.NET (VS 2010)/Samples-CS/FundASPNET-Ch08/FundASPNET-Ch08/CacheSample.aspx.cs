﻿using System;

namespace FundASPNET_Ch08
{
  public partial class CacheSample : System.Web.UI.Page
  {
    protected void Page_Load(object sender, System.EventArgs e)
    {
      if (Cache["Name"] != null)
      {
        txtName.Text = Cache["Name"].ToString();
      }
    }

    protected void btnAppObject_Click(object sender, System.EventArgs e)
    {
      //  Just like Application Object
      Cache["Name"] = txtName.Text;

      lblMessage.Visible = true;
    }

    protected void btnTimeOut2Hours_Click(object sender, System.EventArgs e)
    {
      //  Absolutely expire in 2 hours
      Cache.Insert("Name", txtName.Text,
        null, DateTime.UtcNow.AddHours(2),
        System.Web.Caching.Cache.NoSlidingExpiration);

      lblMessage.Visible = true;
    }

    protected void btnSlidingExpiration_Click(object sender, System.EventArgs e)
    {
      //  Sliding Expiration, expire in 10 seconds if no access
      Cache.Insert("Name", txtName.Text,
        null, DateTime.MaxValue,
        TimeSpan.FromSeconds((10)));

      lblMessage.Visible = true;
    }

    protected void btnSubmitClass_Click(object sender, System.EventArgs e)
    {
      AppCache.Name = txtName.Text;

      //  Expire in exactly 2 hours
      AppCache.SetNameToExpireAbsolutely(txtName.Text, 2);

      //  Sliding Expiration, expire in 10 seconds if no access
      AppCache.SetNameToExpireSliding(txtName.Text, 10);
    }
  }
}