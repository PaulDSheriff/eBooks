﻿using System.Web.UI;

namespace FundASPNET_Ch07
{
	public partial class AdRotator : System.Web.UI.Page
	{		
		protected void Page_Load(object sender, System.EventArgs e)
		{
			if (!(Page.IsPostBack))
			{
				rblFilter.Items.FindByText("Both").Selected = true;
			}
		}

		protected void rblFilter_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			string filter = null;

			filter = rblFilter.SelectedItem.Text;
			if (filter == "Both")
			{
				filter = string.Empty;
			}

			adEmp.KeywordFilter = filter;
		}
	}
}