﻿
namespace FundASPNET_Ch07
{
	public partial class Calendar : System.Web.UI.Page
	{
		protected void Page_Load(object sender, System.EventArgs e)
		{
			cal.SelectedDate = cal.TodaysDate;
		}

		protected void cal_SelectionChanged(object sender, System.EventArgs e)
		{
			lblDate.Text = string.Format("Selected date: {0:d}", cal.SelectedDate);
		}

		protected void cal_VisibleMonthChanged(object sender, System.Web.UI.WebControls.MonthChangedEventArgs e)
		{
			lblMonth.Text = string.Format("Visible Month: {0:MMMM yyyy}", e.NewDate);
		}
	}
}