﻿using System;

namespace FundASPNET_Ch07
{
	public partial class AdRotatorClickThru : System.Web.UI.Page
	{
	}
}