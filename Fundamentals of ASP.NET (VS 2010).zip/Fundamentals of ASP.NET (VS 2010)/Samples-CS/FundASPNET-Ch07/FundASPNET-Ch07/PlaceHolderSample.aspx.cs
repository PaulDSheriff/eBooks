﻿using System.Web.UI;
using System.Web.UI.WebControls;

namespace FundASPNET_Ch07
{
	public partial class PlaceHolderSample : System.Web.UI.Page
	{
		protected void Page_Load(object sender, System.EventArgs e)
		{
			if (!(Page.IsPostBack))
			{
				LoadPlaceHolder();
			}
		}

		private void LoadPlaceHolder()
		{
			TextBox txt = new TextBox();
			Literal lit = new Literal();
			Button btn = new Button();
			HyperLink hyp = new HyperLink();

			txt.Text = string.Empty;
			txt.Width = ((System.Web.UI.WebControls.Unit)(200));
			plcHold.Controls.Add(txt);

			btn.Text = "Click Me!";
			plcHold.Controls.Add(btn);

			lit.Text = "<br />";
			plcHold.Controls.Add(lit);

			hyp.NavigateUrl = "LiteralControl.aspx";
			hyp.Text = "Literal Control Sample Page";
			hyp.ID = "hypSample";
			plcHold.Controls.Add(hyp);
		}
	}
}
