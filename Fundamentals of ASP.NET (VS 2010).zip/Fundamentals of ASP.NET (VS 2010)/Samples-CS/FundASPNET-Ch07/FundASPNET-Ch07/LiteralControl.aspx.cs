﻿using System;

namespace FundASPNET_Ch07
{
	public partial class LiteralControl : System.Web.UI.Page
	{
		protected void btnAssign_Click(System.Object sender, System.EventArgs e)
		{
			litHTML.Text = txtHTML.Text;
		}
	}
}