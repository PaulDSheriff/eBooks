﻿using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace FundASPNET_Ch07
{
  public partial class ListControls : System.Web.UI.Page
  {
    protected void btnRegionCheckList_Click(System.Object sender, System.EventArgs e)
    {
      RegionLoad(clstRegions);
    }

    protected void btnRegionRadioList_Click(System.Object sender, System.EventArgs e)
    {
      RegionLoad(rlstRegions);
    }

    private void RegionLoad(ListControl ctlRegions)
    {
      string strSQL = null;
      DataSet ds = new DataSet();
      SqlDataAdapter da = null;

      strSQL = "SELECT RegionID, RegionDescription " + "FROM Region";
      da = new SqlDataAdapter(strSQL, AppConfig.ConnectionString);
      da.Fill(ds);

      ctlRegions.DataTextField = "RegionDescription";
      ctlRegions.DataValueField = "RegionID";
      ctlRegions.DataSource = ds;
      ctlRegions.DataBind();
    }
  }
}

