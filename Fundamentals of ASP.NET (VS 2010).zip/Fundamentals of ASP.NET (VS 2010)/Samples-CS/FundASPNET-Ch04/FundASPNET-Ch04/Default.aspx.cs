﻿
namespace FundASPNET_Ch04
{
	public partial class Default : System.Web.UI.Page
	{
	}
}