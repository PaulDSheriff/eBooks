﻿using System;

namespace FundASPNET_Ch04
{
	public partial class DataBinding : System.Web.UI.Page
	{
	}
}