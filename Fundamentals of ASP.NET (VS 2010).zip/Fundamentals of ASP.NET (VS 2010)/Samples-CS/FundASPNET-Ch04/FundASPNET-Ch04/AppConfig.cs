﻿using System.Configuration;

namespace FundASPNET_Ch04
{
  public class AppConfig
  {
    public static string ConnectionString
    {
      get { return ConfigurationManager.ConnectionStrings["NorthwindConnectionString"].ConnectionString; }
    }
  }
}