﻿
namespace FundASPNET_Ch04
{
	public partial class GridView : System.Web.UI.Page
	{
	}
}