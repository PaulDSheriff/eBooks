﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FundASPNET_Ch04
{
	public partial class GridViewDetailsView : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}
		protected void grdProducts_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			DetailsView1.DataSourceID = "SqlDataSource2";
			DetailsView1.DataBind();
		}

		protected void DetailsView1_ItemInserted(object sender, System.Web.UI.WebControls.DetailsViewInsertedEventArgs e)
		{
			e.KeepInInsertMode = false;
			grdProducts.DataBind();
		}

		protected void DetailsView1_ItemInserting(object sender, System.Web.UI.WebControls.DetailsViewInsertEventArgs e)
		{
			// This event procedure must be defined, but does not have to do anything
		}

		protected void DetailsView1_ItemUpdated(object sender, System.Web.UI.WebControls.DetailsViewUpdatedEventArgs e)
		{
			grdProducts.DataBind();
		}

		protected void lnkAdd_Click(object sender, System.EventArgs e)
		{
			//  Have to bind before we change the mode if it is not already bound
			DetailsView1.DataSourceID = "SqlDataSource2";
			DetailsView1.DataBind();
			DetailsView1.ChangeMode(DetailsViewMode.Insert);
		}
	}
}