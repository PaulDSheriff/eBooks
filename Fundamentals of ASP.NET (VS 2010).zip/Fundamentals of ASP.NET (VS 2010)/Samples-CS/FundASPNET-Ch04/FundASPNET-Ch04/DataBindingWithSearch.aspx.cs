﻿using System;

namespace FundASPNET_Ch04
{
  public partial class DataBindingWithSearch : System.Web.UI.Page
  {
    protected void btnSearch_Click(object sender, System.EventArgs e)
    {
      RebindData();
    }

    private void RebindData()
    {
      grdProducts.DataBind();
    }
  }
}