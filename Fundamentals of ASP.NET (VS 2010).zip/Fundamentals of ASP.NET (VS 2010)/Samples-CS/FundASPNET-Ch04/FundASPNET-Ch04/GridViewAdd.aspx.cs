﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FundASPNET_Ch04
{
  public partial class GridViewAdd : System.Web.UI.Page
  {
    protected void Page_Load(object sender, System.EventArgs e)
    {
      if (!(Page.IsPostBack))
      {
        ViewState["Adding"] = false;
      }
    }

    protected void lnkAdd_Click(object sender, System.EventArgs e)
    {
      DataSet ds = new DataSet();
      SqlDataAdapter da = null;
      DataRow dr = null;

      da = new SqlDataAdapter(dsProducts.SelectCommand, dsProducts.ConnectionString);

      ViewState["Adding"] = true;
      da.Fill(ds);

      //  Get a Blank Row
      dr = ds.Tables[0].NewRow();
      //  Always make it appear at the first row in the grid
      ds.Tables[0].Rows.InsertAt(dr, 0);

      //  Use Blank Row as DataSource to Grid
      grdProducts.DataSourceID = string.Empty;
      grdProducts.DataSource = ds;
      grdProducts.DataBind();

      //  Edit the first item
      grdProducts.EditIndex = 0;
    }

    protected void grdProducts_RowCancelingEdit(object sender, System.Web.UI.WebControls.GridViewCancelEditEventArgs e)
    {
      grdProducts.EditIndex = -1;
      grdProducts.DataSourceID = "dsProducts";
      grdProducts.DataBind();
    }

    protected void grdProducts_RowUpdating(object sender, System.Web.UI.WebControls.GridViewUpdateEventArgs e)
    {
      if (Convert.ToBoolean(ViewState["Adding"]))
      {
        DataAdd();

        e.Cancel = true;
        ViewState["Adding"] = false;

        grdProducts.EditIndex = -1;
        grdProducts.DataSourceID = "dsProducts";
        grdProducts.DataBind();
      }
    }

    private void DataAdd()
    {
      int intRows = 0;
      SqlCommand cmd = new SqlCommand();
      GridViewRow row = grdProducts.Rows[0];

      cmd.CommandText = dsProducts.InsertCommand;
      cmd.Connection = new SqlConnection(AppConfig.ConnectionString);

      cmd.Parameters.Add(new SqlParameter("ProductName", SqlDbType.VarChar));
      cmd.Parameters.Add(new SqlParameter("SupplierID", SqlDbType.Int));
      cmd.Parameters.Add(new SqlParameter("CategoryID", SqlDbType.Int));
      cmd.Parameters.Add(new SqlParameter("QuantityPerUnit", SqlDbType.NVarChar));
      cmd.Parameters.Add(new SqlParameter("UnitPrice", SqlDbType.Money));
      cmd.Parameters.Add(new SqlParameter("UnitsInStock", SqlDbType.SmallInt));
      cmd.Parameters.Add(new SqlParameter("UnitsOnOrder", SqlDbType.SmallInt));
      cmd.Parameters.Add(new SqlParameter("ReorderLevel", SqlDbType.SmallInt));
      cmd.Parameters.Add(new SqlParameter("Discontinued", SqlDbType.Bit));

      cmd.Parameters["ProductName"].Value = ((TextBox)(row.Cells[2].Controls[0])).Text;
      cmd.Parameters["SupplierID"].Value = ((DropDownList)(row.Cells[3].Controls[1])).SelectedValue;
      cmd.Parameters["CategoryID"].Value = ((DropDownList)(row.Cells[4].Controls[1])).SelectedValue;
      cmd.Parameters["QuantityPerUnit"].Value = ((TextBox)(row.Cells[5].Controls[0])).Text;
      cmd.Parameters["UnitPrice"].Value = ((TextBox)(row.Cells[6].Controls[0])).Text;
      cmd.Parameters["UnitsInStock"].Value = ((TextBox)(row.Cells[7].Controls[0])).Text;
      cmd.Parameters["UnitsOnOrder"].Value = ((TextBox)(row.Cells[8].Controls[0])).Text;
      cmd.Parameters["ReorderLevel"].Value = ((TextBox)(row.Cells[9].Controls[0])).Text;
      cmd.Parameters["Discontinued"].Value = ((CheckBox)(row.Cells[10].Controls[0])).Checked;

      cmd.Connection.Open();
      intRows = cmd.ExecuteNonQuery();

      cmd.Connection.Close();
      cmd.Connection.Dispose();
    }

  }
}