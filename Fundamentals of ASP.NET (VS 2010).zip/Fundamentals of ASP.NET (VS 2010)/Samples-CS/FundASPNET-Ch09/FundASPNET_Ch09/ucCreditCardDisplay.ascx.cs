﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FundASPNET_Ch09
{
	public partial class ucCreditCardDisplay : System.Web.UI.UserControl
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}
		public void SetUserData(PDSACreditCard cc)
		{
			SetUserData(cc, false);
		}

		public void SetUserData(PDSACreditCard cc, bool DisplayRealCCNumber)
		{
			lblCCType.Text = cc.CreditCardType;
			if (DisplayRealCCNumber)
			{
				lblCCNumber.Text = cc.CreditCardNumber;
			}
			else
			{
				if (cc.CreditCardNumber.Length > 4)
				{
					lblCCNumber.Text = "***************" + cc.CreditCardNumber.Substring(cc.CreditCardNumber.Length - 4);
				}
				else
				{
					lblCCNumber.Text = "***************";
				}
			}
			lblName.Text = cc.NameOnCard;
			lblExpDate.Text = cc.ExpMonth + "/" + cc.ExpYear;
			lblPostalCode.Text = cc.BillingPostalCode;
		}
	}
}