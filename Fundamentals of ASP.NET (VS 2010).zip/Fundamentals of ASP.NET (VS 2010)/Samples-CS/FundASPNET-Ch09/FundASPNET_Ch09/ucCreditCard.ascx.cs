﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace FundASPNET_Ch09
{
	public partial class ucCreditCard : System.Web.UI.UserControl
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!(Page.IsPostBack))
			{
				CardTypesLoad();
				MonthLoad();
				YearLoad();
			}

		}
		private void CardTypesLoad()
		{
			DataSet ds = new DataSet();

			ds.ReadXml(Server.MapPath("~/Xml-Common/CreditCardTypes.xml"));

			ddlCreditCards.DataTextField = "Name";
			ddlCreditCards.DataValueField = "Name";
			ddlCreditCards.DataSource = ds;
			ddlCreditCards.DataBind();
		}


		private void MonthLoad()
		{
			int intLoop = 0;

			for (intLoop = 1; intLoop <= 12; intLoop++)
			{
				ddlMonth.Items.Add(intLoop.ToString() + "-" + GetMonthName(intLoop));
			}
		}

		private void YearLoad()
		{
			int intLoop = 0;

			for (intLoop = DateTime.Now.Year; intLoop <= (DateTime.Now.Year + 12); intLoop++)
			{
				ddlYear.Items.Add(intLoop.ToString());
			}
		}

		private string GetMonthName(int Value)
		{
			System.Globalization.DateTimeFormatInfo dtfi = new System.Globalization.DateTimeFormatInfo();
			string[] arr = null;

			arr = dtfi.MonthNames;

			return arr[Value - 1];
		}

		public PDSACreditCard GetUserData()
		{
			PDSACreditCard cc = new PDSACreditCard();
			string strCC = null;

			strCC = txtCardNumber.Text.Trim();
			strCC = strCC.Replace(" ", "");
			strCC = strCC.Replace("-", "");
			strCC = strCC.Replace("/", "");
			strCC = strCC.Replace(@"\", "");
			strCC = strCC.Replace(".", "");

			cc.CreditCardNumber = strCC;
			if (ddlCreditCards.SelectedItem != null)
				cc.CreditCardType = ddlCreditCards.SelectedItem.Text;
			cc.CVCode = txtCVCode.Text;
			cc.NameOnCard = txtName.Text;
			if (ddlMonth.SelectedItem != null)
				cc.ExpMonth = ddlMonth.SelectedItem.Text;
			if (ddlYear.SelectedItem != null)
				cc.ExpYear = ddlYear.SelectedItem.Text;
			cc.BillingPostalCode = txtZipCode.Text;

			return cc;
		}

		public void SetUserData(PDSACreditCard cc)
		{
			string strCC = null;

			strCC = cc.CreditCardNumber.Trim();

			if (strCC.Length > 4)
			{
				txtCardNumber.Text = "**********" + strCC.Substring(strCC.Length - 4);
			}
			else
			{
				if (strCC.Length == 0)
				{
					txtCardNumber.Text = "";
				}
				else
				{
					txtCardNumber.Text = "*********************";
				}
			}
			PDSAWebList.DropDownFindByText(ref ddlCreditCards, cc.CreditCardType);
			txtName.Text = cc.NameOnCard;
			txtCVCode.Text = cc.CVCode;
			PDSAWebList.DropDownFindByText(ref ddlMonth, cc.ExpMonth);
			PDSAWebList.DropDownFindByText(ref ddlYear, cc.ExpYear);
			txtZipCode.Text = cc.BillingPostalCode;
		}
	}
}