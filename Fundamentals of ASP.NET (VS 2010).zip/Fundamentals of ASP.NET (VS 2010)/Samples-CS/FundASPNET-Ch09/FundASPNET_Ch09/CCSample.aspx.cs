﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FundASPNET_Ch09
{
	public partial class CCSample : System.Web.UI.Page
	{
		protected void btnSubmit_Click(object sender, EventArgs e)
		{
			PDSACreditCard cc = null;

			cc = this.ucCreditCard1.GetUserData();

			Session["PDSACC"] = cc;

			Response.Redirect("CCDisplay.aspx");
		}
	}
}