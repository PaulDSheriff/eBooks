﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FundASPNET_Ch09
{
	public partial class CCDisplay : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			PDSACreditCard cc = null;

			if (Session["PDSACC"] != null)
			{
				cc = ((PDSACreditCard)(Session["PDSACC"]));

			this.ucCreditCardDisplay1.SetUserData(cc);
			}

		}
	}
}