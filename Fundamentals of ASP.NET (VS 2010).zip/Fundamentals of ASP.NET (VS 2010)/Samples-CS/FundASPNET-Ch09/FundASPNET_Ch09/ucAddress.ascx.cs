﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FundASPNET_Ch09
{
	public partial class ucAddress : System.Web.UI.UserControl
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!(Page.IsPostBack))
			{
				this.InitControlVisiblity();
				LoadDropDowns();
			}

		}
		private void InitControlVisiblity()
		{
			this.divPDSAAddrAddress3.Visible = false;
			this.divPDSAAddrState.Visible = true;
			this.divPDSAAddrVillage.Visible = false;
			this.lblZipHypen.Visible = true;
			this.txtZipExension.Visible = true;
			this.lblZipPostal.Text = "Zip Code";
			this.lblStateProvince.Text = "State";
			this.lblZipHypen.Visible = true;
			this.txtZipExension.Visible = true;
		}

		public void LoadDropDowns()
		{
			if (ddlCountry.Items.Count == 0)
			{
				CountryLoad();
				ShowCountry();
				ShowDetails(PDSAAddress.PDSAAddressTypeEnum.US);
			}
		}

		private void CountryLoad()
		{
			ddlCountry.DataTextField = "sName";
			ddlCountry.DataValueField = "sCode";
			ddlCountry.DataSource = PDSADataCommon.GetCountries().Tables[0];
			ddlCountry.DataBind();
		}

		private void StateLoad()
		{
			ddlStateProvince.DataTextField = "StateName";
			ddlStateProvince.DataValueField = "StateCode";
			this.ddlStateProvince.DataSource = PDSADataCommon.GetUSStates().Tables[0];
			this.ddlStateProvince.DataBind();
		}

		private PDSAAddress.PDSAAddressTypeEnum AddressType
		{
			get
			{
				if (this.ddlCountry.SelectedItem.Value == "USA")
				{
					return PDSAAddress.PDSAAddressTypeEnum.US;
				}
				else if (this.ddlCountry.SelectedItem.Value == "CAN")
				{
					return PDSAAddress.PDSAAddressTypeEnum.Canadian;
				}
				else if (this.ddlCountry.SelectedItem.Value == "GBR")
				{
					return PDSAAddress.PDSAAddressTypeEnum.UK;
				}
				else
				{
					return PDSAAddress.PDSAAddressTypeEnum.Other;
				}
			}
		}

		protected void ddlCountry_SelectedIndexChanged(System.Object sender, System.EventArgs e)
		{
			this.ShowDetails(this.AddressType);
		}


		public void ShowCountry()
		{
			this.divPDSAAddrCountry.Visible = true;
			this.divPDSAAddrDetails.Visible = true;
		}

		public void ShowDetails(PDSAAddress.PDSAAddressTypeEnum addressType)
		{
			this.divPDSAAddrDetails.Visible = true;

			ddlStateProvince.DataSource = null;
			ddlStateProvince.Items.Clear();
			if (this.AddressType ==
				PDSAAddress.PDSAAddressTypeEnum.Other)
			{
				this.divPDSAAddrVillage.Visible = false;
				this.lblZipPostal.Text = "Postal Code";
				this.divPDSAAddrAddress3.Visible = true;
				this.divPDSAAddrState.Visible = false;
				this.lblZipHypen.Visible = false;
				this.txtZipExension.Visible = false;
				rfvStateProvince.Enabled = false;
			}
			else if (this.AddressType ==
			  PDSAAddress.PDSAAddressTypeEnum.UK)
			{
				this.divPDSAAddrVillage.Visible = true;
				this.lblZipPostal.Text = "Postal Code";
				this.lblZipHypen.Visible = false;
				this.txtZipExension.Visible = false;
				this.divPDSAAddrState.Visible = false;
				rfvStateProvince.Enabled = false;
			}
			else if (this.AddressType ==
			   PDSAAddress.PDSAAddressTypeEnum.Canadian)
			{
				this.divPDSAAddrVillage.Visible = false;
				this.lblZipPostal.Text = "Postal Code";
				this.lblStateProvince.Text = "Province";
				this.lblZipHypen.Visible = false;
				this.txtZipExension.Visible = false;
				ddlStateProvince.DataTextField = "Name";
				ddlStateProvince.DataValueField = "PostalAbbr";
				this.ddlStateProvince.DataSource =
				   PDSADataCommon.GetCanadianProvinces().Tables[0];
				this.ddlStateProvince.DataBind();
				rfvStateProvince.Enabled = false;
			}
			else if (this.AddressType ==
			  PDSAAddress.PDSAAddressTypeEnum.US)
			{
				this.divPDSAAddrAddress3.Visible = false;
				this.divPDSAAddrState.Visible = true;
				this.divPDSAAddrVillage.Visible = false;
				this.lblZipHypen.Visible = true;
				this.txtZipExension.Visible = true;
				this.lblZipPostal.Text = "Zip Code";
				this.lblStateProvince.Text = "State";
				this.lblZipHypen.Visible = true;
				this.txtZipExension.Visible = true;
				ddlStateProvince.DataTextField = "StateName";
				ddlStateProvince.DataValueField = "StateCode";
				this.ddlStateProvince.DataSource =
				  PDSADataCommon.GetUSStates().Tables[0];
				this.ddlStateProvince.DataBind();
				rfvStateProvince.Enabled = true;
			}
		}

		public PDSAAddress GetUserData()
		{
			PDSAAddress address = new PDSAAddress();

			address.Address1 = this.txtAddress1.Text;
			address.Address2 = this.txtAddress2.Text;
			address.Address3 = this.txtAddress3.Text;
			address.City = this.txtCity.Text;

			if (divPDSAAddrState.Visible)
			{
				address.StateCode = this.ddlStateProvince.SelectedItem.Value;
				address.StateName = this.ddlStateProvince.SelectedItem.Text;
			}
			else
			{
				address.StateCode = "";
				address.StateName = "";
			}
			address.CountryCode = this.ddlCountry.SelectedItem.Value;
			address.CountryName = this.ddlCountry.SelectedItem.Text;
			address.PostalCode = this.txtZipPostal.Text;

			if (this.txtZipExension.Text.Length > 0)
			{
				address.PostalCodeExt = this.txtZipExension.Text;
			}
			address.Type = this.AddressType;

			return address;
		}

		public void SetUserData(PDSAAddress address)
		{

			this.txtAddress1.Text = address.Address1;
			this.txtAddress2.Text = address.Address2;
			this.txtAddress3.Text = address.Address3;
			this.txtCity.Text = address.City;

			if (address.StateCode.Trim() != "")
			{
				ddlStateProvince.SelectedIndex = -1;
				PDSAWebList.DropDownFindByValue(ref ddlStateProvince, address.StateCode);
			}
			else if (address.StateName.Trim() != "")
			{
				ddlStateProvince.SelectedIndex = -1;
				PDSAWebList.DropDownFindByText(ref ddlStateProvince, address.StateName);
			}
			if (address.CountryCode.Trim() != "")
			{
				ddlCountry.SelectedIndex = -1;
				PDSAWebList.DropDownFindByValue(ref ddlCountry, address.CountryCode);
			}
			else if (address.CountryName.Trim() != "")
			{
				ddlCountry.SelectedIndex = -1;
				PDSAWebList.DropDownFindByValue(ref ddlCountry, address.CountryName);
			}
			this.txtZipPostal.Text = address.PostalCode;

			this.txtZipExension.Text = address.PostalCodeExt;
		}
	}
}