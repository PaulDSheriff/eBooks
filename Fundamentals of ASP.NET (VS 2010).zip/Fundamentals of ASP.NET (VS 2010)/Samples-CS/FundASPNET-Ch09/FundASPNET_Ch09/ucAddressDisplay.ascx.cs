﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;

namespace FundASPNET_Ch09
{
	public partial class ucAddressDisplay : System.Web.UI.UserControl
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}
		public void SetUserData(PDSAAddress address)
		{
			StringBuilder sb = new StringBuilder(1024);

			sb.Append(address.Address1);
			sb.Append("<br />");
			if (address.Address2.Trim() != string.Empty)
			{
				sb.Append(address.Address2);
				sb.Append("<br />");
			}
			if (address.Address3.Trim() != string.Empty)
			{
				sb.Append(address.Address3);
				sb.Append("<br />");
			}
			if (address.City.Trim() != string.Empty)
			{
				sb.Append(address.City);
			}
			if (address.Village.Trim() != string.Empty)
			{
				sb.Append(address.Village);
			}
			if (address.StateName.Trim() != string.Empty)
			{
				sb.Append(", " + address.StateName);
			}
			else if (address.StateCode.Trim() != string.Empty)
			{
				sb.Append(", " + address.StateCode);
			}
			if (address.PostalCode.Trim() != string.Empty)
			{
				sb.Append(" " + address.PostalCode);
				if (address.PostalCodeExt != string.Empty)
				{
					sb.Append("-" + address.PostalCodeExt);
				}
				sb.Append("<br />");
			}
			if (address.CountryName.Trim() != string.Empty)
			{
				sb.Append(address.CountryName);
				sb.Append("<br />");
			}
			else if (address.CountryCode.Trim() != string.Empty)
			{
				sb.Append(address.CountryCode);
				sb.Append("<br />");
			}

			lblAddress.Text = sb.ToString();
		}
	}
}