using System;

namespace FundASPNET_Ch09
{
  [Serializable()]
  public class PDSACreditCard
  {
    private string _CreditCardType = "Visa";
    private string mstrNameOnCard = string.Empty;
    private string mstrCreditCardNumber = string.Empty;
    private string mstrExpMonth = string.Empty;
    private string mstrExpYear = string.Empty;
    private string mstrCVCode = string.Empty;
    private string mstrBillingPostalCode = string.Empty;

    public string BillingPostalCode
    {
      get { return mstrBillingPostalCode; }
      set { mstrBillingPostalCode = value; }
    }

    public string CreditCardType
    {
      get { return _CreditCardType; }
      set { _CreditCardType = value; }
    }

    public string NameOnCard
    {
      get { return mstrNameOnCard; }
      set { mstrNameOnCard = value; }
    }

    public string CreditCardNumber
    {
      get { return mstrCreditCardNumber; }
      set { mstrCreditCardNumber = value; }
    }

    public string ExpMonth
    {
      get { return mstrExpMonth; }
      set { mstrExpMonth = value; }
    }

    public string ExpYear
    {
      get { return mstrExpYear; }
      set { mstrExpYear = value; }
    }

    public string CVCode
    {
      get { return mstrCVCode; }
      set { mstrCVCode = value; }
    }
  }
}