﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FundASPNET_Ch09
{
	public class PDSAAddress
	{
		public enum PDSAAddressTypeEnum : int
		{
			US,
			Canadian,
			UK,
			Other,
		}

		private Guid mObjectId = Guid.NewGuid();
		private PDSAAddressTypeEnum mType = PDSAAddressTypeEnum.US;
		private string mstrAddress1 = string.Empty;
		private string mstrAddress2 = string.Empty;
		private string mstrAddress3 = string.Empty;
		private string mstrCity = string.Empty;
		private string mstrVillage = string.Empty;
		private int mintStateId = int.MinValue;
		private string mstrStateCode = string.Empty;
		private string mstrStateName = string.Empty;
		private int mintCountryId = int.MinValue;
		private string mstrCountryCode = string.Empty;
		private string mstrCountryName = string.Empty;
		private string mstrPostalCode = string.Empty;
		private string mstrPostalCodeExt = string.Empty;

		public Guid ObjectId
		{
			get { return this.mObjectId; }
		}

		public PDSAAddressTypeEnum Type
		{
			get { return this.mType; }
			set { this.mType = value; }
		}

		public string Address1
		{
			get { return this.mstrAddress1; }
			set { this.mstrAddress1 = value; }
		}

		public string Address2
		{
			get { return this.mstrAddress2; }
			set { this.mstrAddress2 = value; }
		}

		public string Address3
		{
			get { return this.mstrAddress3; }
			set { this.mstrAddress3 = value; }
		}

		public string City
		{
			get { return this.mstrCity; }
			set { this.mstrCity = value; }
		}

		public string Village
		{
			get { return this.mstrVillage; }
			set { this.mstrVillage = value; }
		}

		public int StateId
		{
			get { return this.mintStateId; }
			set { this.mintStateId = value; }
		}

		public string StateCode
		{
			get { return this.mstrStateCode; }
			set { this.mstrStateCode = value; }
		}

		public string StateName
		{
			get { return this.mstrStateName; }
			set { this.mstrStateName = value; }
		}

		public int CountryId
		{
			get { return this.mintCountryId; }
			set { this.mintCountryId = value; }
		}

		public string CountryCode
		{
			get { return this.mstrCountryCode; }
			set { this.mstrCountryCode = value; }
		}

		public string CountryName
		{
			get { return this.mstrCountryName; }
			set { this.mstrCountryName = value; }
		}

		public string PostalCode
		{
			get { return this.mstrPostalCode; }
			set { this.mstrPostalCode = value; }
		}

		public string PostalCodeExt
		{
			get { return this.mstrPostalCodeExt; }
			set { this.mstrPostalCodeExt = value; }
		}

		public virtual bool Validate()
		{
			bool isValid = true;

			//  Require Address1
			if (this.mstrAddress1.Length == 0)
			{
				isValid = false;
			}

			//  Require City
			if (this.mstrCity.Length == 0)
			{
				isValid = false;
			}

			// Require State for Canada and US
			if (this.mType == PDSAAddressTypeEnum.Canadian | this.mType == PDSAAddressTypeEnum.US)
			{
				if (this.mstrStateName.Length == 0 & this.mstrStateCode.Length == 0 & this.mintStateId > 0)
				{
					isValid = false;
				}
			}

			//  Require Postal Code
			if (this.mstrPostalCode.Length == 0)
			{
				isValid = false;
			}

			return isValid;
		}

		public string GetFullAddress()
		{
			// Returns an strAddr in the following format
			// 1234 Street
			// PO Box 1234
			// Route(4)
			// City, State 90210-1234

			string strAddr = null;

			strAddr = this.mstrAddress1;

			if (this.mstrAddress2.Length > 0)
			{
				strAddr += "\r\n" + this.mstrAddress2;
			}

			if (this.mstrAddress3.Length > 0)
			{
				strAddr += "\r\n" + this.mstrAddress3;
			}

			strAddr += "\r\n" + this.mstrCity;

			if (this.mType != PDSAAddressTypeEnum.Other)
			{
				if (this.mstrStateName.Trim() != "")
				{
					strAddr += ", " + this.mstrStateName;
				}
				else
				{
					strAddr += ", " + this.mstrStateCode;
				}
			}

			strAddr += "  " + this.mstrPostalCode;

			if (this.mType != PDSAAddressTypeEnum.Other & this.mstrPostalCodeExt.Trim() != string.Empty)
			{
				strAddr += " - " + this.mstrPostalCodeExt;
			}

			return strAddr;
		}

		public override string ToString()
		{
			return GetFullAddress();
		}
	}
}