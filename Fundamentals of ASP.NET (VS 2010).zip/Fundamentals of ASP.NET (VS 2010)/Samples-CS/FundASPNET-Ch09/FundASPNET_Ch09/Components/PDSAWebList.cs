using System.Web;
using System.Web.UI.WebControls;

namespace FundASPNET_Ch09
{
  public class PDSAWebList
  {
    public static void DropDownFindByText(ref DropDownList ddl, string Value)
    {
      ListItem di = null;

      di = ddl.Items.FindByText(Value);
      if (!((di == null)))
      {
        di.Selected = true;
      }
    }

    public static void DropDownFindByValue(ref DropDownList ddl, int Value)
    {
      ListItem di = null;

      di = ddl.Items.FindByValue(Value.ToString());
      if (!((di == null)))
      {
        di.Selected = true;
      }
    }

    public static void DropDownFindByValue(ref DropDownList ddl, string Value)
    {
      ListItem di = null;

      di = ddl.Items.FindByValue(Value);
      if (!((di == null)))
      {
        di.Selected = true;
      }
    }
  }
}