﻿using System.Web.UI.WebControls;

namespace FundASPNET_Ch06
{
  public partial class Default : System.Web.UI.Page
  {
    protected void dlstEmps_CancelCommand(object source, System.Web.UI.WebControls.DataListCommandEventArgs e)
    {
      dlstEmps.EditItemIndex = -1;
      dlstEmps.DataBind();
    }

    protected void dlstEmps_EditCommand(object source, System.Web.UI.WebControls.DataListCommandEventArgs e)
    {
      dlstEmps.EditItemIndex = e.Item.ItemIndex;
      dlstEmps.DataBind();
    }

    protected void dlstEmps_UpdateCommand(object source, System.Web.UI.WebControls.DataListCommandEventArgs e)
    {
      dsEmps.UpdateParameters["EmployeeID"].DefaultValue = ((LinkButton)(e.Item.FindControl("btnUpdate"))).CommandArgument;
      dsEmps.UpdateParameters["LastName"].DefaultValue = ((TextBox)(e.Item.FindControl("LastName"))).Text;
      dsEmps.UpdateParameters["FirstName"].DefaultValue = ((TextBox)(e.Item.FindControl("FirstName"))).Text;
      dsEmps.UpdateParameters["HomePhone"].DefaultValue = ((TextBox)(e.Item.FindControl("HomePhone"))).Text;
      dsEmps.Update();

      dlstEmps.EditItemIndex = -1;
      dlstEmps.DataBind();
    }
  }
}