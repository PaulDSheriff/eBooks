﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_CommonLibrary
{
	public abstract class PersonAbstact
	{
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public int Age { get; set; }

		public string FirstLast()
		{
			return FirstName + " " + LastName;
		}

		public string LastFirst()
		{
			return LastName + ", " + FirstName;
		}

		public abstract string Format();
	}
}
