﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_CommonLibrary
{
	public interface IPerson
	{
		string FirstName { get; set; }
		string LastName { get; set; }
		int Age { get; set; }

		string FirstLast();
		string LastFirst();

		string Format();
	}
}
