﻿using System.Windows;

using CS_CommonLibrary;

namespace CS_ClassLibrary
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private void btnPerson_Click(object sender, RoutedEventArgs e)
		{
			Person per = new Person();

			per.FirstName = "John";
			per.LastName = "Smith";
			per.Age = 22;

			MessageBox.Show(per.FirstName);
		}

		private void btnEmployee_Click(object sender, RoutedEventArgs e)
		{
			Employee emp = new Employee();

			// The following properties are inherited from "Person"
			emp.FirstName = "Jack";
			emp.LastName = "Bean";
			emp.Age = 43;
			// Employee adds on the following properties
			emp.EmployeeId = "A1";
			emp.Wage = 33;
		}

		private void btnCustomer_Click(object sender, RoutedEventArgs e)
		{
			Customer cust = new Customer();

			// The following properties are inherited from "Person"
			cust.FirstName = "Jane";
			cust.LastName = "Doe";
			cust.Age = 32;
			// Customer adds on the following properties
			cust.CustomerId = 123;
			cust.CompanyName = "Jane Doe Enterprises";
		}

		private void btnPersonFormat_Click(object sender, RoutedEventArgs e)
		{
			Person per = new Person();

			per.FirstName = "John";
			per.LastName = "Smith";
			per.Age = 22;

			MessageBox.Show(per.FirstLast());
			MessageBox.Show(per.Format());
		}

		private void btnEmployeeFormat_Click(object sender, RoutedEventArgs e)
		{
			Employee emp = new Employee();

			emp.FirstName = "Jack";
			emp.LastName = "Bean";
			emp.Age = 43;
			emp.Wage = 33;

			MessageBox.Show(emp.Format());
		}

		private void btnCustomerFormat_Click(object sender, RoutedEventArgs e)
		{
			Customer cust = new Customer();

			// The following properties are inherited from "Person"
			cust.FirstName = "Jane";
			cust.LastName = "Doe";
			cust.Age = 32;
			// Customer adds on the following properties
			cust.CustomerId = 123;
			cust.CompanyName = "Jane Doe Enterprises";

			MessageBox.Show(cust.Format());
		}

		private void btnInterfaceSample_Click(object sender, RoutedEventArgs e)
		{
			IPerson x;

			x = new Person();
			x.FirstName = "John";
			x.LastName = "Smith";
			x.Age = 22;

			MessageBox.Show(x.Format());

			x = new Employee();
			x.FirstName = "Jack";
			x.LastName = "Bean";
			x.Age = 43;

			MessageBox.Show(x.Format());
		}
	}
}
