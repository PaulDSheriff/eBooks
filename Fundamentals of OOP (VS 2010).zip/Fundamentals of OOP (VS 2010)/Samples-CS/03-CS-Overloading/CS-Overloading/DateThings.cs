﻿using System;
using System.Globalization;

namespace CS_Overloading
{
	public class DateThings
	{
		public DateThings()
		{
			TheDate = DateTime.Now;
		}

		public DateThings(DateTime dt)
		{
			TheDate = dt;
		}


		private DateTime _TheDate;
		public DateTime TheDate
		{
			get { return _TheDate; }
			set { _TheDate = value; }
		}

		public string MonthName
		{
			get
			{
				DateTimeFormatInfo info = new DateTimeFormatInfo();
				string[] months = null;

				months = info.MonthNames;

				return months[_TheDate.Month - 1];
			}
		}

		private const string DEFAULT_FORMAT = "yyyy-MM-dd HH:mm:ss";

		public string SqlFormatted()
		{
			return SqlFormatted(DEFAULT_FORMAT, TheDate);
		}

		public string SqlFormatted(DateTime newDate)
		{
			return SqlFormatted(DEFAULT_FORMAT, newDate);
		}

		public string SqlFormatted(string format)
		{
			return SqlFormatted(format, TheDate);
		}

		public string SqlFormatted(string format, DateTime newDate)
		{
			return newDate.ToString(format);
		}

		public DateTime MonthStart()
		{
			DateTime ret = default(DateTime);

			ret = new DateTime(TheDate.Year, TheDate.Month, 1,
				TheDate.Hour, TheDate.Minute, TheDate.Second,
				TheDate.Millisecond, CultureInfo.CurrentCulture.Calendar);

			return ret;
		}

		public DateTime MonthEnd()
		{
			int lastDay = 0;
			DateTime ret = default(DateTime);

			lastDay = DateTime.DaysInMonth(TheDate.Year, TheDate.Month);

			ret = new DateTime(TheDate.Year, TheDate.Month, lastDay,
				TheDate.Hour, TheDate.Minute, TheDate.Second,
				TheDate.Millisecond, CultureInfo.CurrentCulture.Calendar);


			return ret;
		}

		public DateTime YearStart()
		{
			DateTime ret = default(DateTime);

			ret = new DateTime(TheDate.Year, 1, 1, TheDate.Hour,
				TheDate.Minute, TheDate.Second, TheDate.Millisecond,
				CultureInfo.CurrentCulture.Calendar);

			return ret;
		}

		public DateTime YearEnd()
		{
			DateTime ret = default(DateTime);

			ret = new DateTime(TheDate.Year, 12, 31, TheDate.Hour,
				TheDate.Minute, TheDate.Second, TheDate.Millisecond,
				CultureInfo.CurrentCulture.Calendar);

			return ret;
		}
	}
}