﻿using System;
using System.Windows;

namespace CS_Overloading
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private void btnNormal_Click(object sender, RoutedEventArgs e)
		{
			DateThings dt = new DateThings();

			MessageBox.Show(dt.MonthName);
		}

		private void btnPassToConstructor_Click(object sender, RoutedEventArgs e)
		{
			DateThings dt = new DateThings(Convert.ToDateTime("1/1/2001"));

			MessageBox.Show(dt.MonthName);
		}

		private void btnSqlFormatted_Click(object sender, RoutedEventArgs e)
		{
			DateThings dt = new DateThings();

			MessageBox.Show(dt.SqlFormatted());
		}

		private void btnSqlFormatString_Click(object sender, RoutedEventArgs e)
		{
			DateThings dt = new DateThings();

			MessageBox.Show(dt.SqlFormatted("MM-dd-yyyy"));
		}

		private void btnSqlFormatDate_Click(object sender, RoutedEventArgs e)
		{
			DateThings dt = new DateThings();

			MessageBox.Show(dt.SqlFormatted(Convert.ToDateTime("1/1/2011")));
		}

		private void btnSqlFormatStringDate_Click(object sender, RoutedEventArgs e)
		{
			DateThings dt = new DateThings();

			MessageBox.Show(dt.SqlFormatted("MM-dd-yyyy", Convert.ToDateTime("1/1/2011")));
		}
	}
}
