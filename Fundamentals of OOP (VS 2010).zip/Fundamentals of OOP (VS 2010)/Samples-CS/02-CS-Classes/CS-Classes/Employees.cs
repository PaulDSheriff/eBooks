﻿using System.Collections.Generic;

namespace CS_Classes
{
	public class Employees : List<Employee>
	{	
	}
}
