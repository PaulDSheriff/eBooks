﻿using System;
using System.Windows;

namespace CS_Classes
{
	public partial class winDate : Window
	{
		public winDate()
		{
			InitializeComponent();
		}
		
		private DateThings mDate = new DateThings();

		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			txtDate.Text = DateTime.Now.ToShortDateString();
			mDate.TheDate = DateTime.Now;

		}

		private void txtDate_LostFocus(object sender, RoutedEventArgs e)
		{
			mDate.TheDate = Convert.ToDateTime(txtDate.Text);
		}

		private void DisplayMessage(string msg)
		{
			tbMessage.Text = msg;
		}

		private void btnMonthName_Click(object sender, RoutedEventArgs e)
		{
			MonthName();
		}

		private void MonthName()
		{
			DisplayMessage(mDate.MonthName);
		}

		private void btnSQLFormat_Click(object sender, RoutedEventArgs e)
		{
			SqlFormatted();
		}

		private void SqlFormatted()
		{
			DisplayMessage(mDate.SqlFormatted());
		}

		private void btnMonthStart_Click(object sender, RoutedEventArgs e)
		{
			MonthStart();
		}

		private void MonthStart()
		{
			DisplayMessage(mDate.MonthStart().ToShortDateString());
		}

		private void btnMonthEnd_Click(object sender, RoutedEventArgs e)
		{
			MonthEnd();
		}

		private void MonthEnd()
		{
			DisplayMessage(mDate.MonthEnd().ToShortDateString());
		}

		private void btnYearStart_Click(object sender, RoutedEventArgs e)
		{
			YearStart();
		}

		private void YearStart()
		{
			DisplayMessage(mDate.YearStart().ToShortDateString());
		}

		private void btnYearEnd_Click(object sender, RoutedEventArgs e)
		{
			YearEnd();
		}

		private void YearEnd()
		{
			DisplayMessage(mDate.YearEnd().ToShortDateString());
		}
	}
}
