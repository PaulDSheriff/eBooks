﻿using System;
using System.Linq;
using System.Windows;
using System.Xml.Linq;

namespace CS_Classes
{
	public partial class winXml : Window
	{
		public winXml()
		{
			InitializeComponent();
		}

		#region GetCurrentDirectory Method
		/// <summary>
		/// Returns the current directory the program is running in. If running in Visual Studio, this method removes the \bin folder. NO ending slash is applied to the end of this directory path.
		/// </summary>
		/// <returns>The current directory.</returns>
		public static string GetCurrentDirectory()
		{
			string ret = null;

			ret = AppDomain.CurrentDomain.BaseDirectory;
			if (ret.IndexOf(@"\bin") > 0)
			{
				ret = ret.Substring(0, ret.LastIndexOf(@"\bin"));
			}
			if (ret.EndsWith(@"\"))
				ret = ret.Substring(0, ret.Length - 1);

			return ret;
		}
		#endregion

		private void btnReadAll_Click(object sender, RoutedEventArgs e)
		{
			ReadAll();
		}

		private void ReadAll()
		{
			XDocument xdoc;

			xdoc = XDocument.Load(GetCurrentDirectory()
				+ @"\Xml\Product.xml");

			txtXML.Text = string.Empty;
			txtXML.Text = xdoc.ToString();
		}

		private void btnReadOneRow_Click(object sender, RoutedEventArgs e)
		{
			GetOneRow();
		}

		private void GetOneRow()
		{
			XElement xelem;

			xelem = XElement.Load(GetCurrentDirectory()
				+ @"\Xml\Product.xml");

			var prod = (from p in xelem.Descendants("Product")
									where p.Element("ProductId").Value == "1"
									select p).Single();

			if (prod != null)
			{
				txtXML.Text = string.Empty;
				txtXML.Text = prod.Element("ProductName").Value;
			}
		}

		private void btnReadOneRowAttrib_Click(object sender, RoutedEventArgs e)
		{
			GetOneRowAttribute();
		}

		private void GetOneRowAttribute()
		{
			XElement xelem;

			xelem = XElement.Load(GetCurrentDirectory()
				+ @"\Xml\ProductAttributes.xml");

			var prod = (from p in xelem.Elements("Product")
									where p.Attribute("ProductId").Value == "2"
									select p).Single();

			if (prod != null)
			{
				txtXML.Text = string.Empty;
				txtXML.Text = prod.Attribute("ProductName").Value;
			}
		}

		private void btnLoadClass_Click(object sender, RoutedEventArgs e)
		{
			LoadAClass();
		}

		private void LoadAClass()
		{
			XElement xelem;

			xelem = XElement.Load(GetCurrentDirectory()
				+ @"\Xml\Product.xml");

			var items = from prod in xelem.Descendants("Product")
									select new Product
									{
										ProductId = Convert.ToInt32(prod.Element("ProductId").Value),
										ProductName = prod.Element("ProductName").Value,
										ProductType = prod.Element("ProductType").Value,
										Price = Convert.ToDecimal(prod.Element("Price").Value),
										Image = prod.Element("Image").Value,
										IsOnSpecial = Convert.ToBoolean(prod.Element("IsOnSpecial").Value)
									};

			txtXML.Text = string.Empty;
			foreach (Product item in items)
			{
				txtXML.AppendText(item.ProductName + Environment.NewLine);
			}
		}

		private void btnAggregates_Click(object sender, RoutedEventArgs e)
		{
			Aggregates();
		}

		private void Aggregates()
		{
			XElement xelem;

			xelem = XElement.Load(GetCurrentDirectory()
				+ @"\Xml\Product.xml");

			var maxPrice = (from mnu in xelem.Descendants("Product")
											select Convert.ToDecimal(mnu.Element("Price").Value)).Max();

			var minPrice = (from mnu in xelem.Descendants("Product")
											select Convert.ToDecimal(mnu.Element("Price").Value)).Min();

			var sumPrice = (from mnu in xelem.Descendants("Product")
											select Convert.ToDecimal(mnu.Element("Price").Value)).Sum();

			txtXML.Text = string.Empty;
			txtXML.AppendText("Max Price: " + maxPrice.ToString("c") + Environment.NewLine);
			txtXML.AppendText("Min Price: " + minPrice.ToString("c") + Environment.NewLine);
			txtXML.AppendText("Sum Price: " + sumPrice.ToString("c") + Environment.NewLine);
		}
	}
}
