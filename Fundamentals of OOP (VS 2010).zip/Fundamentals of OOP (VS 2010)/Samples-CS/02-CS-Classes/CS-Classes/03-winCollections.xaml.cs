﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Windows;
using System.Windows.Documents;

namespace CS_Classes
{
	public partial class winCollections : Window
	{
		public winCollections()
		{
			InitializeComponent();
		}

		private void btnArrayList_Click(object sender, RoutedEventArgs e)
		{
      Debugger.Break();

      // Step through the next sample
      ArrayListSample();
		}

		private void ArrayListSample()
		{
			ArrayList al = new ArrayList();

			al.Add("A String");
			al.Add(42);
			al.Add(Convert.ToDateTime("01/01/2011"));

			foreach (object value in al)
			{
				Debug.WriteLine(value);
			}
		}

		private void btnNameValueCollection_Click(object sender, RoutedEventArgs e)
		{
      Debugger.Break();

      // Step through the next sample
      NameValueCollectionSample();
		}

		private void NameValueCollectionSample()
		{
			NameValueCollection nv = new NameValueCollection();

			nv.Add("string", "A String");
			nv.Add("number", 42.ToString());
			nv.Add("date", DateTime.Now.ToString());

			foreach (string key in nv.Keys)
			{
				Debug.Write("Key: " + key);
				Debug.WriteLine("  Value: " + nv[key]);
			}
		}

		private void btnList1_Click(object sender, RoutedEventArgs e)
		{
      Debugger.Break();

      // Step through the next sample
      GenericListSample1();
		}

		private void GenericListSample1()
		{
			List<string> list = new List<string>();

			list.Add("String 1");
			list.Add("String 2");
			list.Add("String 3");
			list.Add("String 4");

			// The following will not work
			//list.Add(42)

			foreach (string value in list)
			{
				Debug.WriteLine(value);
			}
		}

		private void btnList2_Click(object sender, RoutedEventArgs e)
		{
			GenericListSample2();
		}

		private void GenericListSample2()
		{
			Employees emps = new Employees();
			Employee emp = default(Employee);

			emp = new Employee();
			emp.FirstName = "Paul";
			emp.LastName = "Sheriff";

			emps.Add(emp);

			emp = new Employee();
			emp.FirstName = "Ken";
			emp.LastName = "Getz";

			emps.Add(emp);

			emp = new Employee();
			emp.FirstName = "Bill";
			emp.LastName = "Gates";

			emps.Add(emp);

			// The following will not work
			//emps.Add(42)

			foreach (Employee item in emps)
			{
				Debug.WriteLine(item.FirstName);
			}
		}
	}
}
