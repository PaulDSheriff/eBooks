﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace CS_Classes
{
	public partial class winLinq : Window
	{
		public winLinq()
		{
			InitializeComponent();
		}

		private void btnNoLinq_Click(object sender, RoutedEventArgs e)
		{
			lstData.ItemsSource = null;
			lstData.Items.Clear();
			NoLinqSample();
		}

		private void NoLinqSample()
		{
			DataTable dt = new DataTable();
			SqlDataAdapter da = null;

			da = new SqlDataAdapter("SELECT * FROM Product",
				ConfigurationManager.ConnectionStrings["Sandbox"].ConnectionString);

			da.Fill(dt);

			foreach (DataRow item in dt.Rows)
			{
				if (Convert.ToDecimal(item["Price"]) > 20)
					lstData.Items.Add(item["ProductName"]);
			}
		}

		private void btnLinq_Click(object sender, RoutedEventArgs e)
		{
			lstData.Items.Clear();
			lstData.ItemsSource = null;
			LinqSample();
		}

		private void LinqSample()
		{
			DataTable dt = new DataTable();
			SqlDataAdapter da = null;

			da = new SqlDataAdapter("SELECT * FROM Product",
				ConfigurationManager.ConnectionStrings["Sandbox"].ConnectionString);

			da.Fill(dt);

			var rows = (from prod in dt.AsEnumerable()
									where Convert.ToDecimal(prod["Price"]) > 20
									select prod["ProductName"]);

			lstData.ItemsSource = rows;
		}
	}
}
