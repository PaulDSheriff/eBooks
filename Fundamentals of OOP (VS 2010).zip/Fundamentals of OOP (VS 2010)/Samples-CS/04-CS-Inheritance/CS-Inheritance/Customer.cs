﻿using System;
using System.Text;

namespace CS_Inheritance
{
	public class Customer : Person
	{
		public int CustomerId { get; set; }
		public string CompanyName { get; set; }

		public string CustomerIdName()
		{
			StringBuilder sb = new StringBuilder();

			sb.AppendFormat("Customer ID: {0}", CustomerId);
			sb.Append(Environment.NewLine);
			sb.AppendFormat("Company Name: {0}", CompanyName);

			return sb.ToString();
		}

		public override string Format()
		{
			StringBuilder sb = new StringBuilder();

			sb.AppendFormat(this.CustomerIdName());
			sb.Append(Environment.NewLine);
			sb.AppendFormat("Contact Name: {0}", base.LastFirst());

			return sb.ToString();
		}
	}
}
