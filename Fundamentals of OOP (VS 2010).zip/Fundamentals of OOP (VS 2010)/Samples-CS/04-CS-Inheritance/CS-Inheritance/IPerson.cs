﻿
namespace CS_Inheritance
{
	public interface IPerson
	{
		string FirstName { get; set; }
		string LastName { get; set; }
		int Age { get; set; }

		string FirstLast();
		string LastFirst();

		string Format();
	}
}
