﻿using System.Text;

namespace CS_Inheritance
{
	public class Employee : Person
	{
		public string EmployeeId { get; set; }
		public decimal Wage { get; set; }

		public override string Format()
		{
			StringBuilder sb = new StringBuilder();

			sb.Append(base.Format());
			sb.AppendFormat(" and is making {0} per hour.",
											Wage.ToString("c"));

			return sb.ToString();
		}
	}
}
