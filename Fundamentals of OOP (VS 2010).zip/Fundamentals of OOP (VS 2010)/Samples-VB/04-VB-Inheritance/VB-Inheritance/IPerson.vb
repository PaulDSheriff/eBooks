﻿Public Interface IPerson
  Property FirstName() As String
  Property LastName() As String
  Property Age() As Integer

  Function FirstLast() As String
  Function LastFirst() As String

  Function Format() As String
End Interface
