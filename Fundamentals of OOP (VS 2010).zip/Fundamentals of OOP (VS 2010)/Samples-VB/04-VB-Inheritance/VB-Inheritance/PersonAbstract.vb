﻿Public MustInherit Class PersonAbstact
  Public Property FirstName() As String
  Public Property LastName() As String
  Public Property Age() As Integer

  Public Function FirstLast() As String
    Return FirstName & " " & LastName
  End Function

  Public Function LastFirst() As String
    Return LastName & ", " & FirstName
  End Function

  Public MustOverride Function Format() As String
End Class