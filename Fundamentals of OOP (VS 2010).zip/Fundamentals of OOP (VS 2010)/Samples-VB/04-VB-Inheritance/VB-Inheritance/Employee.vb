﻿Imports System.Text

Public Class Employee
  Inherits Person

  Public Property EmployeeId() As String
  Public Property Wage() As Decimal

  Public Overrides Function Format() As String
    Dim sb As New StringBuilder()

    sb.Append(MyBase.Format())
    sb.AppendFormat(" and is making {0} per hour.", Wage.ToString("c"))

    Return sb.ToString()
  End Function
End Class
