﻿Imports System.Text

Public Class Person
  Implements IPerson

  Public Property FirstName() As String Implements IPerson.FirstName
  Public Property LastName() As String Implements IPerson.LastName
  Public Property Age() As Integer Implements IPerson.Age

  Public Function FirstLast() As String Implements IPerson.FirstLast
    Return FirstName & " " & LastName
  End Function

  Public Function LastFirst() As String Implements IPerson.LastFirst
    Return LastName & ", " & FirstName
  End Function

  Public Overridable Function Format() As String Implements IPerson.Format
    Dim sb As New StringBuilder()

    sb.Append(FirstLast())
    sb.AppendFormat(" is {0} years old.", Age)

    Return sb.ToString()
  End Function
End Class
