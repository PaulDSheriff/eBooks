﻿Imports System.Text

Public Class Customer
  Inherits Person

  Public Property CustomerId() As Integer
  Public Property CompanyName() As String

  Public Function CustomerIdName() As String
    Dim sb As New StringBuilder()

    sb.AppendFormat("Customer ID: {0}", CustomerId)
    sb.Append(Environment.NewLine)
    sb.AppendFormat("Company Name: {0}", CompanyName)

    Return sb.ToString()
  End Function

  Public Overrides Function Format() As String
    Dim sb As New StringBuilder()

    sb.AppendFormat(Me.CustomerIdName())
    sb.Append(Environment.NewLine)
    sb.AppendFormat("Contact Name: {0}", MyBase.LastFirst())

    Return sb.ToString()
  End Function
End Class
