﻿Imports System.Globalization

Public Class DateThings
  Public Sub New()
    TheDate = DateTime.Now
  End Sub

  Public Sub New(dt As DateTime)
    TheDate = dt
  End Sub

  Private _TheDate As DateTime

  Public Property TheDate() As DateTime
    Get
      Return _TheDate
    End Get
    Set(value As DateTime)
      _TheDate = value
    End Set
  End Property

  Private Const DEFAULT_FORMAT As String = "yyyy-MM-dd HH:mm:ss"

  Public Function SqlFormatted() As String
    Return SqlFormatted(DEFAULT_FORMAT, TheDate)
  End Function

  Public Function SqlFormatted(newDate As DateTime) As String
    Return SqlFormatted(DEFAULT_FORMAT, newDate)
  End Function

  Public Function SqlFormatted(format As String) As String
    Return SqlFormatted(format, TheDate)
  End Function

  Public Function SqlFormatted(format As String, newDate As DateTime) As String
    Return newDate.ToString(format)
  End Function

  Public ReadOnly Property MonthName() As String
    Get
      Dim info As New DateTimeFormatInfo()
      Dim months As String() = Nothing

      months = info.MonthNames

      Return months(_TheDate.Month - 1)
    End Get
  End Property

  Public Function MonthStart() As DateTime
    Dim ret As DateTime = Nothing

    ret = New DateTime(TheDate.Year, TheDate.Month, 1, _
              TheDate.Hour, TheDate.Minute, TheDate.Second, _
              TheDate.Millisecond, CultureInfo.CurrentCulture.Calendar)

    Return ret
  End Function

  Public Function MonthEnd() As DateTime
    Dim lastDay As Integer = 0
    Dim ret As DateTime = Nothing

    lastDay = DateTime.DaysInMonth(TheDate.Year, TheDate.Month)

    ret = New DateTime(TheDate.Year, TheDate.Month, _
              lastDay, TheDate.Hour, TheDate.Minute, TheDate.Second, _
              TheDate.Millisecond, CultureInfo.CurrentCulture.Calendar)

    Return ret
  End Function

  Public Function YearStart() As DateTime
    Dim ret As DateTime = Nothing

    ret = New DateTime(TheDate.Year, 1, 1, TheDate.Hour, _
             TheDate.Minute, TheDate.Second, _
             TheDate.Millisecond, CultureInfo.CurrentCulture.Calendar)

    Return ret
  End Function

  Public Function YearEnd() As DateTime
    Dim ret As DateTime = Nothing

    ret = New DateTime(TheDate.Year, 12, 31, _
              TheDate.Hour, TheDate.Minute, TheDate.Second, _
              TheDate.Millisecond, CultureInfo.CurrentCulture.Calendar)

    Return ret
  End Function
End Class
