﻿Class MainWindow 
  Private Sub btnNormal_Click(sender As Object, e As RoutedEventArgs) Handles btnNormal.Click
    Dim dt As New DateThings()

    MessageBox.Show(dt.MonthName)
  End Sub

  Private Sub btnPassToConstructor_Click(sender As Object, e As RoutedEventArgs) Handles btnPassToConstructor.Click
    Dim dt As New DateThings(Convert.ToDateTime("1/1/2001"))

    MessageBox.Show(dt.MonthName)
  End Sub

  Private Sub btnSqlFormatted_Click(sender As Object, e As RoutedEventArgs) Handles btnSqlFormatted.Click
    Dim dt As New DateThings()

    MessageBox.Show(dt.SqlFormatted())
  End Sub

  Private Sub btnSqlFormatString_Click(sender As Object, e As RoutedEventArgs) Handles btnSqlFormatString.Click
    Dim dt As New DateThings()

    MessageBox.Show(dt.SqlFormatted("MM-dd-yyyy"))
  End Sub

  Private Sub btnSqlFormatDate_Click(sender As Object, e As RoutedEventArgs) Handles btnSqlFormatDate.Click
    Dim dt As New DateThings()

    MessageBox.Show(dt.SqlFormatted(Convert.ToDateTime("1/1/2011")))
  End Sub

  Private Sub btnSqlFormatStringDate_Click(sender As Object, e As RoutedEventArgs) Handles btnSqlFormatStringDate.Click
    Dim dt As New DateThings()

    MessageBox.Show(dt.SqlFormatted("MM-dd-yyyy", Convert.ToDateTime("1/1/2011")))
  End Sub
End Class
