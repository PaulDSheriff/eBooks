﻿Imports System.Collections
Imports System.Collections.Generic
Imports System.Collections.Specialized
Imports System.Diagnostics
Imports System.Windows
Imports System.Windows.Documents

Public Class winCollections
  Private Sub btnArrayList_Click(sender As Object, e As RoutedEventArgs)
    Debugger.Break()

    ' Step through the next sample
    ArrayListSample()
  End Sub

  Private Sub ArrayListSample()
    Dim al As New ArrayList()

    al.Add("A String")
    al.Add(42)
    al.Add(Convert.ToDateTime("01/01/2011"))

    For Each value As Object In al
      Debug.WriteLine(value)
    Next
  End Sub

  Private Sub btnNameValueCollection_Click(sender As Object, e As RoutedEventArgs) Handles btnNameValueCollection.Click
    Debugger.Break()

    ' Step through the next sample
    NameValueCollectionSample()
  End Sub

  Private Sub NameValueCollectionSample()
    Dim nv As New NameValueCollection()

    nv.Add("string", "A String")
    nv.Add("number", 42.ToString())
    nv.Add("date", DateTime.Now.ToString())

    For Each key As String In nv.Keys
      Debug.Write("Key: " & key)
      Debug.WriteLine("  Value: " & nv(key))
    Next
  End Sub

  Private Sub btnList1_Click(sender As Object, e As RoutedEventArgs) Handles btnList1.Click
    Debugger.Break()

    ' Step through the next sample
    GenericListSample1()
  End Sub

  Private Sub GenericListSample1()
    Dim list As New List(Of String)()

    list.Add("String 1")
    list.Add("String 2")
    list.Add("String 3")
    list.Add("String 4")

    ' The following will not work
    'list.Add(42)

    For Each value As String In list
      Debug.WriteLine(value)
    Next
  End Sub

  Private Sub btnList2_Click(sender As Object, e As RoutedEventArgs) Handles btnList2.Click
    Debugger.Break()

    ' Step through the next sample
    GenericListSample2()
  End Sub

  Private Sub GenericListSample2()
    Dim emps As New Employees()
    Dim emp As Employee = Nothing

    emp = New Employee()
    emp.FirstName = "Paul"
    emp.LastName = "Sheriff"

    emps.Add(emp)

    emp = New Employee()
    emp.FirstName = "Ken"
    emp.LastName = "Getz"

    emps.Add(emp)

    emp = New Employee()
    emp.FirstName = "Bill"
    emp.LastName = "Gates"

    emps.Add(emp)

    ' The following will not work
    'emps.Add(42)

    For Each item As Employee In emps
      Debug.WriteLine(item.FirstName)
    Next
  End Sub
End Class
