﻿Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows

Public Class winLinq
  Private Sub btnNoLinq_Click(sender As Object, e As RoutedEventArgs)
    lstData.ItemsSource = Nothing
    lstData.Items.Clear()
    NoLinqSample()
  End Sub

  Private Sub NoLinqSample()
    Dim dt As New DataTable()
    Dim da As SqlDataAdapter = Nothing

    da = New SqlDataAdapter("SELECT * FROM Product", _
         ConfigurationManager.ConnectionStrings("Sandbox").ConnectionString)

    da.Fill(dt)

    For Each item As DataRow In dt.Rows
      If Convert.ToDecimal(item("Price")) > 20 Then
        lstData.Items.Add(item("ProductName"))
      End If
    Next
  End Sub

  Private Sub btnLinq_Click(sender As Object, e As RoutedEventArgs)
    lstData.Items.Clear()
    lstData.ItemsSource = Nothing
    LinqSample()
  End Sub

  Private Sub LinqSample()
    Dim dt As New DataTable()
    Dim da As SqlDataAdapter = Nothing

    da = New SqlDataAdapter("SELECT * FROM Product", _
         ConfigurationManager.ConnectionStrings("Sandbox").ConnectionString)

    da.Fill(dt)

    Dim rows = (From prod In dt.AsEnumerable() _
                Where Convert.ToDecimal(prod("Price")) > 20 _
                Select prod("ProductName"))

    lstData.ItemsSource = rows
  End Sub
End Class
