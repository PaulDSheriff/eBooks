﻿Public Class Employee
  Public Property FirstName As String
  Public Property LastName As String
End Class
