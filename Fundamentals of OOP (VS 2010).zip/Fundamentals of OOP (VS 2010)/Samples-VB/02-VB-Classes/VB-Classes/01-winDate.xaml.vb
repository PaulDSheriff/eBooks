﻿Public Class winDate
  Private mDate As New DateThings()

  Private Sub Window_Loaded(sender As Object, e As RoutedEventArgs) Handles MyBase.Loaded
    txtDate.Text = DateTime.Now.ToShortDateString()
    mDate.TheDate = DateTime.Now

  End Sub

  Private Sub txtDate_LostFocus(sender As Object, e As RoutedEventArgs) Handles txtDate.LostFocus
    mDate.TheDate = Convert.ToDateTime(txtDate.Text)
  End Sub

  Private Sub DisplayMessage(msg As String)
    tbMessage.Text = msg
  End Sub

  Private Sub btnMonthName_Click(sender As Object, e As RoutedEventArgs) Handles btnMonthName.Click
    MonthName()
  End Sub

  Private Sub MonthName()
    DisplayMessage(mDate.MonthName)
  End Sub

  Private Sub btnSQLFormat_Click(sender As Object, e As RoutedEventArgs) Handles btnSQLFormat.Click
    SqlFormatted()
  End Sub

  Private Sub SqlFormatted()
    DisplayMessage(mDate.SqlFormatted())
  End Sub

  Private Sub btnMonthStart_Click(sender As Object, e As RoutedEventArgs) Handles btnMonthStart.Click
    MonthStart()
  End Sub

  Private Sub MonthStart()
    DisplayMessage(mDate.MonthStart().ToShortDateString())
  End Sub

  Private Sub btnMonthEnd_Click(sender As Object, e As RoutedEventArgs) Handles btnMonthEnd.Click
    MonthEnd()
  End Sub

  Private Sub MonthEnd()
    DisplayMessage(mDate.MonthEnd().ToShortDateString())
  End Sub

  Private Sub btnYearStart_Click(sender As Object, e As RoutedEventArgs) Handles btnYearStart.Click
    YearStart()
  End Sub

  Private Sub YearStart()
    DisplayMessage(mDate.YearStart().ToShortDateString())
  End Sub

  Private Sub btnYearEnd_Click(sender As Object, e As RoutedEventArgs) Handles btnYearEnd.Click
    YearEnd()
  End Sub

  Private Sub YearEnd()
    DisplayMessage(mDate.YearEnd().ToShortDateString())
  End Sub
End Class
