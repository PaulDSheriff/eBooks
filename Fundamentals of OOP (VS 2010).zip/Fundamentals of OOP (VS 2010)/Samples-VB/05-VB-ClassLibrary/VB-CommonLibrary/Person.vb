﻿Imports System.Text

Public Class Person
  Implements IPerson

  Private mFirstName As String
  Private mLastName As String
  Private mAge As Integer

  Public Property FirstName() As String Implements IPerson.FirstName
    Get
      Return mFirstName
    End Get
    Set(value As String)
      mFirstName = value
    End Set
  End Property

  Public Property LastName() As String Implements IPerson.LastName
    Get
      Return mLastName
    End Get
    Set(value As String)
      mLastName = value
    End Set
  End Property

  Public Property Age() As Integer Implements IPerson.Age
    Get
      Return mAge
    End Get
    Set(value As Integer)
      mAge = value
    End Set
  End Property

  Public Function FirstLast() As String Implements IPerson.FirstLast
    Return FirstName & " " & LastName
  End Function

  Public Function LastFirst() As String Implements IPerson.LastFirst
    Return LastName & ", " & FirstName
  End Function

  Public Overridable Function Format() As String Implements IPerson.Format
    Dim sb As New StringBuilder()

    sb.Append(FirstLast())
    sb.AppendFormat(" is {0} years old.", Age)

    Return sb.ToString()
  End Function
End Class
