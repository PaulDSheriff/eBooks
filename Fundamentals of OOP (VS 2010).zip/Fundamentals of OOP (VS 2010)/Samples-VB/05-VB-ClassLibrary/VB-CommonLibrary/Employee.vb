﻿Imports System.Text

Public Class Employee
  Inherits Person

  Private mEmployeeId As String
  Private mWage As Decimal

  Public Property EmployeeId() As String
    Get
      Return mEmployeeId
    End Get
    Set(value As String)
      mEmployeeId = value
    End Set
  End Property

  Public Property Wage() As Decimal
    Get
      Return mWage
    End Get
    Set(value As Decimal)
      mWage = value
    End Set
  End Property

  Public Overrides Function Format() As String
    Dim sb As New StringBuilder()

    sb.Append(MyBase.Format())
    sb.AppendFormat(" and is making {0} per hour.", Wage.ToString("c"))

    Return sb.ToString()
  End Function
End Class
