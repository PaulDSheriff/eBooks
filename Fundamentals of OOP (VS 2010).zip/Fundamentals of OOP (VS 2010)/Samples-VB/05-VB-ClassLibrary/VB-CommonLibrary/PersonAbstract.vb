﻿Public MustInherit Class PersonAbstact
  Private mFirstName As String
  Private mLastName As String
  Private mAge As Integer

  Public Property FirstName() As String
    Get
      Return mFirstName
    End Get
    Set(value As String)
      mFirstName = value
    End Set
  End Property

  Public Property LastName() As String
    Get
      Return mLastName
    End Get
    Set(value As String)
      mLastName = value
    End Set
  End Property

  Public Property Age() As Integer
    Get
      Return mAge
    End Get
    Set(value As Integer)
      mAge = value
    End Set
  End Property

  Public Function FirstLast() As String
    Return FirstName & " " & LastName
  End Function

  Public Function LastFirst() As String
    Return LastName & ", " & FirstName
  End Function

  Public MustOverride Function Format() As String
End Class