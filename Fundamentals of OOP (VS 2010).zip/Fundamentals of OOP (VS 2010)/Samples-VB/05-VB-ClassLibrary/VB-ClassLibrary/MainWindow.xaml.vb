﻿Imports VB_CommonLibrary

Class MainWindow

  Private Sub btnPerson_Click(sender As Object, e As RoutedEventArgs) Handles btnPerson.Click
    Dim per As New Person()

    per.FirstName = "John"
    per.LastName = "Smith"
    per.Age = 22

    MessageBox.Show(per.FirstName)
  End Sub

  Private Sub btnEmployee_Click(sender As Object, e As RoutedEventArgs) Handles btnEmployee.Click
    Dim emp As New Employee()

    ' The following properties are inherited from "Person"
    emp.FirstName = "Jack"
    emp.LastName = "Bean"
    emp.Age = 43
    ' Employee adds on the following properties
    emp.EmployeeId = "A1"
    emp.Wage = 33
  End Sub

  Private Sub btnCustomer_Click(sender As Object, e As RoutedEventArgs) Handles btnCustomer.Click
    Dim cust As New Customer()

    ' The following properties are inherited from "Person"
    cust.FirstName = "Jane"
    cust.LastName = "Doe"
    cust.Age = 32
    ' Customer adds on the following properties
    cust.CustomerId = 123
    cust.CompanyName = "Jane Doe Enterprises"
  End Sub

  Private Sub btnPersonFormat_Click(sender As Object, e As RoutedEventArgs) Handles btnPersonFormat.Click
    Dim per As New Person()

    per.FirstName = "John"
    per.LastName = "Smith"
    per.Age = 22

    MessageBox.Show(per.FirstLast())
    MessageBox.Show(per.Format())
  End Sub

  Private Sub btnEmployeeFormat_Click(sender As Object, e As RoutedEventArgs) Handles btnEmployeeFormat.Click
    Dim emp As New Employee()

    emp.FirstName = "Jack"
    emp.LastName = "Bean"
    emp.Age = 43
    emp.Wage = 33

    MessageBox.Show(emp.Format())
  End Sub

  Private Sub btnCustomerFormat_Click(sender As Object, e As RoutedEventArgs) Handles btnCustomerFormat.Click
    Dim cust As New Customer()

    ' The following properties are inherited from "Person"
    cust.FirstName = "Jane"
    cust.LastName = "Doe"
    cust.Age = 32
    ' Customer adds on the following properties
    cust.CustomerId = 123
    cust.CompanyName = "Jane Doe Enterprises"

    MessageBox.Show(cust.Format())
  End Sub

  Private Sub btnInterfaceSample_Click(sender As Object, e As RoutedEventArgs) Handles btnInterfaceSample.Click
    Dim x As IPerson

    x = New Person()
    x.FirstName = "John"
    x.LastName = "Smith"
    x.Age = 22

    MessageBox.Show(x.Format())

    x = New Employee()
    x.FirstName = "Jack"
    x.LastName = "Bean"
    x.Age = 43

    MessageBox.Show(x.Format())
  End Sub
End Class
