Imports System.Data
Imports System.Data.SqlClient

Partial Class Ch05_frmDataReader
  Inherits System.Web.UI.Page

  Protected Sub btnReadDataBind_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnReadDataBind.Click
    ReaderDataBinding()
  End Sub

  Private Sub ReaderDataBinding()
    Dim cmd As SqlCommand = Nothing
    Dim cnn As SqlConnection = Nothing
    Dim dr As SqlDataReader = Nothing

    Try
      cnn = New SqlConnection(AppConfig.ConnectionString)
      cmd = New SqlCommand("SELECT ProductID, ProductName FROM Products")
      cmd.Connection = cnn
      cnn.Open()
      dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)

      lstData.DataTextField = "ProductName"
      lstData.DataValueField = "ProductID"
      lstData.DataSource = dr
      lstData.DataBind()

    Catch ex As Exception
      MessageDisplay(ex.ToString())

    Finally
      If dr IsNot Nothing Then
        ' Close DataReader and Connection
        dr.Close()
      End If
      If cnn IsNot Nothing Then
        cnn.Dispose()
      End If
    End Try
  End Sub

  Private Sub MessageDisplay(ByVal Msg As String)
    lblMsg.Text = Msg
  End Sub

  Protected Sub btnLoopThru_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLoopThru.Click
    ReaderLoopThru()
  End Sub

  Private Sub ReaderLoopThru()
    Dim cmd As SqlCommand
    Dim cnn As SqlConnection
    Dim dr As SqlDataReader = Nothing

    Try
      cnn = New SqlConnection(AppConfig.ConnectionString)
      cmd = New SqlCommand("SELECT ProductID, ProductName FROM Products")
      cmd.Connection = cnn
      cnn.Open()
      dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)

      If dr.HasRows Then
        Do While dr.Read()
          lstData.Items.Add(dr("ProductName"))
        Loop
      End If

    Catch ex As Exception
      MessageDisplay(ex.ToString())

    Finally
      If dr IsNot Nothing Then
        ' Close DataReader and Connection
        dr.Close()
      End If
    End Try
  End Sub

  Protected Sub btnMultiple_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnMultiple.Click
    MultipleResults()
  End Sub

  Private Sub MultipleResults()
    Dim cmd As SqlCommand
    Dim cnn As SqlConnection = Nothing
    Dim dr As SqlDataReader = Nothing
    Dim sql As String

    Try
      sql = "SELECT ProductID, ProductName FROM Products; "
      sql &= " SELECT CustomerID, CompanyName FROM Customers"

      cnn = New SqlConnection(AppConfig.ConnectionString)
      cmd = New SqlCommand(sql)
      cmd.Connection = cnn
      cnn.Open()
      ' Can't use the CloseConnection CommandBehavior
      dr = cmd.ExecuteReader(CommandBehavior.SequentialAccess)

      lstData.DataTextField = "ProductName"
      lstData.DataValueField = "ProductID"
      lstData.DataSource = dr
      lstData.DataBind()

      dr.NextResult()

      lstData2.DataTextField = "CompanyName"
      lstData2.DataValueField = "CustomerID"
      lstData2.DataSource = dr
      lstData2.DataBind()

    Catch ex As Exception
      MessageDisplay(ex.ToString())

    Finally
      If dr IsNot Nothing Then
        ' Close DataReader
        dr.Close()
      End If
      If cnn IsNot Nothing Then
        ' Close Connection
        cnn.Close()
        cnn.Dispose()
      End If
    End Try
  End Sub
End Class
