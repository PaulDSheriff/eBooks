
Partial Class frmDataBindingWithSearch
  Inherits System.Web.UI.Page

  Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearch.Click
    RebindData()
  End Sub

  Private Sub RebindData()
    grdProducts.DataBind()
  End Sub
End Class
