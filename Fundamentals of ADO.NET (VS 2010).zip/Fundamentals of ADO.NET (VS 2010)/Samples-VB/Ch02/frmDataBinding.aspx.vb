
Partial Class frmDataBinding
  Inherits System.Web.UI.Page

End Class
