Imports System.Data
Imports System.Data.SqlClient

Partial Class Ch03_frmCommand
  Inherits System.Web.UI.Page

  Private mintProductID As Integer

  Private Sub MessageDisplay(ByVal Msg As String)
    lblMessage.Text &= Msg & "<br />"
  End Sub

  Protected Sub btnInsert_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnInsert.Click
    InsertSample()
  End Sub

  Protected Sub btnUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
    UpdateSample()
  End Sub

  Protected Sub btnDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelete.Click
    DeleteSample()
  End Sub

  Protected Sub btnTrans_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnTrans.Click
    TransactionSample()
  End Sub

  Private Sub InsertSample()
    Dim sql As String
    Dim rows As Integer
    Dim cmd As New SqlCommand()

    sql = "INSERT INTO Products"
    sql &= "(ProductName,SupplierID,CategoryID,"
    sql &= "QuantityPerUnit,UnitPrice,UnitsInStock,"
    sql &= "UnitsOnOrder,ReorderLevel,Discontinued)"
    sql &= "VALUES(@ProductName,@SupplierID,@CategoryID,"
    sql &= "@QuantityPerUnit,@UnitPrice,@UnitsInStock,"
    sql &= "@UnitsOnOrder,@ReorderLevel,@Discontinued) "

    cmd.CommandText = sql
    cmd.Connection = _
     New SqlConnection(AppConfig.ConnectionString)

    cmd.Parameters.Add( _
     New SqlParameter("ProductName", SqlDbType.VarChar))
    cmd.Parameters.Add( _
     New SqlParameter("SupplierID", SqlDbType.Int))
    cmd.Parameters.Add( _
     New SqlParameter("CategoryID", SqlDbType.Int))
    cmd.Parameters.Add( _
     New SqlParameter("QuantityPerUnit", SqlDbType.NVarChar))
    cmd.Parameters.Add( _
     New SqlParameter("UnitPrice", SqlDbType.Money))
    cmd.Parameters.Add( _
     New SqlParameter("UnitsInStock", SqlDbType.SmallInt))
    cmd.Parameters.Add( _
     New SqlParameter("UnitsOnOrder", SqlDbType.SmallInt))
    cmd.Parameters.Add( _
     New SqlParameter("ReorderLevel", SqlDbType.SmallInt))
    cmd.Parameters.Add( _
     New SqlParameter("Discontinued", SqlDbType.Bit))

    cmd.Parameters("ProductName").Value = "A New Product 1234"
    cmd.Parameters("SupplierID").Value = 1
    cmd.Parameters("CategoryID").Value = 1
    cmd.Parameters("QuantityPerUnit").Value = "1 per box"
    cmd.Parameters("UnitPrice").Value = 200
    cmd.Parameters("UnitsInStock").Value = 100
    cmd.Parameters("UnitsOnOrder").Value = 0
    cmd.Parameters("ReorderLevel").Value = 10
    cmd.Parameters("Discontinued").Value = False

    cmd.Connection.Open()
    rows = cmd.ExecuteNonQuery()

    ' Retrieve IDENTITY of new Product
    cmd.CommandText = "SELECT @@IDENTITY"
    cmd.Parameters.Clear()
    mintProductID = Convert.ToInt32(cmd.ExecuteScalar())
    txtProductIDUpdate.Text = mintProductID.ToString()

    cmd.Connection.Close()
    cmd.Connection.Dispose()

    MessageDisplay("INSERT succeeded, # of Rows Affected: " _
     & rows.ToString())
  End Sub

  Private Sub UpdateSample()
    Dim sql As String
    Dim rows As Integer
    Dim cmd As New SqlCommand()

    sql = "UPDATE Products SET "
    sql &= "UnitPrice = @UnitPrice"
    sql &= " WHERE ProductID = @ProductID"

    cmd.CommandText = sql
    cmd.Connection = _
     New SqlConnection(AppConfig.ConnectionString)

    cmd.Parameters.Add( _
     New SqlParameter("UnitPrice", SqlDbType.Money))
    cmd.Parameters.Add( _
     New SqlParameter("ProductID", SqlDbType.Int))

    cmd.Parameters("UnitPrice").Value = txtUnitPrice.Text
    cmd.Parameters("ProductID").Value = txtProductIDUpdate.Text

    cmd.Connection.Open()
    rows = cmd.ExecuteNonQuery()
    cmd.Connection.Close()
    cmd.Connection.Dispose()

    MessageDisplay("UPDATE succeeded, # of Rows Affected: " _
     & rows.ToString())
  End Sub

  Private Sub DeleteSample()
    Dim sql As String
    Dim rows As Integer
    Dim cmd As New SqlCommand

    sql = "DELETE FROM Products "
    sql &= " WHERE ProductID = @ProductID"

    cmd.Connection = _
     New SqlConnection(AppConfig.ConnectionString)
    cmd.Parameters.Add( _
     New SqlParameter("ProductID", SqlDbType.Int))
    cmd.Parameters("ProductID").Value = txtProductIDDelete.Text

    cmd.CommandText = sql

    cmd.Connection.Open()
    rows = cmd.ExecuteNonQuery()
    cmd.Connection.Close()
    cmd.Connection.Dispose()

    MessageDisplay("DELETE succeeded, # of Rows Affected: " _
     & rows.ToString())
  End Sub

  Private Sub TransactionSample()
    Dim sql As String
    Dim cmd1 As New SqlCommand()
    Dim cmd2 As New SqlCommand()
    Dim cnn As SqlConnection = Nothing
    Dim trn As SqlTransaction = Nothing

    ' Add $10 to the price of a product
    sql = "UPDATE Products SET "
    sql &= "UnitPrice = UnitPrice + 10 "
    sql &= " WHERE ProductID = @ProductID"

    cmd1.CommandText = sql
    cmd1.Parameters.Add( _
     New SqlParameter("ProductID", SqlDbType.Int))
    cmd1.Parameters("ProductID").Value = txtProductID1.Text

    cmd2.CommandText = sql
    cmd2.Parameters.Add( _
     New SqlParameter("ProductID", SqlDbType.Int))
    cmd2.Parameters("ProductID").Value = txtProductID2.Text

    Try
      cnn = New SqlConnection(AppConfig.ConnectionString)

      cnn.Open()
      trn = cnn.BeginTransaction()

      cmd1.Connection = cnn
      cmd1.Transaction = trn
      cmd2.Connection = cnn
      cmd2.Transaction = trn

      cmd1.ExecuteNonQuery()
      cmd2.ExecuteNonQuery()

      trn.Commit()

      grdProducts.DataBind()

      MessageDisplay("Transaction Completed Successfully")

    Catch ex As Exception
      If trn IsNot Nothing Then
        trn.Rollback()
      End If
      MessageDisplay("Transaction Failed: " & ex.ToString())

    Finally
      If cnn IsNot Nothing Then
        cnn.Close()
        cnn.Dispose()
      End If

    End Try
  End Sub

  Protected Sub btnDisplayProducts_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDisplayProducts.Click
    grdProducts.DataBind()
  End Sub
End Class
