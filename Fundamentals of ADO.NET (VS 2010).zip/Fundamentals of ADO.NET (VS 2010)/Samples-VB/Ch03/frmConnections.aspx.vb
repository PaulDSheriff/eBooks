Imports System.Data.SqlClient

Partial Class Ch03_frmConnections
  Inherits System.Web.UI.Page

  Private Sub MessageDisplay(ByVal Msg As String)
    lblMessage.Text &= Msg & "<br />"
  End Sub

  Protected Sub btnConnect1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConnect1.Click
    ConnectionSample1()
  End Sub

  Private Sub ConnectionSample1()
    Dim cnn As SqlConnection = Nothing

    lblMessage.Text = String.Empty
    Try
      cnn = New SqlConnection()

      cnn.ConnectionString = AppConfig.ConnectionString
      cnn.Open()

      MessageDisplay("Connection was opened successfully")

    Catch ex As Exception
      MessageDisplay(ex.ToString())

    Finally
      If cnn IsNot Nothing Then
        cnn.Close()
        cnn.Dispose()
      End If

    End Try
  End Sub

  Protected Sub btnConnect2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConnect2.Click
    ConnectionException()
  End Sub

  Private Sub ConnectionException()
    Dim cnn As SqlConnection = Nothing

    lblMessage.Text = String.Empty
    Try
      cnn = New SqlConnection()

      cnn.ConnectionString = "Blah Blah"
      cnn.Open()

      MessageDisplay("Connection was opened successfully")

    Catch ex As Exception
      MessageDisplay(ex.ToString())

    Finally
      If cnn IsNot Nothing Then
        cnn.Close()
        cnn.Dispose()
      End If

    End Try
  End Sub

  Protected Sub btnConnect3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConnect3.Click
    ConnectionWithSqlError()
  End Sub

  Private Sub ConnectionWithSqlError()
    Dim cnn As SqlConnection = Nothing
    Dim sb As New StringBuilder(1024)

    lblMessage.Text = String.Empty
    Try
      cnn = New SqlConnection()

      cnn.ConnectionString = "Server=Blah;Database=Northwind;Integrated Security=SSPI"
      cnn.Open()

      MessageDisplay("Connection was opened successfully")

    Catch ex As SqlException
      For Each ex1 As SqlError In ex.Errors
        sb.Append("Class: " & ex1.Class & "<br />")
        sb.Append("Line Number: " & ex1.LineNumber & "<br />")
        sb.Append("Message: " & ex1.Message & "<br />")
        sb.Append("Number: " & ex1.Number & "<br />")
        sb.Append("Procedure: " & ex1.Procedure & "<br />")
        sb.Append("Server: " & ex1.Server & "<br />")
        sb.Append("Source: " & ex1.Source & "<br />")
        sb.Append("State: " & ex1.State & "<br />")
      Next
      MessageDisplay(sb.ToString())

    Catch ex As Exception
      MessageDisplay(ex.ToString())

    Finally
      If cnn IsNot Nothing Then
        cnn.Close()
        cnn.Dispose()
      End If

    End Try
  End Sub

  Protected Sub btnConnect4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConnect4.Click
    ConnectWithEvents()
  End Sub

  Private WithEvents mcnn As SqlConnection

  Private Sub ConnectWithEvents()
    lblMessage.Text = String.Empty
    Try
      mcnn = New SqlConnection()

      mcnn.ConnectionString = AppConfig.ConnectionString
      mcnn.Open()

      MessageDisplay("Connection was opened successfully")

    Catch ex As Exception
      MessageDisplay(ex.ToString())

    Finally
      If mcnn IsNot Nothing Then
        mcnn.Close()
        mcnn.Dispose()
      End If
    End Try
  End Sub

  Protected Sub mcnn_InfoMessage(ByVal sender As Object, ByVal e As System.Data.SqlClient.SqlInfoMessageEventArgs) Handles mcnn.InfoMessage
    MessageDisplay(e.Message)
  End Sub

  Protected Sub mcnn_StateChange(ByVal sender As Object, ByVal e As System.Data.StateChangeEventArgs) Handles mcnn.StateChange
    MessageDisplay(e.CurrentState.ToString())
  End Sub
End Class
