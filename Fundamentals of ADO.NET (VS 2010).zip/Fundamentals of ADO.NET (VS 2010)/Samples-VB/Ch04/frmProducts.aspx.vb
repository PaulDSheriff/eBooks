Imports System.Data
Imports System.Data.SqlClient

Partial Class Ch03_frmProducts
  Inherits System.Web.UI.Page

  Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    If Not Page.IsPostBack Then
      DropDownsLoad()
      GridLoad()
    End If
  End Sub

  Private Sub GridLoad()
    Dim ds As DataSet

    ds = CreateDataSet("SELECT * FROM Products")

    grdProducts.DataSource = ds
    grdProducts.DataBind()
  End Sub

  Private Sub DropDownsLoad()
    Dim ds As DataSet

    ds = CreateDataSet("SELECT SupplierID, CompanyName FROM Suppliers")

    ddlSuppliers.DataTextField = "CompanyName"
    ddlSuppliers.DataValueField = "SupplierID"
    ddlSuppliers.DataSource = ds.Tables(0)
    ddlSuppliers.DataBind()

    ds = CreateDataSet("SELECT CategoryID, CategoryName FROM Categories")

    ddlCategories.DataTextField = "CategoryName"
    ddlCategories.DataValueField = "CategoryID"
    ddlCategories.DataSource = ds.Tables(0)
    ddlCategories.DataBind()
  End Sub

  Private Function CreateDataSet(ByVal SQL As String) As DataSet
    Dim ds As DataSet
    Dim da As SqlDataAdapter

    ds = New DataSet()
    da = New SqlDataAdapter(SQL, _
     AppConfig.ConnectionString)

    da.Fill(ds)

    Return ds
  End Function

  Protected Sub grdProducts_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles grdProducts.RowDeleting
    ProductDelete(Convert.ToInt32(grdProducts.Rows(e.RowIndex).Cells(2).Text))

    GridLoad()
  End Sub

  Protected Sub grdProducts_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdProducts.SelectedIndexChanged
    ViewState("EditMode") = "Edit"
    FormShow(Convert.ToInt32(grdProducts.SelectedRow.Cells(2).Text))
  End Sub

  Private Function GetAProduct(ByVal ProductID As Integer) As DataSet
    Dim ds As DataSet
    Dim da As SqlDataAdapter
    Dim sql As String

    sql = "SELECT * FROM Products WHERE ProductID = @ProductID"

    ds = New DataSet()
    da = New SqlDataAdapter(sql, AppConfig.ConnectionString)
    da.SelectCommand.Parameters.Add(New SqlParameter("ProductID", SqlDbType.Int))
    da.SelectCommand.Parameters(0).Value = ProductID

    da.Fill(ds)

    Return ds
  End Function

  Private Sub FormShow(ByVal ProductID As Integer)
    Dim ds As DataSet
    Dim dr As DataRow

    ds = GetAProduct(ProductID)
    dr = ds.Tables(0).Rows(0)

    pnlGrid.Visible = False
    pnlEdit.Visible = True

    ViewState("ProductID") = dr("ProductID")
    txtProductName.Text = dr("ProductName").ToString()
    FindByValue(ddlSuppliers, dr("SupplierID").ToString())
    FindByValue(ddlCategories, dr("CategoryID").ToString())
    txtQty.Text = dr("QuantityPerUnit").ToString()
    txtUnitPrice.Text = dr("UnitPrice").ToString()
    txtUnitsInStock.Text = dr("UnitsInStock").ToString()
    txtUnitsOnOrder.Text = dr("UnitsOnOrder").ToString()
    txtReorderLevel.Text = dr("ReorderLevel").ToString()
    chkDiscontinued.Checked = Convert.ToBoolean(dr("Discontinued"))
  End Sub

  Private Sub FindByValue(ByVal ddl As DropDownList, ByVal Value As String)
    Dim di As ListItem

    ddl.SelectedIndex = -1

    di = ddl.Items.FindByValue(Value.ToString())
    If Not (di Is Nothing) Then
      di.Selected = True
    End If
  End Sub

  Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
    If ViewState("EditMode") = "Edit" Then
      DataUpdate()
    Else
      DataAdd()
    End If
    pnlGrid.Visible = True
    pnlEdit.Visible = False

    FormClear()

    GridLoad()
  End Sub

  Private Sub ProductDelete(ByVal ProductID As Integer)
    Dim sql As String
    Dim cmd As New SqlCommand

    sql = "DELETE FROM Products "
    sql &= " WHERE ProductID = @ProductID"

    cmd.Connection = New SqlConnection(AppConfig.ConnectionString)
    cmd.Parameters.Add(New SqlParameter("ProductID", SqlDbType.Int))
    cmd.Parameters("ProductID").Value = ProductID

    cmd.CommandText = sql

    cmd.Connection.Open()
    cmd.ExecuteNonQuery()
    cmd.Connection.Close()
    cmd.Connection.Dispose()
  End Sub

  Private Sub DataUpdate()
    Dim sql As String
    Dim cmd As SqlCommand

    sql = "UPDATE Products SET "
    sql &= "ProductName = @ProductName, "
    sql &= "SupplierID = @SupplierID,"
    sql &= "CategoryID = @CategoryID,"
    sql &= "QuantityPerUnit = @QuantityPerUnit,"
    sql &= "UnitPrice = @UnitPrice,"
    sql &= "UnitsInStock = @UnitsInStock,"
    sql &= "UnitsOnOrder = @UnitsOnOrder,"
    sql &= "ReorderLevel = @ReorderLevel,"
    sql &= "Discontinued = @Discontinued"
    sql &= " WHERE ProductID = @ProductID"

    cmd = CreateCommandObject(True)
    cmd.CommandText = sql

    cmd.Connection.Open()
    cmd.ExecuteNonQuery()
    cmd.Connection.Close()
    cmd.Connection.Dispose()

  End Sub

  Private Function CreateCommandObject(ByVal Update As Boolean) As SqlCommand
    Dim cmd As New SqlCommand

    cmd.Connection = New SqlConnection(AppConfig.ConnectionString)

    cmd.Parameters.Add(New SqlParameter("ProductName", SqlDbType.VarChar))
    cmd.Parameters.Add(New SqlParameter("SupplierID", SqlDbType.Int))
    cmd.Parameters.Add(New SqlParameter("CategoryID", SqlDbType.Int))
    cmd.Parameters.Add(New SqlParameter("QuantityPerUnit", SqlDbType.NVarChar))
    cmd.Parameters.Add(New SqlParameter("UnitPrice", SqlDbType.Money))
    cmd.Parameters.Add(New SqlParameter("UnitsInStock", SqlDbType.SmallInt))
    cmd.Parameters.Add(New SqlParameter("UnitsOnOrder", SqlDbType.SmallInt))
    cmd.Parameters.Add(New SqlParameter("ReorderLevel", SqlDbType.SmallInt))
    cmd.Parameters.Add(New SqlParameter("Discontinued", SqlDbType.Bit))

    If Update Then
      cmd.Parameters.Add(New SqlParameter("ProductID", SqlDbType.Int))
    End If

    cmd.Parameters("ProductName").Value = txtProductName.Text
    cmd.Parameters("SupplierID").Value = ddlSuppliers.SelectedValue
    cmd.Parameters("CategoryID").Value = ddlCategories.SelectedValue
    cmd.Parameters("QuantityPerUnit").Value = txtQty.Text
    cmd.Parameters("UnitPrice").Value = txtUnitPrice.Text
    cmd.Parameters("UnitsInStock").Value = txtUnitsInStock.Text
    cmd.Parameters("UnitsOnOrder").Value = txtUnitsOnOrder.Text
    cmd.Parameters("ReorderLevel").Value = txtReorderLevel.text
    cmd.Parameters("Discontinued").Value = chkDiscontinued.Checked
    If Update Then
      cmd.Parameters("ProductID").Value = ViewState("ProductID")
    End If

    Return cmd
  End Function

  Private Sub DataAdd()
    Dim sql As String
    Dim cmd As SqlCommand

    sql = "INSERT INTO Products"
    sql &= "(ProductName,SupplierID,CategoryID,"
    sql &= "QuantityPerUnit,UnitPrice,UnitsInStock,"
    sql &= "UnitsOnOrder,ReorderLevel,Discontinued)"
    sql &= "VALUES(@ProductName,@SupplierID,@CategoryID,"
    sql &= "@QuantityPerUnit,@UnitPrice,@UnitsInStock,"
    sql &= "@UnitsOnOrder,@ReorderLevel,@Discontinued) "

    cmd = CreateCommandObject(False)
    cmd.CommandText = sql

    cmd.Connection.Open()
    cmd.ExecuteNonQuery()
    cmd.Connection.Close()
    cmd.Connection.Dispose()
  End Sub

  Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
    pnlGrid.Visible = True
    pnlEdit.Visible = False
    FormClear()
  End Sub

  Private Sub FormClear()
    txtProductName.Text = String.Empty
    ddlSuppliers.SelectedIndex = -1
    ddlCategories.SelectedIndex = -1
    txtQty.Text = String.Empty
    txtUnitPrice.Text = String.Empty
    txtUnitsInStock.Text = String.Empty
    txtUnitsOnOrder.Text = String.Empty
    txtReorderLevel.Text = String.Empty
    chkDiscontinued.Checked = False
  End Sub

  Protected Sub lnkAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkAdd.Click
    ViewState("ProductID") = -1
    ViewState("EditMode") = "Add"

    FormClear()

    pnlGrid.Visible = False
    pnlEdit.Visible = True
  End Sub
End Class
