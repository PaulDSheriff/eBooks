Imports System.Data
Imports System.Data.SqlClient

Partial Class Ch04_frmDataSet
    Inherits System.Web.UI.Page

  Protected Sub btnLoadDataSet_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLoadDataSet.Click
    DataSetLoad()
  End Sub

  Private Sub DataSetLoad()
    Dim ds As DataSet
    Dim da As SqlDataAdapter

    ds = New DataSet()
    da = New SqlDataAdapter("SELECT * FROM Products", _
     AppConfig.ConnectionString)

    da.Fill(ds)

    grdProducts.DataSource = ds
    grdProducts.DataBind()
  End Sub

  Protected Sub btnLoadDataTable_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLoadDataTable.Click
    DataTableLoad()
  End Sub

  Private Sub DataTableLoad()
    Dim dt As DataTable
    Dim da As SqlDataAdapter

    dt = New DataTable()
    da = New SqlDataAdapter("SELECT * FROM Products", _
     AppConfig.ConnectionString)

    da.Fill(dt)

    grdProducts.DataSource = dt
    grdProducts.DataBind()
  End Sub

  Protected Sub btnMultiple_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnMultiple.Click
    MultipleResults()
  End Sub

  Private Sub MultipleResults()
    Dim ds As New DataSet
    Dim da As SqlDataAdapter
    Dim sql As String

    sql = "SELECT * FROM Orders"
    sql &= Environment.NewLine
    sql &= "SELECT * FROM [Order Details Extended]"

    da = New SqlDataAdapter(sql, _
     AppConfig.ConnectionString)

    da.Fill(ds)

    lstOrders.DataTextField = "ShipName"
    lstOrders.DataValueField = "OrderID"
    lstOrders.DataSource = ds.Tables(0)
    lstOrders.DataBind()

    lstOrdersDetails.DataTextField = "ProductName"
    lstOrdersDetails.DataSource = ds.Tables(1)
    lstOrdersDetails.DataBind()
  End Sub

  Protected Sub btnDataView_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDataView.Click
    DataViewLoad()
  End Sub

  Private Sub DataViewLoad()
    Dim dt As DataTable
    Dim da As SqlDataAdapter
    Dim dv As DataView

    dt = New DataTable()
    da = New SqlDataAdapter("SELECT * FROM Products", _
     AppConfig.ConnectionString)

    da.Fill(dt)

    dv = dt.DefaultView
    dv.Sort = "UnitPrice DESC"
    ' dv.RowFilter = "UnitPrice > 20"

    grdProducts.DataSource = dv
    grdProducts.DataBind()
  End Sub

  Protected Sub btnSelect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSelect.Click
        SelectMethod()
  End Sub

  Private Sub SelectMethod()
    Dim dt As DataTable
    Dim da As SqlDataAdapter
    Dim rows() As DataRow
    Dim dt2 As New DataTable

    dt = New DataTable()
    da = New SqlDataAdapter("SELECT * FROM Products", _
     AppConfig.ConnectionString)

    da.Fill(dt)

    rows = dt.Select("UnitPrice > 20")

    dt2 = dt.Clone()
    For Each dr As DataRow In rows
      dt2.Rows.Add(dr.ItemArray)
    Next

    grdProducts.DataSource = dt2
    grdProducts.DataBind()
  End Sub

  Protected Sub btnBuildDataTable_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBuildDataTable.Click
    BuildDataTable()
  End Sub

  Private Sub BuildDataTable()
    Dim dt As New DataTable
    Dim dc As DataColumn
    Dim dr As DataRow

    dc = New DataColumn("FirstName")
    dc.DataType = System.Type.GetType("System.String")
    dt.Columns.Add(dc)

    dc = New DataColumn("LastName")
    dc.DataType = System.Type.GetType("System.String")
    dt.Columns.Add(dc)

    dc = New DataColumn("EmailAddress")
    dc.DataType = System.Type.GetType("System.String")
    dt.Columns.Add(dc)

    dr = dt.NewRow()
    dr("FirstName") = "Joe"
    dr("LastName") = "Schmoe"
    dr("EmailAddress") = "Joes@schmoe.com"
    dt.Rows.Add(dr)

    dr = dt.NewRow()
    dr("FirstName") = "Sally"
    dr("LastName") = "Smith"
    dr("EmailAddress") = "Sallys@smith.com"
    dt.Rows.Add(dr)

    dr = dt.NewRow()
    dr("FirstName") = "Jim"
    dr("LastName") = "Jones"
    dr("EmailAddress") = "Jimj@Jones.com"
    dt.Rows.Add(dr)


    grdProducts.DataSource = dt
    grdProducts.DataBind()
  End Sub

  Protected Sub btnXML_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnXML.Click
    XmlLoad()
  End Sub

  Private Sub XmlLoad()
    Dim ds As New DataSet

    ds.ReadXml(Server.MapPath("~/Xml/Names.xml"))

    grdProducts.DataSource = ds
    grdProducts.DataBind()
  End Sub
End Class
