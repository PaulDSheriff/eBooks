
Partial Class MasterPage_ADONETFund
  Inherits System.Web.UI.MasterPage
End Class

