Imports System.Data
Imports System.Data.SqlClient

Partial Class Ch06_frmStoredProcs
  Inherits System.Web.UI.Page

  Private Sub MessageDisplay(ByVal Msg As String)
    lblMessage.Text = Msg
  End Sub

  Protected Sub btnNoParams_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNoParams.Click
    NoParams()
  End Sub

  Private Sub NoParams()
    Dim ds As New DataSet
    Dim cmd As SqlCommand
    Dim da As SqlDataAdapter

    Try
      cmd = New SqlCommand
      cmd.CommandText = "[Ten Most Expensive Products]"
      cmd.CommandType = CommandType.StoredProcedure
      cmd.Connection = New SqlConnection(AppConfig.ConnectionString)

      da = New SqlDataAdapter(cmd)

      da.Fill(ds)

      grdData.DataSource = ds
      grdData.DataBind()

    Catch ex As Exception
      MessageDisplay(ex.ToString())

    End Try
  End Sub

  Protected Sub btnInputParams_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnInputParams.Click
    InputParams()
  End Sub

  Private Sub InputParams()
    Dim ds As New DataSet
    Dim cmd As SqlCommand
    Dim da As SqlDataAdapter
    Dim param As SqlParameter

    Try
      cmd = New SqlCommand
      cmd.CommandText = "[Employee Sales by Country]"
      cmd.CommandType = CommandType.StoredProcedure
      cmd.Connection = New SqlConnection(AppConfig.ConnectionString)

      param = New SqlParameter("Beginning_Date", SqlDbType.DateTime)
      param.Value = txtBeginDate.Text
      cmd.Parameters.Add(param)

      param = New SqlParameter("Ending_Date", SqlDbType.DateTime)
      param.Value = txtEndDate.Text
      cmd.Parameters.Add(param)

      da = New SqlDataAdapter(cmd)

      da.Fill(ds)

      grdData.DataSource = ds
      grdData.DataBind()

    Catch ex As Exception
      MessageDisplay(ex.ToString())

    End Try
  End Sub

  Protected Sub btnOutputParams_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnOutputParams.Click
    OutputParams()
  End Sub

  Private Sub OutputParams()
    Dim sql As String
    Dim rows As Integer
    Dim intID As Integer
    Dim cmd As New SqlCommand()

    sql = "Products_Insert"
    cmd.CommandText = sql
    cmd.CommandType = CommandType.StoredProcedure
    cmd.Connection = New SqlConnection(AppConfig.ConnectionString)

    cmd.Parameters.Add(New SqlParameter("ProductName", _
     SqlDbType.VarChar))
    cmd.Parameters.Add(New SqlParameter("SupplierID", _
     SqlDbType.Int))
    cmd.Parameters.Add(New SqlParameter("CategoryID", _
     SqlDbType.Int))
    cmd.Parameters.Add(New SqlParameter("QuantityPerUnit", _
     SqlDbType.NVarChar))
    cmd.Parameters.Add(New SqlParameter("UnitPrice", _
     SqlDbType.Money))
    cmd.Parameters.Add(New SqlParameter("UnitsInStock", _
     SqlDbType.SmallInt))
    cmd.Parameters.Add(New SqlParameter("UnitsOnOrder", _
     SqlDbType.SmallInt))
    cmd.Parameters.Add(New SqlParameter("ReorderLevel", _
     SqlDbType.SmallInt))
    cmd.Parameters.Add(New SqlParameter("Discontinued", _
     SqlDbType.Bit))

    cmd.Parameters("ProductName").Value = "A New Product XYZ"
    cmd.Parameters("SupplierID").Value = 1
    cmd.Parameters("CategoryID").Value = 1
    cmd.Parameters("QuantityPerUnit").Value = "1 per box"
    cmd.Parameters("UnitPrice").Value = 200
    cmd.Parameters("UnitsInStock").Value = 100
    cmd.Parameters("UnitsOnOrder").Value = 0
    cmd.Parameters("ReorderLevel").Value = 10
    cmd.Parameters("Discontinued").Value = False

    cmd.Parameters.Add(New SqlParameter("ProductID", _
     SqlDbType.Int))
    cmd.Parameters("ProductID").Direction = _
     ParameterDirection.Output

    cmd.Connection.Open()
    rows = cmd.ExecuteNonQuery()

    ' Retrieve IDENTITY of new Product
    intID = Convert.ToInt32(cmd.Parameters("ProductID").Value)

    cmd.Connection.Close()
    cmd.Connection.Dispose()

    MessageDisplay("INSERT succeeded, New Product ID: " _
     & intID.ToString())
  End Sub
End Class
