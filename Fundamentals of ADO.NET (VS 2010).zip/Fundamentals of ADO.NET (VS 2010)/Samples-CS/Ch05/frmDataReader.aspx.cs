using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.Data.SqlClient;

public partial class Ch05_frmDataReader : System.Web.UI.Page
{

  protected void btnReadDataBind_Click(object sender, System.EventArgs e)
  {
    ReaderDataBinding();
  }

  private void ReaderDataBinding()
  {
    SqlCommand cmd = null;
    SqlConnection cnn = null;
    SqlDataReader dr = null;

    try
    {
      cnn = new SqlConnection(AppConfig.ConnectionString);
      cmd = new SqlCommand("SELECT ProductID, ProductName FROM Products");
      cmd.Connection = cnn;
      cnn.Open();
      dr = cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);

      lstData.DataTextField = "ProductName";
      lstData.DataValueField = "ProductID";
      lstData.DataSource = dr;
      lstData.DataBind();

    }
    catch (Exception ex)
    {
      MessageDisplay(ex.ToString());

    }
    finally
    {
      if (dr != null)
      {
        //  Close DataReader and Connection
        dr.Close();
      }
      if (cnn != null)
      {
        cnn.Dispose();
      }
    }
  }

  private void MessageDisplay(string Msg)
  {
    lblMsg.Text = Msg;
  }

  protected void btnLoopThru_Click(object sender, System.EventArgs e)
  {
    ReaderLoopThru();
  }

  private void ReaderLoopThru()
  {
    SqlCommand cmd = null;
    SqlConnection cnn = null;
    SqlDataReader dr = null;

    try
    {
      cnn = new SqlConnection(AppConfig.ConnectionString);
      cmd = new SqlCommand("SELECT ProductID, ProductName FROM Products");
      cmd.Connection = cnn;
      cnn.Open();
      dr = cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);

      if (dr.HasRows)
      {
        while (dr.Read())
        {
          lstData.Items.Add(dr["ProductName"].ToString());
        }
      }

    }
    catch (Exception ex)
    {
      MessageDisplay(ex.ToString());

    }
    finally
    {
      if (dr != null)
      {
        //  Close DataReader and Connection
        dr.Close();
      }
      if (cnn != null)
      {
        cnn.Dispose();
      }
    }
  }

  protected void btnMultiple_Click(object sender, System.EventArgs e)
  {
    MultipleResults();
  }

  private void MultipleResults()
  {
    SqlCommand cmd = null;
    SqlConnection cnn = null;
    SqlDataReader dr = null;
    string sql = null;

    try
    {
      sql = "SELECT ProductID, ProductName FROM Products; ";
      sql += " SELECT CustomerID, CompanyName FROM Customers";

      cnn = new SqlConnection(AppConfig.ConnectionString);
      cmd = new SqlCommand(sql);
      cmd.Connection = cnn;
      cnn.Open();
      //  Can't use the CloseConnection CommandBehavior
      dr = cmd.ExecuteReader(System.Data.CommandBehavior.SequentialAccess);

      lstData.DataTextField = "ProductName";
      lstData.DataValueField = "ProductID";
      lstData.DataSource = dr;
      lstData.DataBind();

      dr.NextResult();

      lstData2.DataTextField = "CompanyName";
      lstData2.DataValueField = "CustomerID";
      lstData2.DataSource = dr;
      lstData2.DataBind();

    }
    catch (Exception ex)
    {
      MessageDisplay(ex.ToString());
    }
    finally
    {
      if (dr != null)
      {
        //  Close DataReader
        dr.Close();
      }
      if (cnn != null)
      {
        //  Close Connection
        cnn.Close();
        cnn.Dispose();
      }
    }
  }
}