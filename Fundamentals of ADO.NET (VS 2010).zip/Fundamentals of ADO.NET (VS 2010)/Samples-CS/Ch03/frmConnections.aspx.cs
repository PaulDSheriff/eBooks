using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.Text;
using System.Data.SqlClient;

public partial class Ch03_frmConnections : System.Web.UI.Page
{

  private void MessageDisplay(string Msg)
  {
    lblMessage.Text += Msg + "<br />";
  } 

  protected void btnConnect1_Click(object sender, System.EventArgs e)
  {
    ConnectionSample1();
  }

  private void ConnectionSample1()
  {
    SqlConnection cnn = null;

    lblMessage.Text = string.Empty;
    try
    {
      cnn = new SqlConnection();

      cnn.ConnectionString = AppConfig.ConnectionString;
      cnn.Open();

      MessageDisplay("Connection was opened successfully");

    }
    catch (Exception ex)
    {
      MessageDisplay(ex.ToString());

    }
    finally
    {
      if (cnn != null)
      {
        cnn.Close();
        cnn.Dispose();
      }
    }
  }

  protected void btnConnect2_Click(object sender, System.EventArgs e)
  {
    ConnectionException();
  }

  private void ConnectionException()
  {
    SqlConnection cnn = null;

    lblMessage.Text = string.Empty;
    try
    {
      cnn = new SqlConnection();

      cnn.ConnectionString = "Blah Blah";
      cnn.Open();

      MessageDisplay("Connection was opened successfully");

    }
    catch (Exception ex)
    {
      MessageDisplay(ex.ToString());

    }
    finally
    {
      if (cnn != null)
      {
        cnn.Close();
        cnn.Dispose();
      }
    }
  }

  protected void btnConnect3_Click(object sender, System.EventArgs e)
  {
    ConnectionWithSqlError();
  }

  private void ConnectionWithSqlError()
  {
    SqlConnection cnn = null;
    StringBuilder sb = new StringBuilder(1024);

    lblMessage.Text = string.Empty;
    try
    {
      cnn = new SqlConnection();

      cnn.ConnectionString = "Server=Blah;Database=Northwind;Integrated Security=SSPI";
      cnn.Open();

      MessageDisplay("Connection was opened successfully");

    }
    catch (SqlException ex)
    {
      foreach (System.Data.SqlClient.SqlError ex1 in ex.Errors)
      {
        sb.Append("Class: " + ex1.Class + "<br />");
        sb.Append("Line Number: " + ex1.LineNumber + "<br />");
        sb.Append("Message: " + ex1.Message + "<br />");
        sb.Append("Number: " + ex1.Number + "<br />");
        sb.Append("Procedure: " + ex1.Procedure + "<br />");
        sb.Append("Server: " + ex1.Server + "<br />");
        sb.Append("Source: " + ex1.Source + "<br />");
        sb.Append("State: " + ex1.State + "<br />");
      }
      MessageDisplay(sb.ToString());

    }
    catch (Exception ex)
    {
      MessageDisplay(ex.ToString());

    }
    finally
    {
      if (cnn != null)
      {
        cnn.Close();
        cnn.Dispose();
      }
    }
  }

  protected void btnConnect4_Click(object sender, System.EventArgs e)
  {
    ConnectWithEvents();
  }

  private void ConnectWithEvents()
  {
    SqlConnection cnn = null;

    lblMessage.Text = string.Empty;
    try
    {
      cnn = new SqlConnection();
      cnn.InfoMessage += new SqlInfoMessageEventHandler(cnn_InfoMessage);
      cnn.StateChange += new StateChangeEventHandler(cnn_StateChange);

      cnn.ConnectionString = AppConfig.ConnectionString;
      cnn.Open();

      MessageDisplay("Connection was opened successfully");

    }
    catch (Exception ex)
    {
      MessageDisplay(ex.ToString());

    }
    finally
    {
      if (cnn != null)
      {
        cnn.Close();
        cnn.Dispose();
      }
    }
  }

  protected void cnn_InfoMessage(object sender, SqlInfoMessageEventArgs e)
  {
    MessageDisplay(e.Message);
  }

  protected void cnn_StateChange(object sender, StateChangeEventArgs e)
  {
    MessageDisplay(e.CurrentState.ToString());
  }
}