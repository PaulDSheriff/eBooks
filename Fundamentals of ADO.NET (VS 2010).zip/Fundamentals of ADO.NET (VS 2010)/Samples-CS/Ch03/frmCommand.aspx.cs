using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.Data.SqlClient;

public partial class Ch03_frmCommand : System.Web.UI.Page
{
  private int mintProductID;

  private void MessageDisplay(string Msg)
  {
    lblMessage.Text += Msg + "<br />";
  }

  protected void btnInsert_Click(object sender, System.EventArgs e)
  {
    InsertSample();
  }

  protected void btnUpdate_Click(object sender, System.EventArgs e)
  {
    UpdateSample();
  }

  protected void btnDelete_Click(object sender, System.EventArgs e)
  {
    DeleteSample();
  }

  protected void btnTrans_Click(object sender, System.EventArgs e)
  {
    TransactionSample();
  }

  private void InsertSample()
  {
    string sql = null;
    int rows = 0;
    SqlCommand cmd = new SqlCommand();

    sql = "INSERT INTO Products";
    sql += "(ProductName,SupplierID,CategoryID,";
    sql += "QuantityPerUnit,UnitPrice,UnitsInStock,";
    sql += "UnitsOnOrder,ReorderLevel,Discontinued)";
    sql += "VALUES(@ProductName,@SupplierID,@CategoryID,";
    sql += "@QuantityPerUnit,@UnitPrice,@UnitsInStock,";
    sql += "@UnitsOnOrder,@ReorderLevel,@Discontinued) ";

    cmd.CommandText = sql;
    cmd.Connection =
      new SqlConnection(AppConfig.ConnectionString);

    cmd.Parameters.Add(
      new SqlParameter("ProductName", SqlDbType.VarChar));
    cmd.Parameters.Add(
      new SqlParameter("SupplierID", SqlDbType.Int));
    cmd.Parameters.Add(
      new SqlParameter("CategoryID", SqlDbType.Int));
    cmd.Parameters.Add(
      new SqlParameter("QuantityPerUnit", SqlDbType.NVarChar));
    cmd.Parameters.Add(
      new SqlParameter("UnitPrice", SqlDbType.Money));
    cmd.Parameters.Add(
      new SqlParameter("UnitsInStock", SqlDbType.SmallInt));
    cmd.Parameters.Add(
      new SqlParameter("UnitsOnOrder", SqlDbType.SmallInt));
    cmd.Parameters.Add(
      new SqlParameter("ReorderLevel", SqlDbType.SmallInt));
    cmd.Parameters.Add(
      new SqlParameter("Discontinued", SqlDbType.Bit));

    cmd.Parameters["ProductName"].Value = "A New Product 1234";
    cmd.Parameters["SupplierID"].Value = 1;
    cmd.Parameters["CategoryID"].Value = 1;
    cmd.Parameters["QuantityPerUnit"].Value = "1 per box";
    cmd.Parameters["UnitPrice"].Value = 200;
    cmd.Parameters["UnitsInStock"].Value = 100;
    cmd.Parameters["UnitsOnOrder"].Value = 0;
    cmd.Parameters["ReorderLevel"].Value = 10;
    cmd.Parameters["Discontinued"].Value = false;

    cmd.Connection.Open();
    rows = cmd.ExecuteNonQuery();

    //  Retrieve IDENTITY of new Product
    cmd.CommandText = "SELECT @@IDENTITY";
    cmd.Parameters.Clear();
    mintProductID = Convert.ToInt32(cmd.ExecuteScalar());
    txtProductIDUpdate.Text = mintProductID.ToString();

    cmd.Connection.Close();
    cmd.Connection.Dispose();

    MessageDisplay("INSERT succeeded, # of Rows Affected: "
      + rows.ToString());
  }

  private void UpdateSample()
  {
    string sql = null;
    int rows = 0;
    SqlCommand cmd = new SqlCommand();

    sql = "UPDATE Products SET ";
    sql += "UnitPrice = @UnitPrice";
    sql += " WHERE ProductID = @ProductID";

    cmd.CommandText = sql;
    cmd.Connection =
      new SqlConnection(AppConfig.ConnectionString);

    cmd.Parameters.Add(
      new SqlParameter("UnitPrice", SqlDbType.Money));
    cmd.Parameters.Add(
      new SqlParameter("ProductID", SqlDbType.Int));

    cmd.Parameters["UnitPrice"].Value = txtUnitPrice.Text;
    cmd.Parameters["ProductID"].Value = txtProductIDUpdate.Text;

    cmd.Connection.Open();
    rows = cmd.ExecuteNonQuery();
    cmd.Connection.Close();
    cmd.Connection.Dispose();

    MessageDisplay("UPDATE succeeded, # of Rows Affected: "
      + rows.ToString());
  }

  private void DeleteSample()
  {
    string sql = null;
    int rows = 0;
    SqlCommand cmd = new SqlCommand();

    sql = "DELETE FROM Products ";
    sql += " WHERE ProductID = @ProductID";

    cmd.Connection =
      new SqlConnection(AppConfig.ConnectionString);
    cmd.Parameters.Add(
      new SqlParameter("ProductID", SqlDbType.Int));
    cmd.Parameters["ProductID"].Value = txtProductIDDelete.Text;

    cmd.CommandText = sql;

    cmd.Connection.Open();
    rows = cmd.ExecuteNonQuery();
    cmd.Connection.Close();
    cmd.Connection.Dispose();

    MessageDisplay("DELETE succeeded, # of Rows Affected: "
      + rows.ToString());
  }

  private void TransactionSample()
  {
    string sql = null;
    SqlCommand cmd1 = new SqlCommand();
    SqlCommand cmd2 = new SqlCommand();
    SqlConnection cnn = null;
    SqlTransaction trn = null;

    //  Add $10 to the price of a product
    sql = "UPDATE Products SET ";
    sql += "UnitPrice = UnitPrice + 10 ";
    sql += " WHERE ProductID = @ProductID";

    cmd1.CommandText = sql;
    cmd1.Parameters.Add(
      new SqlParameter("ProductID", SqlDbType.Int));
    cmd1.Parameters["ProductID"].Value = txtProductID1.Text;

    cmd2.CommandText = sql;
    cmd2.Parameters.Add(
      new SqlParameter("ProductID", SqlDbType.Int));
    cmd2.Parameters["ProductID"].Value = txtProductID2.Text;

    try
    {
      cnn = new SqlConnection(AppConfig.ConnectionString);

      cnn.Open();
      trn = cnn.BeginTransaction();

      cmd1.Connection = cnn;
      cmd1.Transaction = trn;
      cmd2.Connection = cnn;
      cmd2.Transaction = trn;

      cmd1.ExecuteNonQuery();
      cmd2.ExecuteNonQuery();

      trn.Commit();

      grdProducts.DataBind();

      MessageDisplay("Transaction Completed Successfully");

    }
    catch (Exception ex)
    {
      if (trn != null)
      {
        trn.Rollback();
      }
      MessageDisplay("Transaction Failed: " + ex.ToString());

    }
    finally
    {
      if (cnn != null)
      {
        cnn.Close();
        cnn.Dispose();
      }
    }
  }

  protected void btnDisplayProducts_Click(object sender, System.EventArgs e)
  {    
    grdProducts.DataBind();
  } 
}