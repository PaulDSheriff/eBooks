
partial class MasterPage_ADONETFund : System.Web.UI.MasterPage 
{ 
} 