using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.Data.SqlClient;

public partial class Ch04_frmProducts : System.Web.UI.Page
{
  protected void Page_Load(object sender, System.EventArgs e)
  {
    if (!(Page.IsPostBack))
    {
      DropDownsLoad();
      GridLoad();
    }
  }

  private void GridLoad()
  {
    DataSet ds = null;

    ds = CreateDataSet("SELECT * FROM Products");

    grdProducts.DataSource = ds;
    grdProducts.DataBind();
  }

  private void DropDownsLoad()
  {
    DataSet ds = null;

    ds = CreateDataSet("SELECT SupplierID, CompanyName FROM Suppliers");

    ddlSuppliers.DataTextField = "CompanyName";
    ddlSuppliers.DataValueField = "SupplierID";
    ddlSuppliers.DataSource = ds.Tables[0];
    ddlSuppliers.DataBind();

    ds = CreateDataSet("SELECT CategoryID, CategoryName FROM Categories");

    ddlCategories.DataTextField = "CategoryName";
    ddlCategories.DataValueField = "CategoryID";
    ddlCategories.DataSource = ds.Tables[0];
    ddlCategories.DataBind();
  }

  private DataSet CreateDataSet(string SQL)
  {
    DataSet ds = null;
    SqlDataAdapter da = null;

    ds = new DataSet();
    da = new SqlDataAdapter(SQL, AppConfig.ConnectionString);

    da.Fill(ds);

    return ds;
  }

  protected void grdProducts_RowDeleting(object sender, System.Web.UI.WebControls.GridViewDeleteEventArgs e)
  {
    ProductDelete(Convert.ToInt32(grdProducts.Rows[e.RowIndex].Cells[2].Text));

    GridLoad();
  }

  protected void grdProducts_SelectedIndexChanged(object sender, System.EventArgs e)
  {
    ViewState["EditMode"] = "Edit";
    FormShow(Convert.ToInt32(grdProducts.SelectedRow.Cells[2].Text));
  }

  private DataSet GetAProduct(int ProductID)
  {
    DataSet ds = null;
    SqlDataAdapter da = null;
    string sql = null;

    sql = "SELECT * FROM Products WHERE ProductID = @ProductID";

    ds = new DataSet();
    da = new SqlDataAdapter(sql, AppConfig.ConnectionString);
    da.SelectCommand.Parameters.Add(new SqlParameter("ProductID", SqlDbType.Int));
    da.SelectCommand.Parameters[0].Value = ProductID;

    da.Fill(ds);

    return ds;
  }

  private void FormShow(int ProductID)
  {
    DataSet ds = null;
    DataRow dr = null;

    ds = GetAProduct(ProductID);
    dr = ds.Tables[0].Rows[0];

    pnlGrid.Visible = false;
    pnlEdit.Visible = true;

    ViewState["ProductID"] = dr["ProductID"];
    txtProductName.Text = dr["ProductName"].ToString();
    FindByValue(ddlSuppliers, dr["SupplierID"].ToString());
    FindByValue(ddlCategories, dr["CategoryID"].ToString());
    txtQty.Text = dr["QuantityPerUnit"].ToString();
    txtUnitPrice.Text = dr["UnitPrice"].ToString();
    txtUnitsInStock.Text = dr["UnitsInStock"].ToString();
    txtUnitsOnOrder.Text = dr["UnitsOnOrder"].ToString();
    txtReorderLevel.Text = dr["ReorderLevel"].ToString();
    chkDiscontinued.Checked = Convert.ToBoolean(dr["Discontinued"]);
  }

  private void FindByValue(DropDownList ddl, string Value)
  {
    ListItem di = null;

    ddl.SelectedIndex = -1;

    di = ddl.Items.FindByValue(Value.ToString());
    if (!((di == null)))
    {
      di.Selected = true;
    }
  }

  protected void btnSave_Click(object sender, System.EventArgs e)
  {
    if (System.Convert.ToString(ViewState["EditMode"]) == "Edit")
    {
      DataUpdate();
    }
    else
    {
      DataAdd();
    }
    pnlGrid.Visible = true;
    pnlEdit.Visible = false;

    FormClear();

    GridLoad();
  }

  private void ProductDelete(int ProductID)
  {
    string sql = null;
    SqlCommand cmd = new SqlCommand();

    sql = "DELETE FROM Products ";
    sql += " WHERE ProductID = @ProductID";

    cmd.Connection = new SqlConnection(AppConfig.ConnectionString);
    cmd.Parameters.Add(new SqlParameter("ProductID", SqlDbType.Int));
    cmd.Parameters["ProductID"].Value = ProductID;

    cmd.CommandText = sql;

    cmd.Connection.Open();
    cmd.ExecuteNonQuery();
    cmd.Connection.Close();
    cmd.Connection.Dispose();
  }

  private void DataUpdate()
  {
    string sql = null;
    SqlCommand cmd = null;

    sql = "UPDATE Products SET ";
    sql += "ProductName = @ProductName, ";
    sql += "SupplierID = @SupplierID,";
    sql += "CategoryID = @CategoryID,";
    sql += "QuantityPerUnit = @QuantityPerUnit,";
    sql += "UnitPrice = @UnitPrice,";
    sql += "UnitsInStock = @UnitsInStock,";
    sql += "UnitsOnOrder = @UnitsOnOrder,";
    sql += "ReorderLevel = @ReorderLevel,";
    sql += "Discontinued = @Discontinued";
    sql += " WHERE ProductID = @ProductID";

    cmd = CreateCommandObject(true);
    cmd.CommandText = sql;

    cmd.Connection.Open();
    cmd.ExecuteNonQuery();
    cmd.Connection.Close();
    cmd.Connection.Dispose();

  }

  private SqlCommand CreateCommandObject(bool Update)
  {
    SqlCommand cmd = new SqlCommand();

    cmd.Connection = new SqlConnection(AppConfig.ConnectionString);

    cmd.Parameters.Add(new SqlParameter("ProductName", SqlDbType.VarChar));
    cmd.Parameters.Add(new SqlParameter("SupplierID", SqlDbType.Int));
    cmd.Parameters.Add(new SqlParameter("CategoryID", SqlDbType.Int));
    cmd.Parameters.Add(new SqlParameter("QuantityPerUnit", SqlDbType.NVarChar));
    cmd.Parameters.Add(new SqlParameter("UnitPrice", SqlDbType.Money));
    cmd.Parameters.Add(new SqlParameter("UnitsInStock", SqlDbType.SmallInt));
    cmd.Parameters.Add(new SqlParameter("UnitsOnOrder", SqlDbType.SmallInt));
    cmd.Parameters.Add(new SqlParameter("ReorderLevel", SqlDbType.SmallInt));
    cmd.Parameters.Add(new SqlParameter("Discontinued", SqlDbType.Bit));

    if (Update)
    {
      cmd.Parameters.Add(new SqlParameter("ProductID", SqlDbType.Int));
    }

    cmd.Parameters["ProductName"].Value = txtProductName.Text;
    cmd.Parameters["SupplierID"].Value = ddlSuppliers.SelectedValue;
    cmd.Parameters["CategoryID"].Value = ddlCategories.SelectedValue;
    cmd.Parameters["QuantityPerUnit"].Value = txtQty.Text;
    cmd.Parameters["UnitPrice"].Value = txtUnitPrice.Text;
    cmd.Parameters["UnitsInStock"].Value = txtUnitsInStock.Text;
    cmd.Parameters["UnitsOnOrder"].Value = txtUnitsOnOrder.Text;
    cmd.Parameters["ReorderLevel"].Value = txtReorderLevel.Text;
    cmd.Parameters["Discontinued"].Value = chkDiscontinued.Checked;
    if (Update)
    {
      cmd.Parameters["ProductID"].Value = ViewState["ProductID"];
    }

    return cmd;
  }

  private void DataAdd()
  {
    string sql = null;
    SqlCommand cmd = null;

    sql = "INSERT INTO Products";
    sql += "(ProductName,SupplierID,CategoryID,";
    sql += "QuantityPerUnit,UnitPrice,UnitsInStock,";
    sql += "UnitsOnOrder,ReorderLevel,Discontinued)";
    sql += "VALUES(@ProductName,@SupplierID,@CategoryID,";
    sql += "@QuantityPerUnit,@UnitPrice,@UnitsInStock,";
    sql += "@UnitsOnOrder,@ReorderLevel,@Discontinued) ";

    cmd = CreateCommandObject(false);
    cmd.CommandText = sql;

    cmd.Connection.Open();
    cmd.ExecuteNonQuery();
    cmd.Connection.Close();
    cmd.Connection.Dispose();
  }

  protected void btnCancel_Click(object sender, System.EventArgs e)
  {
    pnlGrid.Visible = true;
    pnlEdit.Visible = false;
    FormClear();
  }

  private void FormClear()
  {
    txtProductName.Text = string.Empty;
    ddlSuppliers.SelectedIndex = -1;
    ddlCategories.SelectedIndex = -1;
    txtQty.Text = string.Empty;
    txtUnitPrice.Text = string.Empty;
    txtUnitsInStock.Text = string.Empty;
    txtUnitsOnOrder.Text = string.Empty;
    txtReorderLevel.Text = string.Empty;
    chkDiscontinued.Checked = false;
  }

  protected void lnkAdd_Click(object sender, System.EventArgs e)
  {
    ViewState["ProductID"] = -1;
    ViewState["EditMode"] = "Add";

    FormClear();

    pnlGrid.Visible = false;
    pnlEdit.Visible = true;
  }
}