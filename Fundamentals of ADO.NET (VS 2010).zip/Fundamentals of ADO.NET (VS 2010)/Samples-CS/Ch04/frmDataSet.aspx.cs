using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.Data.SqlClient;

public partial class Ch04_frmDataSet : System.Web.UI.Page
{
  protected void btnLoadDataSet_Click(object sender, System.EventArgs e)
  {
    DataSetLoad();
  }

  private void DataSetLoad()
  {
    DataSet ds = null;
    SqlDataAdapter da = null;

    ds = new DataSet();
    da = new SqlDataAdapter("SELECT * FROM Products", AppConfig.ConnectionString);

    da.Fill(ds);

    grdProducts.DataSource = ds;
    grdProducts.DataBind();
  }

  protected void btnLoadDataTable_Click(object sender, System.EventArgs e)
  {
    DataTableLoad();
  }

  private void DataTableLoad()
  {
    DataTable dt = null;
    SqlDataAdapter da = null;

    dt = new DataTable();
    da = new SqlDataAdapter("SELECT * FROM Products", AppConfig.ConnectionString);

    da.Fill(dt);

    grdProducts.DataSource = dt;
    grdProducts.DataBind();
  }

  protected void btnMultiple_Click(object sender, System.EventArgs e)
  {
    MultipleResults();
  }

  private void MultipleResults()
  {
    DataSet ds = new DataSet();
    SqlDataAdapter da = null;
    string sql = null;

    sql = "SELECT * FROM Orders";
    sql += Environment.NewLine;
    sql += "SELECT * FROM [Order Details Extended]";

    da = new SqlDataAdapter(sql, AppConfig.ConnectionString);

    da.Fill(ds);

    lstOrders.DataTextField = "ShipName";
    lstOrders.DataValueField = "OrderID";
    lstOrders.DataSource = ds.Tables[0];
    lstOrders.DataBind();

    lstOrdersDetails.DataTextField = "ProductName";
    lstOrdersDetails.DataSource = ds.Tables[1];
    lstOrdersDetails.DataBind();
  }

  protected void btnDataView_Click(object sender, System.EventArgs e)
  {
    DataViewLoad();
  }

  private void DataViewLoad()
  {
    DataTable dt = null;
    SqlDataAdapter da = null;
    DataView dv = null;

    dt = new DataTable();
    da = new SqlDataAdapter("SELECT * FROM Products", AppConfig.ConnectionString);

    da.Fill(dt);

    dv = dt.DefaultView;
    dv.Sort = "UnitPrice DESC";
    //  dv.RowFilter = "UnitPrice > 20"

    grdProducts.DataSource = dv;
    grdProducts.DataBind();
  }

  protected void btnSelect_Click(object sender, System.EventArgs e)
  {
    SelectMethod();
  }

  private void SelectMethod()
  {
    DataTable dt = null;
    SqlDataAdapter da = null;
    DataRow[] rows = null;
    DataTable dt2 = new DataTable();

    dt = new DataTable();
    da = new SqlDataAdapter("SELECT * FROM Products", AppConfig.ConnectionString);

    da.Fill(dt);

    rows = dt.Select("UnitPrice > 20");

    dt2 = dt.Clone();
    foreach (System.Data.DataRow dr in rows)
    {
      dt2.Rows.Add(dr.ItemArray);
    }

    grdProducts.DataSource = dt2;
    grdProducts.DataBind();
  }

  protected void btnBuildDataTable_Click(object sender, System.EventArgs e)
  {
    BuildDataTable();
  }

  private void BuildDataTable()
  {
    DataTable dt = new DataTable();
    DataColumn dc = null;
    DataRow dr = null;

    dc = new DataColumn("FirstName");
    dc.DataType = System.Type.GetType("System.String");
    dt.Columns.Add(dc);

    dc = new DataColumn("LastName");
    dc.DataType = System.Type.GetType("System.String");
    dt.Columns.Add(dc);

    dc = new DataColumn("EmailAddress");
    dc.DataType = System.Type.GetType("System.String");
    dt.Columns.Add(dc);

    dr = dt.NewRow();
    dr["FirstName"] = "Joe";
    dr["LastName"] = "Schmoe";
    dr["EmailAddress"] = "Joes@schmoe.com";
    dt.Rows.Add(dr);

    dr = dt.NewRow();
    dr["FirstName"] = "Sally";
    dr["LastName"] = "Smith";
    dr["EmailAddress"] = "Sallys@smith.com";
    dt.Rows.Add(dr);

    dr = dt.NewRow();
    dr["FirstName"] = "Jim";
    dr["LastName"] = "Jones";
    dr["EmailAddress"] = "Jimj@Jones.com";
    dt.Rows.Add(dr);

    grdProducts.DataSource = dt;
    grdProducts.DataBind();
  }

  protected void btnXML_Click(object sender, System.EventArgs e)
  {
    XmlLoad();
  }

  private void XmlLoad()
  {
    DataSet ds = new DataSet();

    ds.ReadXml(Server.MapPath("~/Xml/Names.xml"));

    grdProducts.DataSource = ds;
    grdProducts.DataBind();
  }
}