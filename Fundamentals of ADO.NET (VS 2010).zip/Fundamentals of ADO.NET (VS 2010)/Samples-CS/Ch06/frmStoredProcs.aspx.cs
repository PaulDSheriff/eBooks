using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.Data.SqlClient;

public partial class Ch06_frmStoredProcs : System.Web.UI.Page
{

  private void MessageDisplay(string Msg)
  {
    lblMessage.Text = Msg;
  }

  protected void btnNoParams_Click(object sender, System.EventArgs e)
  {
    NoParams();
  }


  private void NoParams()
  {
    DataSet ds = new DataSet();
    SqlCommand cmd = null;
    SqlDataAdapter da = null;

    try
    {
      cmd = new SqlCommand();
      cmd.CommandText = "[Ten Most Expensive Products]";
      cmd.CommandType = CommandType.StoredProcedure;
      cmd.Connection = new SqlConnection(AppConfig.ConnectionString);

      da = new SqlDataAdapter(cmd);

      da.Fill(ds);

      grdData.DataSource = ds;
      grdData.DataBind();

    }
    catch (Exception ex)
    {
      MessageDisplay(ex.ToString());

    }
  }

  protected void btnInputParams_Click(object sender, System.EventArgs e)
  {
    InputParams();
  }

  private void InputParams()
  {
    DataSet ds = new DataSet();
    SqlCommand cmd = null;
    SqlDataAdapter da = null;
    SqlParameter param = null;

    try
    {
      cmd = new SqlCommand();
      cmd.CommandText = "[Employee Sales by Country]";
      cmd.CommandType = CommandType.StoredProcedure;
      cmd.Connection = new 
        SqlConnection(AppConfig.ConnectionString);

      param = new SqlParameter("Beginning_Date", SqlDbType.DateTime);
      param.Value = txtBeginDate.Text;
      cmd.Parameters.Add(param);

      param = new SqlParameter("Ending_Date", SqlDbType.DateTime);
      param.Value = txtEndDate.Text;
      cmd.Parameters.Add(param);

      da = new SqlDataAdapter(cmd);

      da.Fill(ds);

      grdData.DataSource = ds;
      grdData.DataBind();

    }
    catch (Exception ex)
    {
      MessageDisplay(ex.ToString());

    }
  }

  protected void btnOutputParams_Click(object sender, System.EventArgs e)
  {
    OutputParams();
  }

  private void OutputParams()
  {
    string sql = null;
    int rows = 0;
    int id = 0;
    SqlCommand cmd = new SqlCommand();

    sql = "Products_Insert";
    cmd.CommandText = sql;
    cmd.CommandType = CommandType.StoredProcedure;
    cmd.Connection = new SqlConnection(AppConfig.ConnectionString);

    cmd.Parameters.Add(new SqlParameter("ProductName", 
      SqlDbType.VarChar));
    cmd.Parameters.Add(new SqlParameter("SupplierID", 
      SqlDbType.Int));
    cmd.Parameters.Add(new SqlParameter("CategoryID", 
      SqlDbType.Int));
    cmd.Parameters.Add(new SqlParameter("QuantityPerUnit", 
      SqlDbType.NVarChar));
    cmd.Parameters.Add(new SqlParameter("UnitPrice", 
      SqlDbType.Money));
    cmd.Parameters.Add(new SqlParameter("UnitsInStock", 
      SqlDbType.SmallInt));
    cmd.Parameters.Add(new SqlParameter("UnitsOnOrder", 
      SqlDbType.SmallInt));
    cmd.Parameters.Add(new SqlParameter("ReorderLevel", 
      SqlDbType.SmallInt));
    cmd.Parameters.Add(new SqlParameter("Discontinued", 
      SqlDbType.Bit));

    cmd.Parameters["ProductName"].Value = "A New Product XYZ";
    cmd.Parameters["SupplierID"].Value = 1;
    cmd.Parameters["CategoryID"].Value = 1;
    cmd.Parameters["QuantityPerUnit"].Value = "1 per box";
    cmd.Parameters["UnitPrice"].Value = 200;
    cmd.Parameters["UnitsInStock"].Value = 100;
    cmd.Parameters["UnitsOnOrder"].Value = 0;
    cmd.Parameters["ReorderLevel"].Value = 10;
    cmd.Parameters["Discontinued"].Value = false;

    cmd.Parameters.Add(new SqlParameter("ProductID", 
      SqlDbType.Int));
    cmd.Parameters["ProductID"].Direction = 
      ParameterDirection.Output;

    cmd.Connection.Open();
    rows = cmd.ExecuteNonQuery();

    //  Retrieve IDENTITY of new Product
    id = Convert.ToInt32(cmd.Parameters["ProductID"].Value);

    cmd.Connection.Close();
    cmd.Connection.Dispose();

    MessageDisplay("INSERT succeeded, New Product ID: " 
      + id.ToString());
  }
}