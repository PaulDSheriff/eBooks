using System;
using System.Configuration;

public class AppConfig
{
  public static string ConnectionString
  {
    get { return ConfigurationManager.ConnectionStrings["NorthwindConnectionString"].ConnectionString; }
  }
}
