Public Class frmProductBase
	Protected Overridable Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
		lblProductID.Text = ""
		txtProductName.Text = ""
		txtCost.Text = "10"
		txtPrice.Text = "20"
		chkDiscontinued.Checked = False
	End Sub

	Protected Overridable Sub ClearFormControls()
		lblProductID.Text = ""
		txtProductName.Text = ""
		txtCost.Text = ""
		txtPrice.Text = ""
		chkDiscontinued.Checked = False
	End Sub

	Protected Overridable Sub DataHasChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtProductName.TextChanged, chkDiscontinued.CheckedChanged, dtpDateIntroduced.ValueChanged, txtCost.TextChanged, txtPrice.TextChanged
		SetDataChangedButtonState()
	End Sub

	Protected Overridable Sub SetDataChangedButtonState()
		btnSave.Enabled = True
		btnDelete.Enabled = False
		btnNew.Enabled = False
		btnClose.Text = "Cancel"
	End Sub

	Protected Overridable Sub SetNormalButtonState()
		btnSave.Enabled = False
		btnDelete.Enabled = True
		btnNew.Enabled = True
		btnClose.Text = "Close"
	End Sub

	Protected Overridable Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
		If btnClose.Text = "Close" Then
			Me.Close()
		Else
			FormShow()
			SetNormalButtonState()
		End If
	End Sub

	Protected Overridable Sub FormShow()

	End Sub
End Class