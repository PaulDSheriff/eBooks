<Serializable()> Public Class BusinessRuleException
	Inherits ApplicationException

	Public Sub New()

	End Sub

	Public Sub New(ByVal Msg As String)
		MyBase.New(Msg)
	End Sub

	Public Sub New(ByVal Msg As String, ByVal ex As Exception)
		MyBase.New(Msg, ex)
	End Sub

	Public ReadOnly Property MessageForWebDisplay() As String
		Get
			Return MyBase.Message.Replace(Environment.NewLine, "<br>")
		End Get
	End Property
End Class
