Imports ConfigCommon

<Serializable()> Public Class Products
	Inherits ProductsDC

#Region "Constructors"
	Public Sub New()
		' Set the default connect string
		MyBase.ConnectString = AppConfig.ConnectString()
	End Sub

	Public Sub New(ByVal ConnectString As String)
		MyBase.ConnectString = ConnectString
	End Sub
#End Region

#Region "Validate Method"
	Public Overrides Sub Validate()
		Dim strMsg As String = String.Empty

		Try
			' Check data class business rules
			MyBase.Validate()

		Catch ex As BusinessRuleException
			' Get Business Rule Messages
			strMsg = ex.Message

		End Try

		'*******************************************************
		'* CHECK YOUR BUSINESS RULES HERE
		If MyBase.Cost < 0 Or MyBase.Cost > 999 Then
			strMsg &= "Cost must be greater than $0.00 and less than $1,000.00" & Environment.NewLine
		End If
		If MyBase.Price < 0 Or MyBase.Price > 999 Then
			strMsg &= "Price must be greater than $0.00 and less than $1,000.00" & Environment.NewLine
		End If
		If MyBase.Cost > MyBase.Price Then
			strMsg &= "Price must be greater than the Cost of the Product" & Environment.NewLine
		End If

		If strMsg <> String.Empty Then
			Throw New BusinessRuleException(strMsg)
		End If
	End Sub
#End Region

#Region "Custom Methods"

#End Region
End Class
