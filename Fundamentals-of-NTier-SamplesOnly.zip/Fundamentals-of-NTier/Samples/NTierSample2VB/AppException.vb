Public Class AppException
	Public Shared Sub Publish(ByVal ex As Exception)
		MessageBox.Show(ex.Message)
	End Sub

	Public Shared Sub Publish(ByVal Message As String)
		MessageBox.Show(Message)
	End Sub
End Class
