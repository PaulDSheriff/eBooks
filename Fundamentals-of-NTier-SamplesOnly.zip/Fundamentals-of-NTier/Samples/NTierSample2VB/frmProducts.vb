Imports NTierData

Public Class frmProducts
	Private mprod As New Products

	Private Sub frmProducts_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
		ProductsLoad()

		Me.SetNormalButtonState()
	End Sub

	Private Sub lstProducts_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstProducts.SelectedIndexChanged
		FormShow()

		Me.SetNormalButtonState()
	End Sub

	Private Sub ProductsLoad()
		Try
			' Use Schema class to return column names
			lstProducts.ValueMember = mprod.Schema.ProductId
			lstProducts.DisplayMember = mprod.Schema.ProductName

			lstProducts.DataSource = mprod.GetProducts().Tables(0)

		Catch ex As Exception
			AppException.Publish(ex)

		End Try
	End Sub

	Protected Overrides Sub FormShow()
		Try
			' Now use the Data Class to load the Data
			If mprod.Load(Convert.ToInt32(lstProducts.SelectedValue)) Then
				lblProductID.Text = mprod.ProductId.ToString()
				txtProductName.Text = mprod.ProductName
				dtpDateIntroduced.Value = Convert.ToDateTime(mprod.Introduced)
				txtCost.Text = mprod.Cost.ToString()
				txtPrice.Text = mprod.Price.ToString()
				chkDiscontinued.Checked = mprod.Discontinued
			Else
				Me.ClearFormControls()
			End If

		Catch ex As Exception
			AppException.Publish(ex)

		End Try
	End Sub

	Private Sub FormMoveToDataClass()
		If lblProductID.Text.Trim() <> "" Then
			mprod.ProductId = Convert.ToInt32(lblProductID.Text)
		End If
		mprod.ProductName = txtProductName.Text
		mprod.Introduced = dtpDateIntroduced.Value.ToString()
		mprod.Cost = Convert.ToDecimal(txtCost.Text)
		mprod.Price = Convert.ToDecimal(txtPrice.Text)
		mprod.Discontinued = chkDiscontinued.Checked
	End Sub

	Private Function DataAdd() As Boolean
		Dim boolRet As Boolean = False
		Dim strMsg As String = String.Empty

		FormMoveToDataClass()

		Try
			If mprod.Insert() > 0 Then
				boolRet = True

				strMsg = "Successful Insert"
			Else
				boolRet = False

				strMsg = "INSERT DID NOT SUCCEED"
			End If

			MessageBox.Show(strMsg)

		Catch ex As BusinessRuleException
			MessageBox.Show(ex.Message)

		Catch ex As Exception
			AppException.Publish(ex)

		End Try

		Return boolRet
	End Function

	Private Function DataUpdate() As Boolean
		Dim boolRet As Boolean = False
		Dim strMsg As String = String.Empty

		FormMoveToDataClass()

		Try
			If mprod.Update() > 0 Then
				boolRet = True

				strMsg = "Successful Update"
			Else
				boolRet = False

				strMsg = "UPDATE DID NOT SUCCEED"
			End If

			MessageBox.Show(strMsg)

		Catch ex As BusinessRuleException
			MessageBox.Show(ex.Message)

		Catch ex As Exception
			AppException.Publish(ex)

		End Try

		Return boolRet
	End Function

	Private Function DataDelete() As Boolean
		Dim boolRet As Boolean = False
		Dim strMsg As String = String.Empty

		Try
			mprod.ProductId = Convert.ToInt32(lblProductID.Text)
			If mprod.Delete() > 0 Then
				boolRet = True

				strMsg = "Successful Delete"
			Else
				boolRet = False

				strMsg = "DELETE DID NOT SUCCEED"
			End If

			MessageBox.Show(strMsg)

		Catch ex As Exception
			AppException.Publish(ex)

		End Try

		Return boolRet
	End Function

	Protected Overrides Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
		MyBase.btnNew_Click(sender, e)

		txtProductName.Focus()
	End Sub

	Protected Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
		Dim boolSucceed As Boolean

		If lblProductID.Text = "" Then
			boolSucceed = DataAdd()
		Else
			boolSucceed = DataUpdate()
		End If

		If boolSucceed Then
			' Reload Products
			ProductsLoad()

			Me.SetNormalButtonState()
		End If
	End Sub

	Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
		If MessageBox.Show("Delete this product?", "Delete?", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
			If DataDelete() Then
				ProductsLoad()
			End If
		End If
	End Sub

#Region "Hard Coded Samples"
	Private Sub ProductGetSample()
		Dim prod As Products = New Products()

		lstProducts.ValueMember = prod.Schema.ProductId
		lstProducts.DisplayMember = prod.Schema.ProductName
		lstProducts.DataSource = prod.GetProducts()
	End Sub

	Private Sub ProductInsertSample()
		Dim prod As Products = New Products()

		prod.ProductName = "A New Product"
		prod.Introduced = DateTime.Now.ToString()
		prod.Cost = 20
		prod.Price = 55
		prod.Discontinued = False

		prod.Insert()
	End Sub
#End Region
End Class