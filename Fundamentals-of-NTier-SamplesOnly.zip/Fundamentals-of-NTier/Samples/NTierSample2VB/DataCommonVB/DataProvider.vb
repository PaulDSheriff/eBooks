Imports System.Data.SqlClient

Public Class DataProvider
#Region "SQL Server Specific Methods"
	' The following methods currently only handle SQL Server
	' However, these could be put into a Case statement to choose
	' which data provider to use based on the ConnectionString.
	' Or could even be created late bound.
	Public Shared Function CreateConnection() As IDbConnection
		Dim cnn As New SqlConnection

		Return cnn
	End Function

	Public Shared Function CreateCommand() As IDbCommand
		Dim cmd As New SqlCommand

		Return cmd
	End Function

	Public Shared Function CreateParameter() As IDataParameter
		Dim param As New SqlParameter

		Return param
	End Function

	Public Shared Function CreateDataAdapter() As IDbDataAdapter
		Dim da As New SqlDataAdapter

		Return da
	End Function
#End Region
End Class
