Public Class frmMain

	Private Sub btnSample1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSample1.Click
		Dim frm As New frmProducts

		frm.Show()
	End Sub
End Class