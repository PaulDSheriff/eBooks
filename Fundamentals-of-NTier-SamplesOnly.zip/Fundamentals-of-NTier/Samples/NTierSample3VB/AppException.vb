Public Class AppException
	Public Shared Sub Publish(ByVal ex As Exception)
		Dim strMsg As String

		If ex.Message.IndexOf("BusinessRuleException:") >= 0 Then
			strMsg = ex.Message.Substring( _
			  ex.Message.IndexOf("BusinessRuleException:") + _
			  "BusinessRuleException:".Length + 1)
			strMsg = strMsg.Substring(0, strMsg.IndexOf(Environment.NewLine & Environment.NewLine))
			' Business Rule Failure
			MessageBox.Show(strMsg)
		Else
			' General Exception
			AppException.Publish(ex.Message)
		End If
	End Sub

	Public Shared Sub Publish(ByVal Message As String)
		' TODO: Put whatever publishing you want here
		MessageBox.Show(Message)
	End Sub
End Class
