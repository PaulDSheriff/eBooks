using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace ConfigCommonCS
{
	public class AppConfig
	{
		public static string ConnectString
		{
			get { return ConfigurationManager.ConnectionStrings["NTier"].ConnectionString; }
		}
	}
}
