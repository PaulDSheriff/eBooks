using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using NTierDataCS;

namespace NTierSample1aCS
{
	public partial class frmSample1 : NTierSample1aCS.frmProductBase
	{
		public frmSample1()
		{
			InitializeComponent();
		}

		Products mprod = new Products();

		private void frmSample5_Load(object sender, EventArgs e)
		{
			ProductsLoad();
		}

		private void ProductsLoad()
		{
			lstProducts.ValueMember = "iProduct_id";
			lstProducts.DisplayMember = "sProductName";
			lstProducts.DataSource = mprod.GetProducts().Tables[0];
		}

		private void lstProducts_SelectedIndexChanged(object sender, EventArgs e)
		{
			FormShow();
		}

		private void FormShow()
		{
			DataSet ds = new DataSet();
			DataRow dr;

			ds = mprod.GetProduct(Convert.ToInt32(lstProducts.SelectedValue));

			dr = ds.Tables[0].Rows[0];

			lblProductID.Text = dr["iProduct_ID"].ToString();
			txtProductName.Text = dr["sProductName"].ToString();
			dtpDateIntroduced.Value = Convert.ToDateTime(dr["dtIntroduced"]);
			txtCost.Text = dr["cCost"].ToString();
			txtPrice.Text = dr["cPrice"].ToString();
			chkDiscontinued.Checked = Convert.ToBoolean(dr["bDiscontinued"]);
		}
	}
}

