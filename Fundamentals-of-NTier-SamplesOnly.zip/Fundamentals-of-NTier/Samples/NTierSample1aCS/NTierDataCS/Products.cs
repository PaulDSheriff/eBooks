using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

using DataCommonCS;
using ConfigCommonCS;

namespace NTierDataCS
{
	public class Products
	{
		public DataSet GetProducts()
		{
			return GetProducts("SELECT * FROM tblProducts");
		}

		public DataSet GetProducts(string SQL)
		{
			DataSet ds;

			// Use the DataLayer to Build DataTable
			ds = DataLayer.GetDataSet(SQL, AppConfig.ConnectString);

			return ds;
		}

		public DataSet GetProduct(int ProductID)
		{
			string strSQL;

			strSQL = "SELECT * FROM tblProducts";
			strSQL += " WHERE iProduct_id = " + ProductID.ToString();

			return GetProducts(strSQL);
		}
	}
}
