using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace NTierSample1aCS
{
	public partial class frmMain : Form
	{
		public frmMain()
		{
			InitializeComponent();
		}

		private void btnSample1_Click(object sender, EventArgs e)
		{
			frmSample1 frm = new frmSample1();

			frm.Show();
		}
	}
}