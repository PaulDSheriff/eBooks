Imports ConfigCommonCS

<Serializable()> Public Class Products
	Inherits ProductsDC

#Region "Validate Method"
	Public Overrides Sub Validate(ByVal prod As ProductsState)
		Dim strMsg As String = String.Empty

		Try
			' Check data class business rules
			MyBase.Validate(prod)

		Catch ex As BusinessRuleException
			' Get Business Rule Messages
			strMsg = ex.Message

		End Try

		'*******************************************************
		'* CHECK YOUR BUSINESS RULES HERE
		If prod.Cost < 0 Or prod.Cost > 999 Then
			strMsg &= "Cost must be greater than $0.00 and less than $1,000.00" & Environment.NewLine
		End If
		If prod.Price < 0 Or prod.Price > 999 Then
			strMsg &= "Price must be greater than $0.00 and less than $1,000.00" & Environment.NewLine
		End If
		If prod.Cost > prod.Price Then
			strMsg &= "Price must be greater than the Cost of the Product" & Environment.NewLine
		End If

		If strMsg <> String.Empty Then
			Throw New BusinessRuleException(strMsg)
		End If
	End Sub
#End Region

#Region "Custom Methods"

#End Region
End Class
