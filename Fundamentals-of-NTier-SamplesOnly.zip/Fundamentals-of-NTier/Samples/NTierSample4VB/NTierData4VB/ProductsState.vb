<Serializable()> Public Class ProductsState
	Public Schema As SchemaStruct

#Region "Constructors"
	Public Sub New()
		Schema = New SchemaStruct()

		Schema.ObjectName = "tblProducts"
		Schema.ProductId = "iProduct_id"
		Schema.ProductName = "sProductName"
		Schema.Discontinued = "bDiscontinued"
		Schema.Introduced = "dtIntroduced"
		Schema.Price = "cPrice"
		Schema.Cost = "cCost"
	End Sub
#End Region

#Region "Private Member Variables"
	Private mintProductId As Integer
	Private mstrProductName As String
	Private mstrIntroduced As String
	Private mdecCost As Decimal
	Private mdecPrice As Decimal
	Private mboolDiscontinued As Boolean
#End Region

#Region "Column Properties"
	Property ProductId() As Integer
		Get
			Return mintProductId
		End Get

		Set(ByVal Value As Integer)
			mintProductId = Value
		End Set
	End Property

	Property ProductName() As String
		Get
			Return mstrProductName
		End Get

		Set(ByVal Value As String)
			mstrProductName = Value
		End Set
	End Property

	Property Introduced() As String
		Get
			Return mstrIntroduced
		End Get

		Set(ByVal Value As String)
			mstrIntroduced = Value
		End Set
	End Property

	Property Cost() As Decimal
		Get
			Return mdecCost
		End Get

		Set(ByVal Value As Decimal)
			mdecCost = Value
		End Set
	End Property

	Property Price() As Decimal
		Get
			Return mdecPrice
		End Get

		Set(ByVal Value As Decimal)
			mdecPrice = Value
		End Set
	End Property

	Property Discontinued() As Boolean
		Get
			Return mboolDiscontinued
		End Get

		Set(ByVal Value As Boolean)
			mboolDiscontinued = Value
		End Set
	End Property
#End Region

#Region "Schema Structure to return Object and Column Names"
	<Serializable()> Public Structure SchemaStruct
		Public ObjectName As String
		Public ProductId As String
		Public ProductName As String
		Public Introduced As String
		Public Cost As String
		Public Price As String
		Public Discontinued As String
	End Structure
#End Region
End Class


