Imports DataCommonCS

<Serializable()> Public MustInherit Class ProductsDC
	Private mstrConnectString As String

	Public Property ConnectString() As String
		Get
			Return mstrConnectString
		End Get
		Set(ByVal value As String)
			mstrConnectString = value
		End Set
	End Property

#Region "Data Retrieval Methods"
	Public Function GetProducts() As DataSet
		Dim ds As DataSet
		Dim strSQL As String

		strSQL = "SELECT * FROM tblProducts"

		' Retrieve DataTable from Data Layer
		ds = DataLayer.GetDataSet(strSQL, mstrConnectString)

		Return ds
	End Function

	Public Function GetProduct(ByVal prod As ProductsState) As DataSet
		Dim ds As DataSet = Nothing
		Dim strSQL As String = String.Empty

		strSQL = "SELECT * FROM tblProducts"
		strSQL &= " WHERE iProduct_id = " + prod.ProductId.ToString()

		' Retrieve DataTable from Data Layer
		ds = DataLayer.GetDataSet(strSQL, mstrConnectString)

		Return ds
	End Function

	Public Function Load(ByVal prod As ProductsState) As Boolean
		Dim ds As DataSet = Nothing
		Dim dr As DataRow
		Dim boolRet As Boolean = False

		ds = GetProduct(prod)

		If ds IsNot Nothing Then
			If ds.Tables.Count > 0 Then
				boolRet = True

				dr = ds.Tables(0).Rows(0)

				prod.ProductId = Convert.ToInt32(dr(prod.Schema.ProductId))
				prod.ProductName = dr(prod.Schema.ProductName).ToString()
				prod.Introduced = dr(prod.Schema.Introduced).ToString()
				prod.Cost = Convert.ToDecimal(dr(prod.Schema.Cost))
				prod.Price = Convert.ToDecimal(dr(prod.Schema.Price))
				prod.Discontinued = Convert.ToBoolean(dr(prod.Schema.Discontinued))
			End If
		End If

		Return boolRet
	End Function
#End Region

#Region "Data Modification Methods"
	Public Overridable Sub Validate(ByVal prod As ProductsState)
		Dim strMsg As String = String.Empty

		If prod.ProductName.Trim() = String.Empty Then
			strMsg &= "Product Name Must Be Filled In" & Environment.NewLine
		End If

		If prod.Introduced.Trim() <> String.Empty Then
			If Not IsDate(prod.Introduced) Then
				strMsg &= "Date Introduced is not a valid Date" & Environment.NewLine
			End If
		End If

		If strMsg <> String.Empty Then
			Throw New BusinessRuleException(strMsg)
		End If
	End Sub

	Public Function Insert(ByVal prod As ProductsState) As Integer
		Dim cmd As IDbCommand
		Dim strSQL As String

		' Check Business Rules
		Validate(prod)

		strSQL = "INSERT INTO tblProducts( "
		strSQL &= "sProductName, dtIntroduced, cCost, cPrice, bDiscontinued) "
		strSQL &= "VALUES(@sProductName, @dtIntroduced, @cCost, @cPrice, @bDiscontinued) "

		cmd = DataLayer.CreateCommand(strSQL, mstrConnectString)

		FillInParameters(prod, cmd)

		Return DataLayer.ExecuteSQL(cmd, True)
	End Function

	Public Function Update(ByVal prod As ProductsState) As Integer
		Dim cmd As IDbCommand
		Dim strSQL As String

		' Check Business Rules
		Validate(prod)

		strSQL = "UPDATE tblProducts "
		strSQL &= "SET sProductName = @sProductName,"
		strSQL &= " dtIntroduced = @dtIntroduced, "
		strSQL &= " cCost = @cCost, "
		strSQL &= " cPrice = @cPrice, "
		strSQL &= " bDiscontinued = @bDiscontinued "
		strSQL &= " WHERE iProduct_id = @iProduct_id "

		cmd = DataLayer.CreateCommand(strSQL, mstrConnectString)

		FillInParameters(prod, cmd)

		Return DataLayer.ExecuteSQL(cmd, True)
	End Function

	Public Function Delete(ByVal prod As ProductsState) As Integer
		Dim cmd As IDbCommand
		Dim strSQL As String

		strSQL = "DELETE FROM tblProducts "
		strSQL &= " WHERE iProduct_id = @iProduct_id "

		cmd = DataLayer.CreateCommand(strSQL, mstrConnectString)

		FillInParameters(prod, cmd)

		Return DataLayer.ExecuteSQL(cmd, True)
	End Function

	Protected Sub FillInParameters(ByVal prod As ProductsState, ByVal cmd As IDbCommand)
		cmd.Parameters.Add(DataLayer.CreateParameter( _
		 "@iProduct_id", DbType.Int32, prod.ProductId))
		cmd.Parameters.Add(DataLayer.CreateParameter( _
		 "@sProductName", DbType.String, prod.ProductName))
		cmd.Parameters.Add(DataLayer.CreateParameter( _
		 "@dtIntroduced", DbType.DateTime, prod.Introduced))
		cmd.Parameters.Add(DataLayer.CreateParameter( _
		 "@cCost", DbType.Decimal, prod.Cost))
		cmd.Parameters.Add(DataLayer.CreateParameter( _
		 "@cPrice", DbType.Decimal, prod.Price))
		cmd.Parameters.Add(DataLayer.CreateParameter( _
		 "@bDiscontinued", DbType.Decimal, prod.Discontinued))
	End Sub
#End Region
End Class


