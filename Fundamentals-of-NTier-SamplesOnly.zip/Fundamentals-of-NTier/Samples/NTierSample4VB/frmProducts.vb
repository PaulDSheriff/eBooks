Imports NTierData4VB

Public Class frmProducts
	Inherits frmProductBase

	Private mprod As New Products
	Private mprodState As New ProductsState

	Private Sub frmProducts_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
		ProductsLoad()

		Me.SetNormalButtonState()
	End Sub

	Private Sub lstProducts_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstProducts.SelectedIndexChanged
		FormShow()

		Me.SetNormalButtonState()
	End Sub

	Private Sub ProductsLoad()
		Try
			' Use Schema class to return column names
			lstProducts.ValueMember = mprodState.Schema.ProductId
			lstProducts.DisplayMember = mprodState.Schema.ProductName

			lstProducts.DataSource = mprod.GetProducts().Tables(0)

		Catch ex As Exception
			AppException.Publish(ex)

		End Try
	End Sub

	Protected Overrides Sub FormShow()
		Try
			' Get product object
			mprodState.ProductId = Convert.ToInt32(lstProducts.SelectedValue)

			If mprod.Load(mprodState) Then
				lblProductID.Text = mprodState.ProductId.ToString()
				txtProductName.Text = mprodState.ProductName
				dtpDateIntroduced.Value = Convert.ToDateTime(mprodState.Introduced)
				txtCost.Text = mprodState.Cost.ToString()
				txtPrice.Text = mprodState.Price.ToString()
				chkDiscontinued.Checked = mprodState.Discontinued
			Else
				Me.ClearFormControls()
			End If

		Catch ex As Exception
			AppException.Publish(ex)

		End Try
	End Sub

	Private Sub FormMoveToDataClass()
		If lblProductID.Text.Trim() <> "" Then
			mprodState.ProductId = Convert.ToInt32(lblProductID.Text)
		End If

		mprodState.ProductName = txtProductName.Text
		mprodState.Introduced = dtpDateIntroduced.Value.ToString()
		mprodState.Cost = Convert.ToDecimal(txtCost.Text)
		mprodState.Price = Convert.ToDecimal(txtPrice.Text)
		mprodState.Discontinued = chkDiscontinued.Checked
	End Sub

	Private Function DataAdd() As Boolean
		Dim boolRet As Boolean = False
		Dim strMsg As String = String.Empty

		FormMoveToDataClass()

		Try
			If mprod.Insert(mprodState) > 0 Then
				boolRet = True

				strMsg = "Successful Insert"
			Else
				boolRet = False

				strMsg = "INSERT DID NOT SUCCEED"
			End If

			MessageBox.Show(strMsg)

		Catch ex As Exception
			AppException.Publish(ex)

		End Try

		Return boolRet
	End Function

	Private Function DataUpdate() As Boolean
		Dim boolRet As Boolean = False
		Dim strMsg As String = String.Empty

		FormMoveToDataClass()

		Try
			If mprod.Update(mprodState) > 0 Then
				boolRet = True

				strMsg = "Successful Update"
			Else
				boolRet = False

				strMsg = "UPDATE DID NOT SUCCEED"
			End If

			MessageBox.Show(strMsg)

		Catch ex As Exception
			AppException.Publish(ex)

		End Try

		Return boolRet
	End Function

	Private Function DataDelete() As Boolean
		Dim boolRet As Boolean = False
		Dim strMsg As String = String.Empty

		Try
			mprodState.ProductId = Convert.ToInt32(lblProductID.Text)
			If mprod.Delete(mprodState) > 0 Then
				boolRet = True

				strMsg = "Successful Delete"
			Else
				boolRet = False

				strMsg = "DELETE DID NOT SUCCEED"
			End If

			MessageBox.Show(strMsg)

		Catch ex As Exception
			AppException.Publish(ex)

		End Try

		Return boolRet
	End Function

	Protected Overrides Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
		MyBase.btnNew_Click(sender, e)

		txtProductName.Focus()
	End Sub

	Protected Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
		Dim boolSucceed As Boolean

		If lblProductID.Text = "" Then
			boolSucceed = DataAdd()
		Else
			boolSucceed = DataUpdate()
		End If

		If boolSucceed Then
			' Reload Products
			ProductsLoad()

			Me.SetNormalButtonState()
		End If
	End Sub

	Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
		If MessageBox.Show("Delete this product?", "Delete?", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
			If DataDelete() Then
				ProductsLoad()
			End If
		End If
	End Sub
End Class