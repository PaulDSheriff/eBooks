Public Class AppException
	Public Shared Sub Publish(ByVal ex As Exception)
		' TODO: Put whatever publishing you want here
		AppException.Publish(ex.Message)
	End Sub

	Public Shared Sub Publish(ByVal Message As String)
		' TODO: Put whatever publishing you want here
		MessageBox.Show(Message)
	End Sub
End Class
