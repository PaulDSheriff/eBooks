using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace NTierSample3CS
{
	class AppException
	{
		public static void Publish(Exception ex)
		{
			string strMsg;

			if (ex.Message.IndexOf("BusinessRuleException:") >= 0)
			{
				strMsg = ex.Message.Substring(ex.Message.IndexOf("BusinessRuleException:") + "BusinessRuleException:".Length + 1);
				strMsg = strMsg.Substring(0, strMsg.IndexOf("\n\n"));
				// Business Rule Failure
				MessageBox.Show(strMsg);
			}
			else
			{
				// General Exception
				AppException.Publish(ex.Message);
			}
		}

		public static void Publish(string Message)
		{
			// TODO: Put whatever publishing you want here
			MessageBox.Show(Message);
		}
	}
}
