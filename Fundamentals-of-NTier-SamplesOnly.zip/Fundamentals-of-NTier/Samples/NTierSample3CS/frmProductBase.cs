using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace NTierSample3CS
{
	public partial class frmProductBase : Form
	{
		public frmProductBase()
		{
			InitializeComponent();
		}

		protected void btnClose_Click(object sender, EventArgs e)
		{
			if (btnClose.Text == "Close")
			{
				this.Close();
			}
			else
			{
				FormShow();
				SetNormalButtonState();
			}
		}

		protected virtual void FormShow()
		{
		}

		protected virtual void btnNew_Click(object sender, EventArgs e)
		{
			lblProductID.Text = "";
			txtProductName.Text = "";
			txtCost.Text = "10";
			txtPrice.Text = "20";
			chkDiscontinued.Checked = false;
		}

		protected void ClearFormControls()
		{
			lblProductID.Text = "";
			txtProductName.Text = "";
			txtCost.Text = "";
			txtPrice.Text = "";
			chkDiscontinued.Checked = false;
		}

		protected void SetDataChangedButtonState()
		{
			btnSave.Enabled = true;
			btnDelete.Enabled = false;
			btnNew.Enabled = false;
			btnClose.Text = "Cancel";
		}

		protected void SetNormalButtonState()
		{
			btnSave.Enabled = false;
			btnDelete.Enabled = true;
			btnNew.Enabled = true;
			btnClose.Text = "Close";
		}

		private void DataHasChanged(object sender, EventArgs e)
		{
			SetDataChangedButtonState();
		}
	}
}