using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using NTierSample3CS.NTierDataCS;

namespace NTierSample3CS
{
	public partial class frmProducts : NTierSample3CS.frmProductBase
	{
		Products mprod;
		wsProducts mws = new wsProducts();

		public frmProducts()
		{
			InitializeComponent();
		}

		private void frmProducts_Load(object sender, EventArgs e)
		{
			mprod = mws.GetProductObject();

			ProductsLoad();

			this.SetNormalButtonState();
		}

		private void ProductsLoad()
		{
			try
			{
				// Use Schema class to return column names
				lstProducts.ValueMember = mprod.Schema.ProductId;
				lstProducts.DisplayMember = mprod.Schema.ProductName;

				lstProducts.DataSource = mws.GetProducts().Tables[0];
			}
			catch (Exception ex)
			{
				AppException.Publish(ex);
			}
		}

		private void lstProducts_SelectedIndexChanged(object sender, EventArgs e)
		{
			FormShow();

			this.SetNormalButtonState();
		}

		protected override void FormShow()
		{
			try
			{
				// Get Products Class
				mprod = mws.GetProduct(
					Convert.ToInt32(lstProducts.SelectedValue));

				if (mprod != null)
				{
					lblProductID.Text = mprod.ProductId.ToString();
					txtProductName.Text = mprod.ProductName;
					dtpDateIntroduced.Value = 
						Convert.ToDateTime(mprod.Introduced);
					txtCost.Text = mprod.Cost.ToString();
					txtPrice.Text = mprod.Price.ToString();
					chkDiscontinued.Checked = mprod.Discontinued;
				}
				else
				{
					this.ClearFormControls();
				}
			}
			catch (Exception ex)
			{
				AppException.Publish(ex);
			}
		}

		private bool DataAdd()
		{
			bool boolRet = false;
			string strMsg = string.Empty;

			FormMoveToDataClass();

			try
			{
				if (mws.Insert(mprod) > 0)
				{
					boolRet = true;

					strMsg = "Successful Insert";
				}
				else
				{
					boolRet = false;

					strMsg = "INSERT DID NOT SUCCEED";
				}

				MessageBox.Show(strMsg);
			}
			catch (Exception ex)
			{
				AppException.Publish(ex);
			}

			return boolRet;
		}

		private void FormMoveToDataClass()
		{

			if (lblProductID.Text.Trim() != "")
				mprod.ProductId = Convert.ToInt32(lblProductID.Text);

			mprod.ProductName = txtProductName.Text;
			mprod.Introduced = dtpDateIntroduced.Value.ToString();
			mprod.Cost = Convert.ToDecimal(txtCost.Text);
			mprod.Price = Convert.ToDecimal(txtPrice.Text);
			mprod.Discontinued = chkDiscontinued.Checked;
		}

		private bool DataUpdate()
		{
			bool boolRet = false;
			string strMsg = string.Empty;

			FormMoveToDataClass();

			try
			{
				if (mws.Update(mprod) > 0)
				{
					boolRet = true;

					strMsg = "Successful Update";
				}
				else
				{
					boolRet = false;

					strMsg = "UPDATE DID NOT SUCCEED";
				}

				MessageBox.Show(strMsg);
			}

			catch (Exception ex)
			{
				AppException.Publish(ex);
			}

			return boolRet;
		}

		private bool DataDelete()
		{
			bool boolRet = false;
			string strMsg = string.Empty;

			try
			{
				mprod.ProductId = Convert.ToInt32(lblProductID.Text);

				if (mws.Delete(mprod) > 0)
				{
					boolRet = true;

					strMsg = "Successful Delete";
				}
				else
				{
					boolRet = false;

					strMsg = "DELETE DID NOT SUCCEED";
				}

				MessageBox.Show(strMsg);
			}
			catch (Exception ex)
			{
				AppException.Publish(ex);
			}

			return boolRet;
		}
		
		protected override void btnNew_Click(object sender, EventArgs e)
		{
			base.btnNew_Click(sender, e);

			txtProductName.Focus();
		}

		private void btnSave_Click(object sender, EventArgs e)
		{
			bool boolSucceed;

			if (lblProductID.Text == "")
			{
				boolSucceed = DataAdd();
			}
			else
			{
				boolSucceed = DataUpdate();
			}

			if (boolSucceed)
			{
				// Reload Products
				ProductsLoad();

				this.SetNormalButtonState();
			}
		}

		private void btnDelete_Click(object sender, EventArgs e)
		{
			if (MessageBox.Show("Delete this product?", "Delete?", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
			{
				if (DataDelete())
					ProductsLoad();
			}
		}
	}
}

