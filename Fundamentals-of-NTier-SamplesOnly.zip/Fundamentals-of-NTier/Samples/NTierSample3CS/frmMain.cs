using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace NTierSample3CS
{
	public partial class frmMain : Form
	{
		public frmMain()
		{
			InitializeComponent();
		}

		private void btnSample1_Click(object sender, EventArgs e)
		{
			frmProducts frm = new frmProducts();

			frm.Show();
		}
	}
}