using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

using NTierDataCS;
using ConfigCommonCS;
using System.Data;

[WebService(Namespace = "http://www.pdsa.com/eBooks/NTier/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class wsProducts : System.Web.Services.WebService
{
    public wsProducts()
	 {
		  //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

	[WebMethod]
	public Products GetProductObject()
	{
		Products prod = new Products();

		return prod;
	}

	 [WebMethod]
	 public DataSet GetProducts()
	 {
		 Products prod = new Products();
		 
		 return prod.GetProducts();
	 }

	[WebMethod]
	 public Products GetProduct(int ProductId)
	 {
		 Products prod = new Products();

		 if (!prod.Load(ProductId))
		 {
			 prod = null;
		 }

		 return prod;
	 }

	[WebMethod]
	public int Insert(Products prod)
	{
		int intRet = 0;
		prod.ConnectString = AppConfig.ConnectString;

		try
		{
			intRet = prod.Insert();
		}

		catch 
		{
			throw;
		}

		return intRet;
	}

	[WebMethod]
	public int Update(Products prod)
	{
		int intRet = 0;
		prod.ConnectString = AppConfig.ConnectString;

		try
		{
			intRet = prod.Update();
		}

		catch 
		{
			throw;
		}
		return intRet;
	}

	[WebMethod]
	public int Delete(Products prod)
	{
		int intRet = 0;
		prod.ConnectString = AppConfig.ConnectString;

		try
		{
			intRet = prod.Delete();
		}

		catch
		{
			throw;
		}
		return intRet;
	}

}
