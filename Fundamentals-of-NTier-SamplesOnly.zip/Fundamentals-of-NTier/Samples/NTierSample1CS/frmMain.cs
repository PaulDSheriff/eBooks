using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace NTierSample1CS
{
	public partial class frmMain : Form
	{
		public frmMain()
		{
			InitializeComponent();
		}

		private void btnSample1_Click(object sender, EventArgs e)
		{
			frmSample1 frm = new frmSample1();

			frm.Show();
		}

		private void btnSample2_Click(object sender, EventArgs e)
		{
			frmSample2 frm = new frmSample2();

			frm.Show();
		}

		private void btnSample3_Click(object sender, EventArgs e)
		{
			frmSample3 frm = new frmSample3();

			frm.Show();
		}

		private void btnSample4_Click(object sender, EventArgs e)
		{
			frmSample4 frm = new frmSample4();

			frm.Show();
		}

		private void btnSample5_Click(object sender, EventArgs e)
		{
			frmSample5 frm = new frmSample5();

			frm.Show();
		}
	}
}