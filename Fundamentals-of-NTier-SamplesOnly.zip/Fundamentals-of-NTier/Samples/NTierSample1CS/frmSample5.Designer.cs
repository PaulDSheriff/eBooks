namespace NTierSample1CS
{
	partial class frmSample5
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.SuspendLayout();
			// 
			// lstProducts
			// 
			this.lstProducts.SelectedIndexChanged += new System.EventHandler(this.lstProducts_SelectedIndexChanged);
			// 
			// frmSample5
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
			this.ClientSize = new System.Drawing.Size(870, 353);
			this.Name = "frmSample5";
			this.Text = "Sample 5";
			this.Load += new System.EventHandler(this.frmSample5_Load);
			this.Controls.SetChildIndex(this.txtPrice, 0);
			this.Controls.SetChildIndex(this.txtCost, 0);
			this.Controls.SetChildIndex(this.dtpDateIntroduced, 0);
			this.Controls.SetChildIndex(this.txtProductName, 0);
			this.Controls.SetChildIndex(this.chkDiscontinued, 0);
			this.Controls.SetChildIndex(this.lstProducts, 0);
			this.Controls.SetChildIndex(this.lblProductID, 0);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
	}
}
