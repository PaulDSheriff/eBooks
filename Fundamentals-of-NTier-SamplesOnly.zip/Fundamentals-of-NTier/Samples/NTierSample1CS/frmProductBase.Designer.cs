namespace NTierSample1CS
{
	partial class frmProductBase
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.Label label1;
			System.Windows.Forms.Label label2;
			System.Windows.Forms.Label label3;
			System.Windows.Forms.Label label4;
			System.Windows.Forms.Label label5;
			this.lblProductID = new System.Windows.Forms.Label();
			this.lstProducts = new System.Windows.Forms.ListBox();
			this.btnClose = new System.Windows.Forms.Button();
			this.pnlButtons = new System.Windows.Forms.Panel();
			this.chkDiscontinued = new System.Windows.Forms.CheckBox();
			this.txtProductName = new System.Windows.Forms.TextBox();
			this.dtpDateIntroduced = new System.Windows.Forms.DateTimePicker();
			this.txtCost = new System.Windows.Forms.TextBox();
			this.txtPrice = new System.Windows.Forms.TextBox();
			label1 = new System.Windows.Forms.Label();
			label2 = new System.Windows.Forms.Label();
			label3 = new System.Windows.Forms.Label();
			label4 = new System.Windows.Forms.Label();
			label5 = new System.Windows.Forms.Label();
			this.pnlButtons.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Location = new System.Drawing.Point(401, 12);
			label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			label1.Name = "label1";
			label1.Size = new System.Drawing.Size(95, 20);
			label1.TabIndex = 27;
			label1.Text = "Product ID";
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.Location = new System.Drawing.Point(401, 61);
			label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			label2.Name = "label2";
			label2.Size = new System.Drawing.Size(122, 20);
			label2.TabIndex = 29;
			label2.Text = "Product Name";
			// 
			// label3
			// 
			label3.AutoSize = true;
			label3.Location = new System.Drawing.Point(401, 112);
			label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			label3.Name = "label3";
			label3.Size = new System.Drawing.Size(140, 20);
			label3.TabIndex = 31;
			label3.Text = "Date Introduced";
			// 
			// label4
			// 
			label4.AutoSize = true;
			label4.Location = new System.Drawing.Point(401, 160);
			label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			label4.Name = "label4";
			label4.Size = new System.Drawing.Size(46, 20);
			label4.TabIndex = 33;
			label4.Text = "Cost";
			// 
			// label5
			// 
			label5.AutoSize = true;
			label5.Location = new System.Drawing.Point(401, 209);
			label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			label5.Name = "label5";
			label5.Size = new System.Drawing.Size(49, 20);
			label5.TabIndex = 35;
			label5.Text = "Price";
			// 
			// lblProductID
			// 
			this.lblProductID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblProductID.Location = new System.Drawing.Point(557, 12);
			this.lblProductID.Name = "lblProductID";
			this.lblProductID.Size = new System.Drawing.Size(86, 22);
			this.lblProductID.TabIndex = 28;
			// 
			// lstProducts
			// 
			this.lstProducts.FormattingEnabled = true;
			this.lstProducts.ItemHeight = 20;
			this.lstProducts.Location = new System.Drawing.Point(12, 12);
			this.lstProducts.Name = "lstProducts";
			this.lstProducts.Size = new System.Drawing.Size(382, 284);
			this.lstProducts.TabIndex = 26;
			// 
			// btnClose
			// 
			this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnClose.Location = new System.Drawing.Point(781, 6);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(75, 36);
			this.btnClose.TabIndex = 2;
			this.btnClose.Text = "Close";
			this.btnClose.UseVisualStyleBackColor = true;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// pnlButtons
			// 
			this.pnlButtons.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlButtons.Controls.Add(this.btnClose);
			this.pnlButtons.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.pnlButtons.Location = new System.Drawing.Point(0, 306);
			this.pnlButtons.Name = "pnlButtons";
			this.pnlButtons.Size = new System.Drawing.Size(870, 47);
			this.pnlButtons.TabIndex = 38;
			// 
			// chkDiscontinued
			// 
			this.chkDiscontinued.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.chkDiscontinued.Location = new System.Drawing.Point(396, 253);
			this.chkDiscontinued.Name = "chkDiscontinued";
			this.chkDiscontinued.Size = new System.Drawing.Size(179, 32);
			this.chkDiscontinued.TabIndex = 37;
			this.chkDiscontinued.Text = "Discontinued?";
			this.chkDiscontinued.UseVisualStyleBackColor = true;
			// 
			// txtProductName
			// 
			this.txtProductName.Location = new System.Drawing.Point(561, 58);
			this.txtProductName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.txtProductName.Name = "txtProductName";
			this.txtProductName.Size = new System.Drawing.Size(300, 26);
			this.txtProductName.TabIndex = 30;
			// 
			// dtpDateIntroduced
			// 
			this.dtpDateIntroduced.Location = new System.Drawing.Point(561, 107);
			this.dtpDateIntroduced.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.dtpDateIntroduced.Name = "dtpDateIntroduced";
			this.dtpDateIntroduced.Size = new System.Drawing.Size(300, 26);
			this.dtpDateIntroduced.TabIndex = 32;
			// 
			// txtCost
			// 
			this.txtCost.Location = new System.Drawing.Point(561, 156);
			this.txtCost.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.txtCost.Name = "txtCost";
			this.txtCost.Size = new System.Drawing.Size(300, 26);
			this.txtCost.TabIndex = 34;
			// 
			// txtPrice
			// 
			this.txtPrice.Location = new System.Drawing.Point(561, 205);
			this.txtPrice.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.txtPrice.Name = "txtPrice";
			this.txtPrice.Size = new System.Drawing.Size(300, 26);
			this.txtPrice.TabIndex = 36;
			// 
			// frmProductBase
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(870, 353);
			this.Controls.Add(this.lblProductID);
			this.Controls.Add(this.lstProducts);
			this.Controls.Add(this.pnlButtons);
			this.Controls.Add(this.chkDiscontinued);
			this.Controls.Add(label1);
			this.Controls.Add(label2);
			this.Controls.Add(this.txtProductName);
			this.Controls.Add(label3);
			this.Controls.Add(this.dtpDateIntroduced);
			this.Controls.Add(label4);
			this.Controls.Add(this.txtCost);
			this.Controls.Add(label5);
			this.Controls.Add(this.txtPrice);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.Name = "frmProductBase";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "frmProductBase";
			this.pnlButtons.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		protected System.Windows.Forms.Label lblProductID;
		protected System.Windows.Forms.ListBox lstProducts;
		protected System.Windows.Forms.Button btnClose;
		internal System.Windows.Forms.Panel pnlButtons;
		protected System.Windows.Forms.CheckBox chkDiscontinued;
		protected System.Windows.Forms.TextBox txtProductName;
		protected System.Windows.Forms.DateTimePicker dtpDateIntroduced;
		protected System.Windows.Forms.TextBox txtCost;
		protected System.Windows.Forms.TextBox txtPrice;
	}
}