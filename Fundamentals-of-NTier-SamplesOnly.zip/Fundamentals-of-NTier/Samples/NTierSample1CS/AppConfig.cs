using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace NTierSample1CS
{
	class AppConfig
	{
		public static string ConnectString
		{
			get { return ConfigurationManager.ConnectionStrings["NTier"].ConnectionString; }
		}
	}
}
