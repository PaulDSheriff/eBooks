using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace NTierSample1CS
{
	public partial class frmSample5 : NTierSample1CS.frmProductBase
	{
		public frmSample5()
		{
			InitializeComponent();
		}

		ProductsVer3 mprod = new ProductsVer3();

		private void frmSample5_Load(object sender, EventArgs e)
		{
			ProductsLoad();
		}

		private void ProductsLoad()
		{
			lstProducts.ValueMember = "iProduct_id";
			lstProducts.DisplayMember = "sProductName";

			lstProducts.DataSource = mprod.GetProducts().Tables[0];
		}

		private void lstProducts_SelectedIndexChanged(object sender, EventArgs e)
		{
			FormShow();
		}

		private void FormShow()
		{
			DataTable dt;
			DataRow dr;

			dt = mprod.GetProduct(
				  Convert.ToInt32(lstProducts.SelectedValue)).Tables[0];

			dr = dt.Rows[0];

			lblProductID.Text = dr["iProduct_ID"].ToString();
			txtProductName.Text = dr["sProductName"].ToString();
			dtpDateIntroduced.Value = Convert.ToDateTime(dr["dtIntroduced"]);
			txtCost.Text = dr["cCost"].ToString();
			txtPrice.Text = dr["cPrice"].ToString();
			chkDiscontinued.Checked = Convert.ToBoolean(dr["bDiscontinued"]);
		}
	}
}

