using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace NTierSample1CS
{
	class ProductsVer3
	{
		public DataSet GetProducts()
		{
			return GetProducts("SELECT * FROM tblProducts");
		}

		public DataSet GetProducts(string SQL)
		{
			DataSet ds;

			// Use the DataLayer to Build DataSet
			ds = DataLayer.GetDataSet(SQL, AppConfig.ConnectString);

			return ds;
		}

		public DataSet GetProduct(int ProductID)
		{
			string strSQL;

			strSQL = "SELECT * FROM tblProducts";
			strSQL += " WHERE iProduct_id = " + ProductID.ToString();

			return GetProducts(strSQL);
		}
	}
}
