using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace NTierSample1CS
{
	class ProductsVer2
	{
		public DataSet GetProducts()
		{
			return GetProducts("SELECT * FROM tblProducts");
		}

		public DataSet GetProducts(string SQL)
		{
			DataSet ds = new DataSet();
			SqlDataAdapter da = new SqlDataAdapter();

			// Use AppConfig class to get Connect String
			da = new SqlDataAdapter(SQL, AppConfig.ConnectString);

			da.Fill(ds);

			return ds;
		}

		public DataSet GetProduct(int ProductID)
		{
			string strSQL;

			strSQL = "SELECT * FROM tblProducts";
			strSQL += " WHERE iProduct_id = " + ProductID.ToString();

			return GetProducts(strSQL);
		}
	}
}
