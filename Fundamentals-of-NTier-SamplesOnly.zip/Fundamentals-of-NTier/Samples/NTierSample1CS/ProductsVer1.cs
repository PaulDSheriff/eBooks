using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace NTierSample1CS
{
	class ProductsVer1
	{
		public DataSet GetProducts()
		{
			return GetProducts("SELECT * FROM tblProducts");
		}

		public DataSet GetProducts(string SQL)
		{
			DataSet ds = new DataSet();
			SqlDataAdapter da = new SqlDataAdapter();

			da = new SqlDataAdapter(SQL, GetConnectString());

			da.Fill(ds);

			return ds;
		}

		public DataSet GetProduct(int ProductID)
		{
			string strSQL;

			strSQL = "SELECT * FROM tblProducts";
			strSQL += " WHERE iProduct_id = " + ProductID.ToString();

			return GetProducts(strSQL);
		}

		protected string GetConnectString()
		{
			return "Server=Localhost;Database=NTier-eBook;"
			 + "Integrated Security=SSPI";
		}
	}
}
