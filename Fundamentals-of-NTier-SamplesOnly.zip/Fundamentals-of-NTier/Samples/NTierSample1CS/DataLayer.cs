using System;
using System.Collections.Generic;
using System.Text;

using System.Data;
using System.Data.SqlClient;

namespace NTierSample1CS
{
	class DataLayer
	{
		public static DataSet GetDataSet(string SQL, string ConnectString)
		{
			DataSet ds = new DataSet();
			SqlDataAdapter da = new SqlDataAdapter();

			da = new SqlDataAdapter(SQL, ConnectString);

			da.Fill(ds);

			return ds;
		}

		public static DataTable GetDataTable(string SQL, string ConnectString)
		{
			DataSet ds = new DataSet();
			DataTable dt = null;

			ds = GetDataSet(SQL, ConnectString);

			if (ds.Tables.Count > 0)
			{
				dt = ds.Tables[0];
			}

			return dt;
		}
	}
}
