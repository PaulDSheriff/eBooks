using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace NTierSample1CS
{
	public partial class frmSample1 : NTierSample1CS.frmProductBase
	{
		public frmSample1()
		{
			InitializeComponent();
		}

		private void frmSample1_Load(object sender, EventArgs e)
		{
			ProductsLoad();
		}

		private void ProductsLoad()
		{
			DataTable dt = new DataTable();
			SqlDataAdapter da = new SqlDataAdapter();
			string strSQL;
			string strConn;

			strSQL = "SELECT * FROM tblProducts";
			strConn = "Server=Localhost;Database=NTier-eBook;Integrated Security=SSPI";

			// Create a method to retrieve the connection string
			da = new SqlDataAdapter(strSQL, strConn);

			da.Fill(dt);

			lstProducts.ValueMember = "iProduct_id";
			lstProducts.DisplayMember = "sProductName";
			lstProducts.DataSource = dt;
		}

		private void lstProducts_SelectedIndexChanged(object sender, EventArgs e)
		{
			FormShow();
		}

		private void FormShow()
		{
			DataTable dt = new DataTable();
			SqlDataAdapter da = new SqlDataAdapter();
			DataRow dr;
			string strSQL;
			string strConn;

			strSQL = "SELECT * FROM tblProducts";
			strSQL += " WHERE iProduct_id = " + lstProducts.SelectedValue.ToString();
			strConn = "Server=Localhost;Database=NTier-eBook;Integrated Security=SSPI";

			da = new SqlDataAdapter(strSQL, strConn);

			da.Fill(dt);

			dr = dt.Rows[0];
			lblProductID.Text = dr["iProduct_ID"].ToString();
			txtProductName.Text = dr["sProductName"].ToString();
			dtpDateIntroduced.Value = Convert.ToDateTime(dr["dtIntroduced"]);
			txtCost.Text = dr["cCost"].ToString();
			txtPrice.Text = dr["cPrice"].ToString();
			chkDiscontinued.Checked = Convert.ToBoolean(dr["bDiscontinued"]);
		}
	}
}

