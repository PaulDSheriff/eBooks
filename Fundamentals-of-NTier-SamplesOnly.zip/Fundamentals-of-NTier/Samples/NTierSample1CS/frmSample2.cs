using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace NTierSample1CS
{
	public partial class frmSample2 : NTierSample1CS.frmProductBase
	{
		public frmSample2()
		{
			InitializeComponent();
		}

		private void frmSample2_Load(object sender, EventArgs e)
		{
			ProductsLoad();
		}

		private void ProductsLoad()
		{
			lstProducts.ValueMember = "iProduct_id";
			lstProducts.DisplayMember = "sProductName";
			lstProducts.DataSource = GetAllProducts();
		}

		private DataTable GetAllProducts()
		{
			return GetProducts("SELECT * FROM tblProducts");
		}

		private DataTable GetProducts(string SQL)
		{
			DataTable dt = new DataTable();
			SqlDataAdapter da = new SqlDataAdapter();

			da = new SqlDataAdapter(SQL, GetConnectString());

			da.Fill(dt);

			return dt;
		}

		private string GetConnectString()
		{
			return "Server=Localhost;Database=NTier-eBook;"
			 + "Integrated Security=SSPI";
		}

		private void lstProducts_SelectedIndexChanged(object sender, EventArgs e)
		{
			FormShow();
		}

		private void FormShow()
		{
			DataTable dt = new DataTable();
			DataRow dr;

			dt = GetAProduct(Convert.ToInt32(lstProducts.SelectedValue));

			dr = dt.Rows[0];

			lblProductID.Text = dr["iProduct_ID"].ToString();
			txtProductName.Text = dr["sProductName"].ToString();
			dtpDateIntroduced.Value = Convert.ToDateTime(dr["dtIntroduced"]);
			txtCost.Text = dr["cCost"].ToString();
			txtPrice.Text = dr["cPrice"].ToString();
			chkDiscontinued.Checked = Convert.ToBoolean(dr["bDiscontinued"]);
		}


		private DataTable GetAProduct(int ProductID)
		{
			string strSQL;

			strSQL = "SELECT * FROM tblProducts";
			strSQL += " WHERE iProduct_id = " + ProductID.ToString();

			return GetProducts(strSQL);
		}
	}
}

