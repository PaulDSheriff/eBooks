<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSample2
	Inherits NTierSample1.frmProductBase

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing AndAlso components IsNot Nothing Then
			components.Dispose()
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.SuspendLayout()
		'
		'lstProducts
		'
		'
		'frmSample2
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 20.0!)
		Me.ClientSize = New System.Drawing.Size(944, 357)
		Me.Name = "frmSample2"
		Me.Text = "Sample 2"
		Me.Controls.SetChildIndex(Me.txtPrice, 0)
		Me.Controls.SetChildIndex(Me.txtCost, 0)
		Me.Controls.SetChildIndex(Me.dtpDateIntroduced, 0)
		Me.Controls.SetChildIndex(Me.txtProductName, 0)
		Me.Controls.SetChildIndex(Me.chkDiscontinued, 0)
		Me.Controls.SetChildIndex(Me.lstProducts, 0)
		Me.Controls.SetChildIndex(Me.lblProductID, 0)
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub

End Class
