Imports System.Data.SqlClient

Public Class DataLayer
	Public Shared Function GetDataSet(ByVal SQL As String, _
	 ByVal ConnectString As String) As DataSet
		Dim ds As New DataSet
		Dim da As SqlDataAdapter

		da = New SqlDataAdapter(SQL, ConnectString)

		da.Fill(ds)

		Return ds
	End Function

	Public Shared Function GetDataTable(ByVal SQL As String, _
	 ByVal ConnectString As String) As DataTable
		Dim ds As DataSet
		Dim dt As DataTable = Nothing

		ds = GetDataSet(SQL, ConnectString)

		If ds.Tables.Count > 0 Then
			dt = ds.Tables(0)
		End If

		Return dt
	End Function
End Class
