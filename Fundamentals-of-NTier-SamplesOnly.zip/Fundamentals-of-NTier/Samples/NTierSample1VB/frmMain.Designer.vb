<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Me.btnSample1 = New System.Windows.Forms.Button
		Me.btnSample2 = New System.Windows.Forms.Button
		Me.btnSample3 = New System.Windows.Forms.Button
		Me.btnSample4 = New System.Windows.Forms.Button
		Me.btnSample5 = New System.Windows.Forms.Button
		Me.SuspendLayout()
		'
		'btnSample1
		'
		Me.btnSample1.Location = New System.Drawing.Point(12, 12)
		Me.btnSample1.Name = "btnSample1"
		Me.btnSample1.Size = New System.Drawing.Size(122, 55)
		Me.btnSample1.TabIndex = 0
		Me.btnSample1.Text = "Sample 1"
		Me.btnSample1.UseVisualStyleBackColor = True
		'
		'btnSample2
		'
		Me.btnSample2.Location = New System.Drawing.Point(152, 12)
		Me.btnSample2.Name = "btnSample2"
		Me.btnSample2.Size = New System.Drawing.Size(122, 55)
		Me.btnSample2.TabIndex = 1
		Me.btnSample2.Text = "Sample 2"
		Me.btnSample2.UseVisualStyleBackColor = True
		'
		'btnSample3
		'
		Me.btnSample3.Location = New System.Drawing.Point(292, 12)
		Me.btnSample3.Name = "btnSample3"
		Me.btnSample3.Size = New System.Drawing.Size(122, 55)
		Me.btnSample3.TabIndex = 2
		Me.btnSample3.Text = "Sample 3"
		Me.btnSample3.UseVisualStyleBackColor = True
		'
		'btnSample4
		'
		Me.btnSample4.Location = New System.Drawing.Point(12, 86)
		Me.btnSample4.Name = "btnSample4"
		Me.btnSample4.Size = New System.Drawing.Size(122, 55)
		Me.btnSample4.TabIndex = 3
		Me.btnSample4.Text = "Sample 4"
		Me.btnSample4.UseVisualStyleBackColor = True
		'
		'btnSample5
		'
		Me.btnSample5.Location = New System.Drawing.Point(152, 86)
		Me.btnSample5.Name = "btnSample5"
		Me.btnSample5.Size = New System.Drawing.Size(122, 55)
		Me.btnSample5.TabIndex = 4
		Me.btnSample5.Text = "Sample 5"
		Me.btnSample5.UseVisualStyleBackColor = True
		'
		'frmMain
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 20.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(433, 152)
		Me.Controls.Add(Me.btnSample5)
		Me.Controls.Add(Me.btnSample4)
		Me.Controls.Add(Me.btnSample3)
		Me.Controls.Add(Me.btnSample2)
		Me.Controls.Add(Me.btnSample1)
		Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
		Me.Name = "frmMain"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "N-Tier Samples"
		Me.ResumeLayout(False)

	End Sub
	Friend WithEvents btnSample1 As System.Windows.Forms.Button
	Friend WithEvents btnSample2 As System.Windows.Forms.Button
	Friend WithEvents btnSample3 As System.Windows.Forms.Button
	Friend WithEvents btnSample4 As System.Windows.Forms.Button
	Friend WithEvents btnSample5 As System.Windows.Forms.Button
End Class
