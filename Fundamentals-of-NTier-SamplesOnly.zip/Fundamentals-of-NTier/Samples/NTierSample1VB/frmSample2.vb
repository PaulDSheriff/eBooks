Imports System.Data.SqlClient

Public Class frmSample2
	Private Sub frmSample2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
		ProductsLoad()
	End Sub

	Private Sub ProductsLoad()
		lstProducts.ValueMember = "iProduct_id"
		lstProducts.DisplayMember = "sProductName"
		lstProducts.DataSource = GetAllProducts()
	End Sub

	Private Function GetAllProducts() As DataTable
		Return GetProducts("SELECT * FROM tblProducts")
	End Function

	Private Function GetProducts(ByVal SQL As String) As DataTable
		Dim dt As New DataTable
		Dim da As SqlDataAdapter

		da = New SqlDataAdapter(SQL, GetConnectString())

		da.Fill(dt)

		Return dt
	End Function

	Private Function GetConnectString() As String
		Return "Server=Localhost;Database=NTier-eBook;" _
		 & "Integrated Security=SSPI"
	End Function


	Private Sub lstProducts_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstProducts.SelectedIndexChanged
		FormShow()
	End Sub

	Private Sub FormShow()
		Dim dt As New DataTable
		Dim dr As DataRow

		dt = GetAProduct(Convert.ToInt32(lstProducts.SelectedValue))

		dr = dt.Rows(0)

		lblProductID.Text = dr("iProduct_ID").ToString()
		txtProductName.Text = dr("sProductName").ToString()
		dtpDateIntroduced.Value = Convert.ToDateTime(dr("dtIntroduced"))
		txtCost.Text = dr("cCost").ToString()
		txtPrice.Text = dr("cPrice").ToString()
		chkDiscontinued.Checked = Convert.ToBoolean(dr("bDiscontinued"))
	End Sub

	Private Function GetAProduct(ByVal ProductID As Integer) As DataTable
		Dim strSQL As String

		strSQL = "SELECT * FROM tblProducts"
		strSQL &= " WHERE iProduct_id = " & ProductID.ToString()

		Return GetProducts(strSQL)
	End Function
End Class