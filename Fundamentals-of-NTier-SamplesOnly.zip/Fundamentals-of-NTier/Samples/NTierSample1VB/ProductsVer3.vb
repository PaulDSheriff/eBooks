Public Class ProductsVer3
	Public Function GetProducts() As DataSet
		Return GetProducts("SELECT * FROM tblProducts")
	End Function

	Public Function GetProducts(ByVal SQL As String) As DataSet
		Dim ds As DataSet

		' Use the DataLayer to Build DataSet
		ds = DataLayer.GetDataSet(SQL, AppConfig.ConnectString)

		Return ds
	End Function

	Public Function GetProduct(ByVal ProductID As Integer) As DataSet
		Dim strSQL As String

		strSQL = "SELECT * FROM tblProducts"
		strSQL &= " WHERE iProduct_id = " & ProductID.ToString()

		Return GetProducts(strSQL)
	End Function
End Class
