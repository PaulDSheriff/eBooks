Imports System.Data.SqlClient

Public Class ProductsVer1
	Public Function GetProducts() As DataSet
		Return GetProducts("SELECT * FROM tblProducts")
	End Function

	Public Function GetProducts(ByVal SQL As String) As DataSet
		Dim ds As New DataSet
		Dim da As SqlDataAdapter

		da = New SqlDataAdapter(SQL, GetConnectString())

		da.Fill(ds)

		Return ds
	End Function

	Public Function GetProduct(ByVal ProductID As Integer) As DataSet
		Dim strSQL As String

		strSQL = "SELECT * FROM tblProducts"
		strSQL &= " WHERE iProduct_id = " & ProductID.ToString()

		Return GetProducts(strSQL)
	End Function

	Protected Function GetConnectString() As String
		Return "Server=Localhost;Database=NTier-eBook;" _
		 & "Integrated Security=SSPI"
	End Function
End Class
