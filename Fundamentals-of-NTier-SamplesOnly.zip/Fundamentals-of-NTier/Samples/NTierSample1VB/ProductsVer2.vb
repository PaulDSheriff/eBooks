Imports System.Data.SqlClient

Public Class ProductsVer2
	Public Function GetProducts() As DataSet
		Return GetProducts("SELECT * FROM tblProducts")
	End Function

	Public Function GetProducts(ByVal SQL As String) As DataSet
		Dim ds As New DataSet
		Dim da As SqlDataAdapter

		' Use AppConfig class to get Connect String
		da = New SqlDataAdapter(SQL, AppConfig.ConnectString)

		da.Fill(ds)

		Return ds
	End Function

	Public Function GetProduct(ByVal ProductID As Integer) As DataSet
		Dim strSQL As String

		strSQL = "SELECT * FROM tblProducts"
		strSQL &= " WHERE iProduct_id = " & ProductID.ToString()

		Return GetProducts(strSQL)
	End Function
End Class
