Public Class frmMain

	Private Sub btnSample1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSample1.Click
		Dim frm As New frmSample1

		frm.Show()
	End Sub

	Private Sub btnSample2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSample2.Click
		Dim frm As New frmSample2

		frm.Show()
	End Sub

	Private Sub btnSample3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSample3.Click
		Dim frm As New frmSample3

		frm.Show()
	End Sub

	Private Sub btnSample4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSample4.Click
		Dim frm As New frmSample4

		frm.Show()
	End Sub

	Private Sub btnSample5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSample5.Click
		Dim frm As New frmSample5

		frm.Show()
	End Sub
End Class