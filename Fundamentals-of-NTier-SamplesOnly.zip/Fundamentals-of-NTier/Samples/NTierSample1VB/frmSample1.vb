Imports System.Data.SqlClient

Public Class frmSample1

	Private Sub frmSample1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
		ProductsLoad()
	End Sub

	Private Sub ProductsLoad()
		Dim dt As New DataTable
		Dim da As SqlDataAdapter
		Dim strSQL As String
		Dim strConn As String

		strSQL = "SELECT * FROM tblProducts"
		strConn = "Server=Localhost;Database=NTier-eBook;" _
		 & "Integrated Security=SSPI"

		da = New SqlDataAdapter(strSQL, strConn)

		da.Fill(dt)

		lstProducts.ValueMember = "iProduct_id"
		lstProducts.DisplayMember = "sProductName"
		lstProducts.DataSource = dt
	End Sub

	Private Sub lstProducts_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstProducts.SelectedIndexChanged
		FormShow()
	End Sub

	Private Sub FormShow()
		Dim dt As New DataTable
		Dim dr As DataRow
		Dim da As SqlDataAdapter
		Dim strSQL As String
		Dim strConn As String

		strSQL = "SELECT * FROM tblProducts "
		strSQL &= " WHERE iProduct_id = " & lstProducts.SelectedValue.ToString()

		strConn = "Server=Localhost;Database=NTier-eBook;" _
		 & "Integrated Security=SSPI"

		da = New SqlDataAdapter(strSQL, strConn)

		da.Fill(dt)

		dr = dt.Rows(0)

		lblProductID.Text = dr("iProduct_ID").ToString()
		txtProductName.Text = dr("sProductName").ToString()
		dtpDateIntroduced.Value = Convert.ToDateTime(dr("dtIntroduced"))
		txtCost.Text = dr("cCost").ToString()
		txtPrice.Text = dr("cPrice").ToString()
		chkDiscontinued.Checked = Convert.ToBoolean(dr("bDiscontinued"))
	End Sub
End Class
