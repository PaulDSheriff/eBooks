Public Class frmSample3
	Private mprod As New ProductsVer1

	Private Sub frmSample3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
		ProductsLoad()
	End Sub

	Private Sub ProductsLoad()
		lstProducts.ValueMember = "iProduct_id"
		lstProducts.DisplayMember = "sProductName"

		lstProducts.DataSource = mprod.GetProducts().Tables(0)
	End Sub

	Private Sub lstProducts_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstProducts.SelectedIndexChanged
		FormShow()
	End Sub

	Private Sub FormShow()
		Dim dt As DataTable
		Dim dr As DataRow

		dt = mprod.GetProduct( _
		 Convert.ToInt32(lstProducts.SelectedValue)).Tables(0)

		dr = dt.Rows(0)

		lblProductID.Text = dr("iProduct_ID").ToString()
		txtProductName.Text = dr("sProductName").ToString()
		dtpDateIntroduced.Value = Convert.ToDateTime(dr("dtIntroduced"))
		txtCost.Text = dr("cCost").ToString()
		txtPrice.Text = dr("cPrice").ToString()
		chkDiscontinued.Checked = Convert.ToBoolean(dr("bDiscontinued"))
	End Sub
End Class