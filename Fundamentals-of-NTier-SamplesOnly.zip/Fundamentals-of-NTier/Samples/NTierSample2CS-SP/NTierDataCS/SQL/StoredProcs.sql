/* Get All Products */
CREATE PROCEDURE procGetAllProducts
AS
SELECT * FROM tblProducts
GO

/* Get a Single Product */
CREATE PROCEDURE procGetAProduct
	@iProduct_id int
AS
SELECT * FROM tblProducts
WHERE iProduct_id = @iProduct_id
GO

/* INSERT into Products Table */
CREATE PROCEDURE procProducts_insert
	@sProductName varchar(50), 
  @dtIntroduced DateTime, 
  @cCost money, 
  @cPrice money, 
  @bDiscontinued tinyint 
AS
INSERT INTO tblProducts (
	sProductName, 
  dtIntroduced, 
  cCost, 
  cPrice, 
  bDiscontinued 
)
VALUES (
	@sProductName, 
  @dtIntroduced, 
  @cCost, 
  @cPrice, 
  @bDiscontinued 
)
GO

/* UPDATE Products Table */
CREATE PROCEDURE procProducts_update
	@sProductName varchar(50) ,
  @dtIntroduced DateTime ,
  @cCost money ,
  @cPrice money ,
  @bDiscontinued tinyint ,
	@iProduct_id int  
AS
UPDATE tblProducts
SET 
	sProductName = @sProductName, 
  dtIntroduced = @dtIntroduced, 
  cCost = @cCost, 
  cPrice = @cPrice, 
  bDiscontinued = @bDiscontinued 
WHERE
iProduct_id = @iProduct_id  
GO

/* DELETE a row from Products Table */
CREATE PROCEDURE procProducts_delete
	@iProduct_id int  
AS
DELETE FROM tblProducts
WHERE
iProduct_id = @iProduct_id  

