using System;
using System.Collections.Generic;
using System.Text;

using System.Data;
using DataCommonCS;

namespace NTierDataCS
{
	[Serializable]
	public abstract class ProductsDC
	{
		public ProductsDC.SchemaStruct Schema;
		private string mstrConnectString;

		public ProductsDC()
		{
			Schema = new ProductsDC.SchemaStruct();

			Schema.ObjectName = "tblProducts";
			Schema.ProductId = "iProduct_id";
			Schema.ProductName = "sProductName";
			Schema.Discontinued = "bDiscontinued";
			Schema.Introduced = "dtIntroduced";
			Schema.Price = "cPrice";
			Schema.Cost = "cCost";
		}

		public string ConnectString
		{
			get { return mstrConnectString; }
			set { mstrConnectString = value; }
		}

		#region "Private fields"
		private int mintProductId;
		private string mstrProductName;
		private string mstrIntroduced;
		private decimal mdecCost;
		private decimal mdecPrice;
		private bool mboolDiscontinued;
		#endregion

		#region "Column Properties"
		public int ProductId
		{
			get { return mintProductId; }
			set { mintProductId = value; }
		}

		public string ProductName
		{
			get { return mstrProductName; }
			set { mstrProductName = value; }
		}

		public string Introduced
		{
			get { return mstrIntroduced; }
			set { mstrIntroduced = value; }
		}

		public decimal Cost
		{
			get { return mdecCost; }
			set { mdecCost = value; }
		}

		public decimal Price
		{
			get { return mdecPrice; }
			set { mdecPrice = value; }
		}

		public bool Discontinued
		{
			get { return mboolDiscontinued; }
			set { mboolDiscontinued = value; }
		}
		#endregion

		#region "Data Retrieval Methods"
		public DataSet GetProducts()
		{
			DataSet ds = null;
			string strSQL;

			strSQL = "procGetAllProducts";

			// Use the DataLayer to Build DataTable
			ds = DataLayer.GetDataSet(strSQL, mstrConnectString);

			return ds;
		}

		public DataSet GetProduct(int ProductID)
		{
			IDbCommand cmd;
			DataSet ds = null;
			string strSQL;

			strSQL = "procGetAProduct";

			cmd = DataLayer.CreateCommand(strSQL, mstrConnectString);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Parameters.Add(DataLayer.CreateParameter("@iProduct_id",
				DbType.Int32, ProductID));

			// Use the DataLayer to Build DataSet
			ds = DataLayer.GetDataSet(cmd);

			return ds;
		}

		public bool Load(int ProductID)
		{
			DataSet ds = null;
			DataRow dr;
			bool boolRet = false;

			ds = GetProduct(ProductID);
			if (ds != null)
			{
				if (ds.Tables.Count > 0)
				{
					boolRet = true;

					dr = ds.Tables[0].Rows[0];

					mintProductId = Convert.ToInt32(dr[this.Schema.ProductId]);
					mstrProductName = dr[this.Schema.ProductName].ToString();
					mstrIntroduced = dr[this.Schema.Introduced].ToString();
					mdecCost = Convert.ToDecimal(dr[this.Schema.Cost]);
					mdecPrice = Convert.ToDecimal(dr[this.Schema.Price]);
					mboolDiscontinued = Convert.ToBoolean(dr[this.Schema.Discontinued]);
				}
			}
			return boolRet;
		}
		#endregion

		#region "Data Modification Methods"
		public virtual void Validate()
		{
			string strMsg = string.Empty;

			if (mstrProductName.Trim() == string.Empty)
			{
				strMsg += "Product Name Must Be Filled In" + Environment.NewLine;
			}

			if (mstrIntroduced.Trim() != string.Empty)
			{
				if (!IsDate(mstrIntroduced))
				{
					strMsg += "Date Introduced is not a valid Date" + Environment.NewLine;
				}
			}

			if (strMsg != string.Empty)
			{
				throw new BusinessRuleException(strMsg);
			}
		}

		protected bool IsDate(string Value)
		{
			DateTime dt;
			bool boolRet;

			try
			{
				dt = Convert.ToDateTime(Value);
				boolRet = true;
			}
			catch
			{
				boolRet = false;
			}

			return boolRet;
		}

		public int Insert()
		{
			IDbCommand cmd;
			string strSQL;

			// Check Business Rules
			Validate();

			strSQL = "procProducts_insert";

			cmd = DataLayer.CreateCommand(strSQL, mstrConnectString);

			FillInParameters(cmd);

			return DataLayer.ExecuteSQL(cmd, true);
		}

		public int Update()
		{
			IDbCommand cmd;
			string strSQL;

			// Check Business Rules
			Validate();

			strSQL = "procProducts_update";

			cmd = DataLayer.CreateCommand(strSQL, mstrConnectString);
			cmd.Parameters.Add(DataLayer.CreateParameter("@iProduct_id",
				DbType.Int32, mintProductId));

			FillInParameters(cmd);

			return DataLayer.ExecuteSQL(cmd, true);
		}

		public int Delete()
		{
			IDbCommand cmd;
			string strSQL;

			strSQL = "procProducts_delete";

			cmd = DataLayer.CreateCommand(strSQL, mstrConnectString);

			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Parameters.Add(DataLayer.CreateParameter("@iProduct_id",
				 DbType.Int32, mintProductId));

			return DataLayer.ExecuteSQL(cmd, true);
		}

		protected void FillInParameters(IDbCommand cmd)
		{
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Parameters.Add(DataLayer.CreateParameter(
			 "@sProductName", DbType.String, mstrProductName));
			cmd.Parameters.Add(DataLayer.CreateParameter(
			 "@dtIntroduced", DbType.DateTime, mstrIntroduced));
			cmd.Parameters.Add(DataLayer.CreateParameter(
			 "@cCost", DbType.Decimal, mdecCost));
			cmd.Parameters.Add(DataLayer.CreateParameter(
			 "@cPrice", DbType.Decimal, mdecPrice));
			cmd.Parameters.Add(DataLayer.CreateParameter(
			 "@bDiscontinued", DbType.Decimal, mboolDiscontinued));
		}
		#endregion

		#region "Schema Structure to return Object and Column Names"
		[Serializable]
		public struct SchemaStruct
		{
			public string ObjectName;
			public string ProductId;
			public string ProductName;
			public string Introduced;
			public string Cost;
			public string Price;
			public string Discontinued;
		}
		#endregion
	}
}
