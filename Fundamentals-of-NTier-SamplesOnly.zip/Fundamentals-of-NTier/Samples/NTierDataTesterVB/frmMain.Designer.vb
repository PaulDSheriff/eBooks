<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing AndAlso components IsNot Nothing Then
			components.Dispose()
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.btnGetDataTable = New System.Windows.Forms.Button
		Me.grdResults = New System.Windows.Forms.DataGridView
		Me.btnExecuteScalar = New System.Windows.Forms.Button
		Me.txtScalar = New System.Windows.Forms.TextBox
		Me.btnExecuteSQL2 = New System.Windows.Forms.Button
		Me.btnExecuteSQL3 = New System.Windows.Forms.Button
		Me.btnExecuteSQL1 = New System.Windows.Forms.Button
		Me.txtResult = New System.Windows.Forms.TextBox
		Me.btnGetDataReader = New System.Windows.Forms.Button
		Me.txtScalarResult = New System.Windows.Forms.TextBox
		Me.label5 = New System.Windows.Forms.Label
		Me.label4 = New System.Windows.Forms.Label
		Me.label3 = New System.Windows.Forms.Label
		Me.txtSELECT = New System.Windows.Forms.TextBox
		Me.lstProducts = New System.Windows.Forms.ListBox
		Me.label2 = New System.Windows.Forms.Label
		Me.tabPage1 = New System.Windows.Forms.TabPage
		Me.grpRetrieve = New System.Windows.Forms.GroupBox
		Me.btnGetDataSet = New System.Windows.Forms.Button
		Me.tabControl1 = New System.Windows.Forms.TabControl
		Me.tabPage2 = New System.Windows.Forms.TabPage
		Me.grpDataModifcation = New System.Windows.Forms.GroupBox
		Me.btnExecuteSQL4 = New System.Windows.Forms.Button
		Me.txtConnectString = New System.Windows.Forms.TextBox
		Me.label1 = New System.Windows.Forms.Label
		Me.TabPage3 = New System.Windows.Forms.TabPage
		Me.btnInterface1 = New System.Windows.Forms.Button
		CType(Me.grdResults, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.tabPage1.SuspendLayout()
		Me.grpRetrieve.SuspendLayout()
		Me.tabControl1.SuspendLayout()
		Me.tabPage2.SuspendLayout()
		Me.grpDataModifcation.SuspendLayout()
		Me.TabPage3.SuspendLayout()
		Me.SuspendLayout()
		'
		'btnGetDataTable
		'
		Me.btnGetDataTable.Location = New System.Drawing.Point(259, 25)
		Me.btnGetDataTable.Name = "btnGetDataTable"
		Me.btnGetDataTable.Size = New System.Drawing.Size(224, 71)
		Me.btnGetDataTable.TabIndex = 11
		Me.btnGetDataTable.Text = "GetDataTable(SQL, ConnectString)"
		Me.btnGetDataTable.UseVisualStyleBackColor = True
		'
		'grdResults
		'
		Me.grdResults.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
		Me.grdResults.Location = New System.Drawing.Point(18, 179)
		Me.grdResults.Name = "grdResults"
		Me.grdResults.Size = New System.Drawing.Size(606, 133)
		Me.grdResults.TabIndex = 9
		'
		'btnExecuteScalar
		'
		Me.btnExecuteScalar.Location = New System.Drawing.Point(18, 102)
		Me.btnExecuteScalar.Name = "btnExecuteScalar"
		Me.btnExecuteScalar.Size = New System.Drawing.Size(224, 71)
		Me.btnExecuteScalar.TabIndex = 13
		Me.btnExecuteScalar.Text = "ExecuteScalar(SQL, ConnectString)"
		Me.btnExecuteScalar.UseVisualStyleBackColor = True
		'
		'txtScalar
		'
		Me.txtScalar.Location = New System.Drawing.Point(170, 84)
		Me.txtScalar.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
		Me.txtScalar.Name = "txtScalar"
		Me.txtScalar.Size = New System.Drawing.Size(636, 26)
		Me.txtScalar.TabIndex = 13
		Me.txtScalar.Text = "SELECT Count(*) FROM tblProducts"
		'
		'btnExecuteSQL2
		'
		Me.btnExecuteSQL2.Location = New System.Drawing.Point(258, 25)
		Me.btnExecuteSQL2.Name = "btnExecuteSQL2"
		Me.btnExecuteSQL2.Size = New System.Drawing.Size(224, 71)
		Me.btnExecuteSQL2.TabIndex = 13
		Me.btnExecuteSQL2.Text = "ExecuteSQL(cmd)"
		Me.btnExecuteSQL2.UseVisualStyleBackColor = True
		'
		'btnExecuteSQL3
		'
		Me.btnExecuteSQL3.Location = New System.Drawing.Point(501, 25)
		Me.btnExecuteSQL3.Name = "btnExecuteSQL3"
		Me.btnExecuteSQL3.Size = New System.Drawing.Size(224, 71)
		Me.btnExecuteSQL3.TabIndex = 12
		Me.btnExecuteSQL3.Text = "ExecuteSQL(SQL, ConnectString)"
		Me.btnExecuteSQL3.UseVisualStyleBackColor = True
		'
		'btnExecuteSQL1
		'
		Me.btnExecuteSQL1.Location = New System.Drawing.Point(20, 25)
		Me.btnExecuteSQL1.Name = "btnExecuteSQL1"
		Me.btnExecuteSQL1.Size = New System.Drawing.Size(224, 71)
		Me.btnExecuteSQL1.TabIndex = 11
		Me.btnExecuteSQL1.Text = "ExecuteSQL(cmd, DisposeOfCommand)"
		Me.btnExecuteSQL1.UseVisualStyleBackColor = True
		'
		'txtResult
		'
		Me.txtResult.Location = New System.Drawing.Point(177, 210)
		Me.txtResult.Name = "txtResult"
		Me.txtResult.Size = New System.Drawing.Size(77, 26)
		Me.txtResult.TabIndex = 3
		'
		'btnGetDataReader
		'
		Me.btnGetDataReader.Location = New System.Drawing.Point(502, 25)
		Me.btnGetDataReader.Name = "btnGetDataReader"
		Me.btnGetDataReader.Size = New System.Drawing.Size(224, 71)
		Me.btnGetDataReader.TabIndex = 12
		Me.btnGetDataReader.Text = "GetDataReader(SQL, ConnectString)"
		Me.btnGetDataReader.UseVisualStyleBackColor = True
		'
		'txtScalarResult
		'
		Me.txtScalarResult.Location = New System.Drawing.Point(342, 124)
		Me.txtScalarResult.Name = "txtScalarResult"
		Me.txtScalarResult.Size = New System.Drawing.Size(77, 26)
		Me.txtScalarResult.TabIndex = 16
		'
		'label5
		'
		Me.label5.AutoSize = True
		Me.label5.Location = New System.Drawing.Point(264, 127)
		Me.label5.Name = "label5"
		Me.label5.Size = New System.Drawing.Size(61, 20)
		Me.label5.TabIndex = 15
		Me.label5.Text = "Result"
		'
		'label4
		'
		Me.label4.AutoSize = True
		Me.label4.Location = New System.Drawing.Point(9, 89)
		Me.label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		Me.label4.Name = "label4"
		Me.label4.Size = New System.Drawing.Size(133, 20)
		Me.label4.TabIndex = 12
		Me.label4.Text = "SELECT Scalar"
		'
		'label3
		'
		Me.label3.AutoSize = True
		Me.label3.Location = New System.Drawing.Point(9, 53)
		Me.label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		Me.label3.Name = "label3"
		Me.label3.Size = New System.Drawing.Size(77, 20)
		Me.label3.TabIndex = 10
		Me.label3.Text = "SELECT"
		'
		'txtSELECT
		'
		Me.txtSELECT.Location = New System.Drawing.Point(170, 48)
		Me.txtSELECT.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
		Me.txtSELECT.Name = "txtSELECT"
		Me.txtSELECT.Size = New System.Drawing.Size(636, 26)
		Me.txtSELECT.TabIndex = 11
		Me.txtSELECT.Text = "SELECT * FROM tblProducts"
		'
		'lstProducts
		'
		Me.lstProducts.FormattingEnabled = True
		Me.lstProducts.ItemHeight = 20
		Me.lstProducts.Location = New System.Drawing.Point(640, 182)
		Me.lstProducts.Name = "lstProducts"
		Me.lstProducts.Size = New System.Drawing.Size(153, 124)
		Me.lstProducts.TabIndex = 14
		'
		'label2
		'
		Me.label2.AutoSize = True
		Me.label2.Location = New System.Drawing.Point(16, 216)
		Me.label2.Name = "label2"
		Me.label2.Size = New System.Drawing.Size(61, 20)
		Me.label2.TabIndex = 2
		Me.label2.Text = "Result"
		'
		'tabPage1
		'
		Me.tabPage1.Controls.Add(Me.grpRetrieve)
		Me.tabPage1.Location = New System.Drawing.Point(4, 29)
		Me.tabPage1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
		Me.tabPage1.Name = "tabPage1"
		Me.tabPage1.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
		Me.tabPage1.Size = New System.Drawing.Size(817, 352)
		Me.tabPage1.TabIndex = 0
		Me.tabPage1.Text = "Data Retrieval"
		Me.tabPage1.UseVisualStyleBackColor = True
		'
		'grpRetrieve
		'
		Me.grpRetrieve.Controls.Add(Me.txtScalarResult)
		Me.grpRetrieve.Controls.Add(Me.label5)
		Me.grpRetrieve.Controls.Add(Me.lstProducts)
		Me.grpRetrieve.Controls.Add(Me.btnGetDataReader)
		Me.grpRetrieve.Controls.Add(Me.btnGetDataTable)
		Me.grpRetrieve.Controls.Add(Me.grdResults)
		Me.grpRetrieve.Controls.Add(Me.btnExecuteScalar)
		Me.grpRetrieve.Controls.Add(Me.btnGetDataSet)
		Me.grpRetrieve.Location = New System.Drawing.Point(7, 8)
		Me.grpRetrieve.Name = "grpRetrieve"
		Me.grpRetrieve.Size = New System.Drawing.Size(794, 328)
		Me.grpRetrieve.TabIndex = 10
		Me.grpRetrieve.TabStop = False
		Me.grpRetrieve.Text = "Data Retrieval"
		'
		'btnGetDataSet
		'
		Me.btnGetDataSet.Location = New System.Drawing.Point(18, 25)
		Me.btnGetDataSet.Name = "btnGetDataSet"
		Me.btnGetDataSet.Size = New System.Drawing.Size(224, 71)
		Me.btnGetDataSet.TabIndex = 10
		Me.btnGetDataSet.Text = "GetDataSet(SQL, ConnectString)"
		Me.btnGetDataSet.UseVisualStyleBackColor = True
		'
		'tabControl1
		'
		Me.tabControl1.Controls.Add(Me.tabPage1)
		Me.tabControl1.Controls.Add(Me.tabPage2)
		Me.tabControl1.Controls.Add(Me.TabPage3)
		Me.tabControl1.Location = New System.Drawing.Point(13, 134)
		Me.tabControl1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
		Me.tabControl1.Name = "tabControl1"
		Me.tabControl1.SelectedIndex = 0
		Me.tabControl1.Size = New System.Drawing.Size(825, 385)
		Me.tabControl1.TabIndex = 9
		'
		'tabPage2
		'
		Me.tabPage2.Controls.Add(Me.grpDataModifcation)
		Me.tabPage2.Location = New System.Drawing.Point(4, 29)
		Me.tabPage2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
		Me.tabPage2.Name = "tabPage2"
		Me.tabPage2.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
		Me.tabPage2.Size = New System.Drawing.Size(817, 352)
		Me.tabPage2.TabIndex = 1
		Me.tabPage2.Text = "Data Modification"
		Me.tabPage2.UseVisualStyleBackColor = True
		'
		'grpDataModifcation
		'
		Me.grpDataModifcation.Controls.Add(Me.btnExecuteSQL4)
		Me.grpDataModifcation.Controls.Add(Me.btnExecuteSQL2)
		Me.grpDataModifcation.Controls.Add(Me.btnExecuteSQL3)
		Me.grpDataModifcation.Controls.Add(Me.btnExecuteSQL1)
		Me.grpDataModifcation.Controls.Add(Me.txtResult)
		Me.grpDataModifcation.Controls.Add(Me.label2)
		Me.grpDataModifcation.Location = New System.Drawing.Point(7, 8)
		Me.grpDataModifcation.Name = "grpDataModifcation"
		Me.grpDataModifcation.Size = New System.Drawing.Size(793, 251)
		Me.grpDataModifcation.TabIndex = 11
		Me.grpDataModifcation.TabStop = False
		Me.grpDataModifcation.Text = "Data Modification"
		'
		'btnExecuteSQL4
		'
		Me.btnExecuteSQL4.Location = New System.Drawing.Point(258, 115)
		Me.btnExecuteSQL4.Name = "btnExecuteSQL4"
		Me.btnExecuteSQL4.Size = New System.Drawing.Size(224, 71)
		Me.btnExecuteSQL4.TabIndex = 14
		Me.btnExecuteSQL4.Text = "ExecuteSQL(cmd) using Parameters"
		Me.btnExecuteSQL4.UseVisualStyleBackColor = True
		'
		'txtConnectString
		'
		Me.txtConnectString.Location = New System.Drawing.Point(170, 12)
		Me.txtConnectString.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
		Me.txtConnectString.Name = "txtConnectString"
		Me.txtConnectString.Size = New System.Drawing.Size(636, 26)
		Me.txtConnectString.TabIndex = 8
		Me.txtConnectString.Text = "Server=Localhost;Database=NTier-eBook;Integrated Security=SSPI"
		'
		'label1
		'
		Me.label1.AutoSize = True
		Me.label1.Location = New System.Drawing.Point(9, 17)
		Me.label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		Me.label1.Name = "label1"
		Me.label1.Size = New System.Drawing.Size(153, 20)
		Me.label1.TabIndex = 7
		Me.label1.Text = "Connection String"
		'
		'TabPage3
		'
		Me.TabPage3.Controls.Add(Me.btnInterface1)
		Me.TabPage3.Location = New System.Drawing.Point(4, 29)
		Me.TabPage3.Name = "TabPage3"
		Me.TabPage3.Size = New System.Drawing.Size(817, 352)
		Me.TabPage3.TabIndex = 2
		Me.TabPage3.Text = "Interfaces"
		Me.TabPage3.UseVisualStyleBackColor = True
		'
		'btnInterface1
		'
		Me.btnInterface1.Location = New System.Drawing.Point(16, 14)
		Me.btnInterface1.Name = "btnInterface1"
		Me.btnInterface1.Size = New System.Drawing.Size(224, 71)
		Me.btnInterface1.TabIndex = 11
		Me.btnInterface1.Text = "Interface Example 1"
		Me.btnInterface1.UseVisualStyleBackColor = True
		'
		'frmMain
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 20.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(846, 530)
		Me.Controls.Add(Me.txtScalar)
		Me.Controls.Add(Me.label4)
		Me.Controls.Add(Me.label3)
		Me.Controls.Add(Me.txtSELECT)
		Me.Controls.Add(Me.tabControl1)
		Me.Controls.Add(Me.txtConnectString)
		Me.Controls.Add(Me.label1)
		Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
		Me.Name = "frmMain"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "Form1"
		CType(Me.grdResults, System.ComponentModel.ISupportInitialize).EndInit()
		Me.tabPage1.ResumeLayout(False)
		Me.grpRetrieve.ResumeLayout(False)
		Me.grpRetrieve.PerformLayout()
		Me.tabControl1.ResumeLayout(False)
		Me.tabPage2.ResumeLayout(False)
		Me.grpDataModifcation.ResumeLayout(False)
		Me.grpDataModifcation.PerformLayout()
		Me.TabPage3.ResumeLayout(False)
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub
	Private WithEvents btnGetDataTable As System.Windows.Forms.Button
	Private WithEvents grdResults As System.Windows.Forms.DataGridView
	Private WithEvents btnExecuteScalar As System.Windows.Forms.Button
	Private WithEvents txtScalar As System.Windows.Forms.TextBox
	Private WithEvents btnExecuteSQL2 As System.Windows.Forms.Button
	Private WithEvents btnExecuteSQL3 As System.Windows.Forms.Button
	Private WithEvents btnExecuteSQL1 As System.Windows.Forms.Button
	Private WithEvents txtResult As System.Windows.Forms.TextBox
	Private WithEvents btnGetDataReader As System.Windows.Forms.Button
	Private WithEvents txtScalarResult As System.Windows.Forms.TextBox
	Private WithEvents label5 As System.Windows.Forms.Label
	Private WithEvents label4 As System.Windows.Forms.Label
	Private WithEvents label3 As System.Windows.Forms.Label
	Private WithEvents txtSELECT As System.Windows.Forms.TextBox
	Private WithEvents lstProducts As System.Windows.Forms.ListBox
	Private WithEvents label2 As System.Windows.Forms.Label
	Private WithEvents tabPage1 As System.Windows.Forms.TabPage
	Private WithEvents grpRetrieve As System.Windows.Forms.GroupBox
	Private WithEvents btnGetDataSet As System.Windows.Forms.Button
	Private WithEvents tabControl1 As System.Windows.Forms.TabControl
	Private WithEvents tabPage2 As System.Windows.Forms.TabPage
	Private WithEvents grpDataModifcation As System.Windows.Forms.GroupBox
	Private WithEvents btnExecuteSQL4 As System.Windows.Forms.Button
	Private WithEvents txtConnectString As System.Windows.Forms.TextBox
	Private WithEvents label1 As System.Windows.Forms.Label
	Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
	Private WithEvents btnInterface1 As System.Windows.Forms.Button

End Class
