Public Class frmMain

#Region "Data Retrieval Tests"
	Private Sub btnGetDataSet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetDataSet.Click
		Dim ds As DataSet

		Try
			ds = DataLayer.GetDataSet(txtSELECT.Text, txtConnectString.Text)

			grdResults.DataSource = ds.Tables(0)

		Catch ex As Exception
			MessageBox.Show(ex.Message)
		End Try
	End Sub

	Private Sub btnGetDataTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetDataTable.Click
		Dim dt As DataTable

		Try
			dt = DataLayer.GetDataTable(txtSELECT.Text, txtConnectString.Text)

			grdResults.DataSource = dt

		Catch ex As Exception
			MessageBox.Show(ex.Message)
		End Try
	End Sub

	Private Sub btnGetDataReader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetDataReader.Click
		Dim dr As IDataReader = Nothing

		Try
			dr = DataLayer.GetDataReader(txtSELECT.Text, txtConnectString.Text)

			Do While dr.Read()
				lstProducts.Items.Add(dr("sProductName"))
			Loop
		Catch ex As Exception
			MessageBox.Show(ex.Message)
		Finally
			If dr IsNot Nothing Then
				dr.Close()
				dr.Dispose()
			End If
		End Try
	End Sub

	Private Sub btnExecuteScalar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteScalar.Click
		Dim dec As Decimal

		Try
			dec = Convert.ToDecimal(DataLayer.ExecuteScalar(txtScalar.Text, txtConnectString.Text))

			txtScalarResult.Text = dec.ToString()

		Catch ex As Exception
			MessageBox.Show(ex.Message)

		End Try
	End Sub
#End Region

#Region "Data Modification Tests"
	Private Function ProductInsertSQL() As String
		Dim strSQL As String

		strSQL = "INSERT INTO tblProducts"
		strSQL &= "(sProductName, dtIntroduced, cCost, cPrice, bDiscontinued)"
		strSQL &= " VALUES('A New Product', '{0}', 25, 50, 0)"

		strSQL = String.Format(strSQL, DateTime.Now.ToString("G"))

		Return strSQL
	End Function

	Private Function ProductInsertSQLWithParams() As String
		Dim strSQL As String

		strSQL = "INSERT INTO tblProducts"
		strSQL &= "(sProductName, dtIntroduced, cCost, cPrice, bDiscontinued)"
		strSQL &= " VALUES(@sProductName, @dtIntroduced, @cCost, @cPrice, @bDiscontinued)"

		Return strSQL
	End Function

	Private Sub btnExecuteSQL1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteSQL1.Click
		Dim cmd As IDbCommand = Nothing
		Dim intRet As Integer = 0

		Try
			cmd = DataLayer.CreateCommand(ProductInsertSQL(), txtConnectString.Text)

			intRet = DataLayer.ExecuteSQL(cmd, True)

			txtResult.Text = intRet.ToString()

		Catch ex As Exception
			MessageBox.Show(ex.Message)

		End Try
	End Sub

	Private Sub btnExecuteSQL2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteSQL2.Click
		Dim cmd As IDbCommand = Nothing
		Dim cnn As IDbConnection = Nothing
		Dim intRet As Integer = 0

		Try
			cmd = DataLayer.CreateCommand(ProductInsertSQL())
			cnn = DataLayer.CreateConnection(txtConnectString.Text)

			cnn.Open()
			cmd.Connection = cnn

			intRet = DataLayer.ExecuteSQL(cmd, False)

			txtResult.Text = intRet.ToString()

		Catch ex As Exception
			MessageBox.Show(ex.Message)

		Finally
			If cnn IsNot Nothing Then
				cnn.Close()
				cnn.Dispose()
			End If

			If cmd IsNot Nothing Then
				cmd.Dispose()
			End If

		End Try
	End Sub

	Private Sub btnExecuteSQL3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteSQL3.Click
		Dim intRet As Integer = 0

		Try
			intRet = DataLayer.ExecuteSQL(ProductInsertSQL(), txtConnectString.Text)

			txtResult.Text = intRet.ToString()

		Catch ex As Exception
			MessageBox.Show(ex.Message)

		End Try
	End Sub

	Private Sub btnExecuteSQL4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteSQL4.Click
		Dim cmd As IDbCommand = Nothing
		Dim intRet As Integer = 0

		Try
			cmd = DataLayer.CreateCommand(ProductInsertSQLWithParams(), txtConnectString.Text)

			cmd.Parameters.Add(DataLayer.CreateParameter("@sProductName", DbType.String, "A New Product (Param)"))
			cmd.Parameters.Add(DataLayer.CreateParameter("@dtIntroduced", DbType.DateTime, DateTime.Now))
			cmd.Parameters.Add(DataLayer.CreateParameter("@cCost", DbType.Decimal, 50))
			cmd.Parameters.Add(DataLayer.CreateParameter("@cPrice", DbType.Decimal, 150))
			cmd.Parameters.Add(DataLayer.CreateParameter("@bDiscontinued", DbType.Int16, 0))

			intRet = DataLayer.ExecuteSQL(cmd)

			txtResult.Text = intRet.ToString()

		Catch ex As Exception
			MessageBox.Show(ex.Message)

		Finally
			If cmd IsNot Nothing Then
				cmd.Dispose()
			End If

		End Try
	End Sub
#End Region


#Region "Interface Examples"
	Private Sub btnInterface1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInterface1.Click
		Dim cnn As IDbConnection = Nothing

		Try
			cnn = DataLayer.CreateConnection(txtConnectString.Text)

			cnn.Open()

			MessageBox.Show("Connection Opened")

		Catch ex As Exception
			MessageBox.Show(ex.Message)

		Finally
			If cnn IsNot Nothing Then
				cnn.Close()
				cnn.Dispose()
			End If
		End Try
	End Sub
#End Region
End Class
