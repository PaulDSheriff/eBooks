Imports DataCommon
Imports ConfigCommon

Public Class Products
#Region "Private Member Variables/Fields"
	Private mintProductId As Integer
	Private mstrProductName As String
	Private mstrIntroduced As String
	Private mcurCost As Decimal
	Private mcurPrice As Decimal
	Private mboolDiscontinued As Boolean
#End Region

#Region "Column Properties"
	Property ProductId() As Integer
		Get
			Return mintProductId
		End Get

		Set(ByVal Value As Integer)
			mintProductId = Value
		End Set
	End Property

	Property ProductName() As String
		Get
			Return mstrProductName
		End Get

		Set(ByVal Value As String)
			mstrProductName = Value
		End Set
	End Property

	Property Introduced() As String
		Get
			Return mstrIntroduced
		End Get

		Set(ByVal Value As String)
			mstrIntroduced = Value
		End Set
	End Property

	Property Cost() As Decimal
		Get
			Return mcurCost
		End Get

		Set(ByVal Value As Decimal)
			mcurCost = Value
		End Set
	End Property

	Property Price() As Decimal
		Get
			Return mcurPrice
		End Get

		Set(ByVal Value As Decimal)
			mcurPrice = Value
		End Set
	End Property

	Property Discontinued() As Boolean
		Get
			Return mboolDiscontinued
		End Get

		Set(ByVal Value As Boolean)
			mboolDiscontinued = Value
		End Set
	End Property
#End Region

	Public Function GetProducts() As DataSet
		Return GetProducts("SELECT * FROM tblProducts")
	End Function

	Public Function GetProducts(ByVal SQL As String) As DataSet
		Dim ds As DataSet

		' Now use the AppConfig class to retrieve the connection string
		ds = DataLayer.GetDataSet(SQL, AppConfig.ConnectString)

		Return ds
	End Function

	Public Function GetProduct(ByVal ProductID As Integer) As DataSet
		Dim strSQL As String

		strSQL = "SELECT * FROM tblProducts"
		strSQL &= " WHERE iProduct_id = " & ProductID.ToString()

		Return GetProducts(strSQL)
	End Function

	Public Function Load(ByVal ProductID As Integer) As Boolean
		Dim ds As DataSet
		Dim dr As DataRow
		Dim boolRet As Boolean = False

		ds = GetProduct(ProductID)

		If ds.Tables(0).Rows.Count > 0 Then
			boolRet = True
			dr = ds.Tables(0).Rows(0)

			mintProductId = Convert.ToInt32(dr("iProduct_ID"))
			mstrProductName = dr("sProductName").ToString()
			mstrIntroduced = dr("dtIntroduced").ToString()
			mcurCost = Convert.ToDecimal(dr("cCost"))
			mcurPrice = Convert.ToDecimal(dr("cPrice"))
			mboolDiscontinued = Convert.ToBoolean(dr("bDiscontinued"))
		End If

		Return boolRet
	End Function
End Class