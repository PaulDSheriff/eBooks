Imports NTierDataVB

Public Class frmSample1
	Private mprod As New Products

	Private Sub frmSample1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
		ProductLoad()
	End Sub

	Private Sub ProductLoad()
		lstProducts.ValueMember = "iProduct_id"
		lstProducts.DisplayMember = "sProductName"

		lstProducts.DataSource = mprod.GetProducts().Tables(0)
	End Sub

	Private Sub lstProducts_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstProducts.SelectedIndexChanged
		FormShow()
	End Sub

	Private Sub FormShow()
		' Now use the Data Class to load the Data
		If mprod.Load(Convert.ToInt32(lstProducts.SelectedValue)) Then
			lblProductID.Text = mprod.ProductId.ToString()
			txtProductName.Text = mprod.ProductName
			dtpDateIntroduced.Value = Convert.ToDateTime(mprod.Introduced)
			txtCost.Text = mprod.Cost.ToString()
			txtPrice.Text = mprod.Price.ToString()
			chkDiscontinued.Checked = mprod.Discontinued
		Else
			lblProductID.Text = ""
			txtProductName.Text = ""
			dtpDateIntroduced.Value = Now
			txtCost.Text = ""
			txtPrice.Text = ""
			chkDiscontinued.Checked = False
		End If
	End Sub
End Class
