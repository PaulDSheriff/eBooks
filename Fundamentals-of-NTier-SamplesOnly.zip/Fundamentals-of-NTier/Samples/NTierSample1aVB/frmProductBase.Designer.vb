<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmProductBase
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Dim label1 As System.Windows.Forms.Label
		Dim label2 As System.Windows.Forms.Label
		Dim label3 As System.Windows.Forms.Label
		Dim label4 As System.Windows.Forms.Label
		Dim label5 As System.Windows.Forms.Label
		Me.btnClose = New System.Windows.Forms.Button
		Me.lblProductID = New System.Windows.Forms.Label
		Me.lstProducts = New System.Windows.Forms.ListBox
		Me.pnlButtons = New System.Windows.Forms.Panel
		Me.chkDiscontinued = New System.Windows.Forms.CheckBox
		Me.txtProductName = New System.Windows.Forms.TextBox
		Me.dtpDateIntroduced = New System.Windows.Forms.DateTimePicker
		Me.txtCost = New System.Windows.Forms.TextBox
		Me.txtPrice = New System.Windows.Forms.TextBox
		label1 = New System.Windows.Forms.Label
		label2 = New System.Windows.Forms.Label
		label3 = New System.Windows.Forms.Label
		label4 = New System.Windows.Forms.Label
		label5 = New System.Windows.Forms.Label
		Me.pnlButtons.SuspendLayout()
		Me.SuspendLayout()
		'
		'label1
		'
		label1.AutoSize = True
		label1.Location = New System.Drawing.Point(447, 23)
		label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		label1.Name = "label1"
		label1.Size = New System.Drawing.Size(95, 20)
		label1.TabIndex = 14
		label1.Text = "Product ID"
		'
		'label2
		'
		label2.AutoSize = True
		label2.Location = New System.Drawing.Point(447, 72)
		label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		label2.Name = "label2"
		label2.Size = New System.Drawing.Size(122, 20)
		label2.TabIndex = 16
		label2.Text = "Product Name"
		'
		'label3
		'
		label3.AutoSize = True
		label3.Location = New System.Drawing.Point(447, 123)
		label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		label3.Name = "label3"
		label3.Size = New System.Drawing.Size(140, 20)
		label3.TabIndex = 18
		label3.Text = "Date Introduced"
		'
		'label4
		'
		label4.AutoSize = True
		label4.Location = New System.Drawing.Point(447, 171)
		label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		label4.Name = "label4"
		label4.Size = New System.Drawing.Size(46, 20)
		label4.TabIndex = 20
		label4.Text = "Cost"
		'
		'label5
		'
		label5.AutoSize = True
		label5.Location = New System.Drawing.Point(447, 220)
		label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		label5.Name = "label5"
		label5.Size = New System.Drawing.Size(49, 20)
		label5.TabIndex = 22
		label5.Text = "Price"
		'
		'btnClose
		'
		Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.btnClose.Location = New System.Drawing.Point(855, 6)
		Me.btnClose.Name = "btnClose"
		Me.btnClose.Size = New System.Drawing.Size(75, 36)
		Me.btnClose.TabIndex = 2
		Me.btnClose.Text = "Close"
		Me.btnClose.UseVisualStyleBackColor = True
		'
		'lblProductID
		'
		Me.lblProductID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.lblProductID.Location = New System.Drawing.Point(603, 23)
		Me.lblProductID.Name = "lblProductID"
		Me.lblProductID.Size = New System.Drawing.Size(86, 22)
		Me.lblProductID.TabIndex = 15
		'
		'lstProducts
		'
		Me.lstProducts.FormattingEnabled = True
		Me.lstProducts.ItemHeight = 20
		Me.lstProducts.Location = New System.Drawing.Point(12, 12)
		Me.lstProducts.Name = "lstProducts"
		Me.lstProducts.Size = New System.Drawing.Size(409, 284)
		Me.lstProducts.TabIndex = 13
		'
		'pnlButtons
		'
		Me.pnlButtons.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.pnlButtons.Controls.Add(Me.btnClose)
		Me.pnlButtons.Dock = System.Windows.Forms.DockStyle.Bottom
		Me.pnlButtons.Location = New System.Drawing.Point(0, 310)
		Me.pnlButtons.Name = "pnlButtons"
		Me.pnlButtons.Size = New System.Drawing.Size(944, 47)
		Me.pnlButtons.TabIndex = 25
		'
		'chkDiscontinued
		'
		Me.chkDiscontinued.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
		Me.chkDiscontinued.Location = New System.Drawing.Point(442, 264)
		Me.chkDiscontinued.Name = "chkDiscontinued"
		Me.chkDiscontinued.Size = New System.Drawing.Size(179, 32)
		Me.chkDiscontinued.TabIndex = 24
		Me.chkDiscontinued.Text = "Discontinued?"
		Me.chkDiscontinued.UseVisualStyleBackColor = True
		'
		'txtProductName
		'
		Me.txtProductName.Location = New System.Drawing.Point(607, 69)
		Me.txtProductName.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
		Me.txtProductName.Name = "txtProductName"
		Me.txtProductName.Size = New System.Drawing.Size(331, 26)
		Me.txtProductName.TabIndex = 17
		'
		'dtpDateIntroduced
		'
		Me.dtpDateIntroduced.Location = New System.Drawing.Point(607, 118)
		Me.dtpDateIntroduced.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
		Me.dtpDateIntroduced.Name = "dtpDateIntroduced"
		Me.dtpDateIntroduced.Size = New System.Drawing.Size(331, 26)
		Me.dtpDateIntroduced.TabIndex = 19
		'
		'txtCost
		'
		Me.txtCost.Location = New System.Drawing.Point(607, 167)
		Me.txtCost.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
		Me.txtCost.Name = "txtCost"
		Me.txtCost.Size = New System.Drawing.Size(331, 26)
		Me.txtCost.TabIndex = 21
		'
		'txtPrice
		'
		Me.txtPrice.Location = New System.Drawing.Point(607, 216)
		Me.txtPrice.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
		Me.txtPrice.Name = "txtPrice"
		Me.txtPrice.Size = New System.Drawing.Size(331, 26)
		Me.txtPrice.TabIndex = 23
		'
		'frmProductBase
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 20.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(944, 357)
		Me.Controls.Add(Me.lblProductID)
		Me.Controls.Add(Me.lstProducts)
		Me.Controls.Add(Me.pnlButtons)
		Me.Controls.Add(Me.chkDiscontinued)
		Me.Controls.Add(label1)
		Me.Controls.Add(label2)
		Me.Controls.Add(Me.txtProductName)
		Me.Controls.Add(label3)
		Me.Controls.Add(Me.dtpDateIntroduced)
		Me.Controls.Add(label4)
		Me.Controls.Add(Me.txtCost)
		Me.Controls.Add(label5)
		Me.Controls.Add(Me.txtPrice)
		Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
		Me.Name = "frmProductBase"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "frmProductBase"
		Me.pnlButtons.ResumeLayout(False)
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub
	Friend WithEvents pnlButtons As System.Windows.Forms.Panel
	Protected WithEvents btnClose As System.Windows.Forms.Button
	Protected WithEvents lblProductID As System.Windows.Forms.Label
	Protected WithEvents lstProducts As System.Windows.Forms.ListBox
	Protected WithEvents chkDiscontinued As System.Windows.Forms.CheckBox
	Protected WithEvents txtProductName As System.Windows.Forms.TextBox
	Protected WithEvents dtpDateIntroduced As System.Windows.Forms.DateTimePicker
	Protected WithEvents txtCost As System.Windows.Forms.TextBox
	Protected WithEvents txtPrice As System.Windows.Forms.TextBox
End Class
