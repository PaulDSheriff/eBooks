Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols

Imports System.Data
Imports ConfigCommonCS
Imports NTierDataCS

<WebService(Namespace:="http://tempuri.org/")> _
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Public Class wsProducts
	Inherits System.Web.Services.WebService

	<WebMethod()> _
	Public Function GetProductObject() As Products
		Dim prod As Products = New Products()

		Return prod
	End Function

	<WebMethod()> _
	Public Function GetProducts() As DataSet
		Dim prod As Products = New Products()

		Return prod.GetProducts()
	End Function

	<WebMethod()> _
	 Public Function GetProduct(ByVal ProductId As Integer) As Products
		Dim prod As Products = New Products()

		If prod.Load(ProductId) = False Then
			prod = Nothing
		End If

		Return prod
	End Function

	<WebMethod()> _
	Public Function Insert(ByVal prod As Products) As Integer
		Dim intRet As Integer = 0

		prod.ConnectString = AppConfig.ConnectString

		Try
			intRet = prod.Insert()

		Catch
			Throw

		End Try

		Return intRet
	End Function

	<WebMethod()> _
	Public Function Update(ByVal prod As Products) As Integer
		Dim intRet As Integer = 0

		prod.ConnectString = AppConfig.ConnectString

		Try
			intRet = prod.Update()

		Catch
			Throw

		End Try

		Return intRet
	End Function

	<WebMethod()> _
	Public Function Delete(ByVal prod As Products) As Integer
		Dim intRet As Integer = 0

		prod.ConnectString = AppConfig.ConnectString

		Try
			intRet = prod.Delete()

		Catch
			Throw

		End Try

		Return intRet
	End Function
End Class
