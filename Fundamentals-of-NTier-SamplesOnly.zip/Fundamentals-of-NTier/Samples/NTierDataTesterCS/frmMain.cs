using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using DataCommonCS;

namespace NTierDataTesterCS
{
	public partial class frmMain : Form
	{
		public frmMain()
		{
			InitializeComponent();
		}

		#region "Data Retrieval Tests"
		private void btnGetDataSet_Click(object sender, EventArgs e)
		{
			DataSet ds;

			try
			{
				ds = DataLayer.GetDataSet(txtSELECT.Text, txtConnectString.Text);

				grdResults.DataSource = ds.Tables[0];
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnGetDataTable_Click(object sender, EventArgs e)
		{
			DataTable dt;

			try
			{
				dt = DataLayer.GetDataTable(txtSELECT.Text, txtConnectString.Text);

				grdResults.DataSource = dt;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnGetDataReader_Click(object sender, EventArgs e)
		{
			IDataReader dr = null;

			try
			{
				dr = DataLayer.GetDataReader(txtSELECT.Text, txtConnectString.Text);

				while (dr.Read())
				{
					lstProducts.Items.Add(dr["sProductName"]);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
			finally
			{
				if(dr != null)
				{
					dr.Close();
					dr.Dispose();
				}
			}
		}

		private void btnExecuteScalar_Click(object sender, EventArgs e)
		{
			decimal dec;

			try
			{
				dec = Convert.ToDecimal(DataLayer.ExecuteScalar(txtScalar.Text, txtConnectString.Text));

				txtScalarResult.Text = dec.ToString();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
		#endregion

		#region "Data Modification Tests"
		private string ProductInsertSQL()
		{
			string strSQL;

			strSQL = "INSERT INTO tblProducts";
			strSQL += "(sProductName, dtIntroduced, cCost, cPrice, bDiscontinued)";
			strSQL += " VALUES('A New Product', '{0}', 25, 50, 0)";

			strSQL = string.Format(strSQL, DateTime.Now.ToString("G"));

			return strSQL;
		}

		private string ProductInsertSQLWithParams()
		{
			string strSQL;

			strSQL = "INSERT INTO tblProducts";
			strSQL += "(sProductName, dtIntroduced, cCost, cPrice, bDiscontinued)";
			strSQL += " VALUES(@sProductName, @dtIntroduced, @cCost, @cPrice, @bDiscontinued)";

			return strSQL;
		}

		private void btnExecuteSQL1_Click(object sender, EventArgs e)
		{
			IDbCommand cmd = null;
			int intRet = 0;

			try
			{
				cmd = DataLayer.CreateCommand(ProductInsertSQL(), txtConnectString.Text);

				intRet = DataLayer.ExecuteSQL(cmd, true);

				txtResult.Text = intRet.ToString();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnExecuteSQL2_Click(object sender, EventArgs e)
		{
			IDbCommand cmd = null;
			IDbConnection cnn = null;
			int intRet = 0;

			try
			{
				cmd = DataLayer.CreateCommand(ProductInsertSQL());
				cnn = DataLayer.CreateConnection(txtConnectString.Text);

				cnn.Open();
				cmd.Connection = cnn;

				intRet = DataLayer.ExecuteSQL(cmd, false);

				txtResult.Text = intRet.ToString();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
			finally
			{
				if (cnn != null)
				{
					cnn.Close();
					cnn.Dispose();
				}
				if (cmd != null)
				{
					cmd.Dispose();
				}
			}
		}

		private void btnExecuteSQL3_Click(object sender, EventArgs e)
		{
			int intRet = 0;

			try
			{
				intRet = DataLayer.ExecuteSQL(ProductInsertSQL(), txtConnectString.Text);

				txtResult.Text = intRet.ToString();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnExecuteSQL4_Click(object sender, EventArgs e)
		{
			IDbCommand cmd = null;
			int intRet = 0;

			try
			{
				cmd = DataLayer.CreateCommand(ProductInsertSQLWithParams(), txtConnectString.Text);

				cmd.Parameters.Add(DataLayer.CreateParameter("@sProductName", DbType.String, "A New Product (Param)"));
				cmd.Parameters.Add(DataLayer.CreateParameter("@dtIntroduced", DbType.DateTime, DateTime.Now));
				cmd.Parameters.Add(DataLayer.CreateParameter("@cCost", DbType.Decimal, 50));
				cmd.Parameters.Add(DataLayer.CreateParameter("@cPrice", DbType.Decimal, 150));
				cmd.Parameters.Add(DataLayer.CreateParameter("@bDiscontinued", DbType.Int16, 0));
				
				intRet = DataLayer.ExecuteSQL(cmd);

				txtResult.Text = intRet.ToString();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
			finally
			{
				if (cmd != null)
				{
					cmd.Dispose();
				}
			}
		}
		#endregion

		#region "Interface Examples"

		private void btnInterface1_Click(object sender, EventArgs e)
		{
			IDbConnection cnn = null;

			cnn = DataLayer.CreateConnection(txtConnectString.Text);

			try
			{
				cnn.Open();

				MessageBox.Show("Connection Opened");
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
			finally
			{
				if (cnn != null)
				{
					cnn.Close();
					cnn.Dispose();
				}
			}
		}

		#endregion
	}
}