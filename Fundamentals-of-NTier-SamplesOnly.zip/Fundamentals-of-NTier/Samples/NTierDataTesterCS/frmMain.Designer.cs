namespace NTierDataTesterCS
{
	partial class frmMain
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.txtConnectString = new System.Windows.Forms.TextBox();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.grpRetrieve = new System.Windows.Forms.GroupBox();
			this.txtScalarResult = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.lstProducts = new System.Windows.Forms.ListBox();
			this.btnGetDataReader = new System.Windows.Forms.Button();
			this.btnGetDataTable = new System.Windows.Forms.Button();
			this.grdResults = new System.Windows.Forms.DataGridView();
			this.btnExecuteScalar = new System.Windows.Forms.Button();
			this.btnGetDataSet = new System.Windows.Forms.Button();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.grpDataModifcation = new System.Windows.Forms.GroupBox();
			this.btnExecuteSQL4 = new System.Windows.Forms.Button();
			this.btnExecuteSQL2 = new System.Windows.Forms.Button();
			this.btnExecuteSQL3 = new System.Windows.Forms.Button();
			this.btnExecuteSQL1 = new System.Windows.Forms.Button();
			this.txtResult = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.txtSELECT = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.txtScalar = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.tabPage3 = new System.Windows.Forms.TabPage();
			this.btnInterface1 = new System.Windows.Forms.Button();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.grpRetrieve.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.grdResults)).BeginInit();
			this.tabPage2.SuspendLayout();
			this.grpDataModifcation.SuspendLayout();
			this.tabPage3.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(4, 18);
			this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(153, 20);
			this.label1.TabIndex = 0;
			this.label1.Text = "Connection String";
			// 
			// txtConnectString
			// 
			this.txtConnectString.Location = new System.Drawing.Point(165, 13);
			this.txtConnectString.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.txtConnectString.Name = "txtConnectString";
			this.txtConnectString.Size = new System.Drawing.Size(636, 26);
			this.txtConnectString.TabIndex = 1;
			this.txtConnectString.Text = "Server=Localhost;Database=NTier-eBook;Integrated Security=SSPI";
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Controls.Add(this.tabPage3);
			this.tabControl1.Location = new System.Drawing.Point(8, 132);
			this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(825, 385);
			this.tabControl1.TabIndex = 2;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.grpRetrieve);
			this.tabPage1.Location = new System.Drawing.Point(4, 29);
			this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.tabPage1.Size = new System.Drawing.Size(817, 352);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Data Retrieval";
			this.tabPage1.UseVisualStyleBackColor = true;
			// 
			// grpRetrieve
			// 
			this.grpRetrieve.Controls.Add(this.txtScalarResult);
			this.grpRetrieve.Controls.Add(this.label5);
			this.grpRetrieve.Controls.Add(this.lstProducts);
			this.grpRetrieve.Controls.Add(this.btnGetDataReader);
			this.grpRetrieve.Controls.Add(this.btnGetDataTable);
			this.grpRetrieve.Controls.Add(this.grdResults);
			this.grpRetrieve.Controls.Add(this.btnExecuteScalar);
			this.grpRetrieve.Controls.Add(this.btnGetDataSet);
			this.grpRetrieve.Location = new System.Drawing.Point(7, 8);
			this.grpRetrieve.Name = "grpRetrieve";
			this.grpRetrieve.Size = new System.Drawing.Size(794, 328);
			this.grpRetrieve.TabIndex = 10;
			this.grpRetrieve.TabStop = false;
			this.grpRetrieve.Text = "Data Retrieval";
			// 
			// txtScalarResult
			// 
			this.txtScalarResult.Location = new System.Drawing.Point(342, 124);
			this.txtScalarResult.Name = "txtScalarResult";
			this.txtScalarResult.Size = new System.Drawing.Size(77, 26);
			this.txtScalarResult.TabIndex = 16;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(264, 127);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(61, 20);
			this.label5.TabIndex = 15;
			this.label5.Text = "Result";
			// 
			// lstProducts
			// 
			this.lstProducts.FormattingEnabled = true;
			this.lstProducts.ItemHeight = 20;
			this.lstProducts.Location = new System.Drawing.Point(640, 182);
			this.lstProducts.Name = "lstProducts";
			this.lstProducts.Size = new System.Drawing.Size(153, 124);
			this.lstProducts.TabIndex = 14;
			// 
			// btnGetDataReader
			// 
			this.btnGetDataReader.Location = new System.Drawing.Point(502, 25);
			this.btnGetDataReader.Name = "btnGetDataReader";
			this.btnGetDataReader.Size = new System.Drawing.Size(224, 71);
			this.btnGetDataReader.TabIndex = 12;
			this.btnGetDataReader.Text = "GetDataReader(SQL, ConnectString)";
			this.btnGetDataReader.UseVisualStyleBackColor = true;
			this.btnGetDataReader.Click += new System.EventHandler(this.btnGetDataReader_Click);
			// 
			// btnGetDataTable
			// 
			this.btnGetDataTable.Location = new System.Drawing.Point(259, 25);
			this.btnGetDataTable.Name = "btnGetDataTable";
			this.btnGetDataTable.Size = new System.Drawing.Size(224, 71);
			this.btnGetDataTable.TabIndex = 11;
			this.btnGetDataTable.Text = "GetDataTable(SQL, ConnectString)";
			this.btnGetDataTable.UseVisualStyleBackColor = true;
			this.btnGetDataTable.Click += new System.EventHandler(this.btnGetDataTable_Click);
			// 
			// grdResults
			// 
			this.grdResults.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.grdResults.Location = new System.Drawing.Point(18, 179);
			this.grdResults.Name = "grdResults";
			this.grdResults.Size = new System.Drawing.Size(606, 133);
			this.grdResults.TabIndex = 9;
			// 
			// btnExecuteScalar
			// 
			this.btnExecuteScalar.Location = new System.Drawing.Point(18, 102);
			this.btnExecuteScalar.Name = "btnExecuteScalar";
			this.btnExecuteScalar.Size = new System.Drawing.Size(224, 71);
			this.btnExecuteScalar.TabIndex = 13;
			this.btnExecuteScalar.Text = "ExecuteScalar(SQL, ConnectString)";
			this.btnExecuteScalar.UseVisualStyleBackColor = true;
			this.btnExecuteScalar.Click += new System.EventHandler(this.btnExecuteScalar_Click);
			// 
			// btnGetDataSet
			// 
			this.btnGetDataSet.Location = new System.Drawing.Point(18, 25);
			this.btnGetDataSet.Name = "btnGetDataSet";
			this.btnGetDataSet.Size = new System.Drawing.Size(224, 71);
			this.btnGetDataSet.TabIndex = 10;
			this.btnGetDataSet.Text = "GetDataSet(SQL, ConnectString)";
			this.btnGetDataSet.UseVisualStyleBackColor = true;
			this.btnGetDataSet.Click += new System.EventHandler(this.btnGetDataSet_Click);
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.grpDataModifcation);
			this.tabPage2.Location = new System.Drawing.Point(4, 29);
			this.tabPage2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.tabPage2.Size = new System.Drawing.Size(817, 352);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Data Modification";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// grpDataModifcation
			// 
			this.grpDataModifcation.Controls.Add(this.btnExecuteSQL4);
			this.grpDataModifcation.Controls.Add(this.btnExecuteSQL2);
			this.grpDataModifcation.Controls.Add(this.btnExecuteSQL3);
			this.grpDataModifcation.Controls.Add(this.btnExecuteSQL1);
			this.grpDataModifcation.Controls.Add(this.txtResult);
			this.grpDataModifcation.Controls.Add(this.label2);
			this.grpDataModifcation.Location = new System.Drawing.Point(7, 8);
			this.grpDataModifcation.Name = "grpDataModifcation";
			this.grpDataModifcation.Size = new System.Drawing.Size(793, 251);
			this.grpDataModifcation.TabIndex = 11;
			this.grpDataModifcation.TabStop = false;
			this.grpDataModifcation.Text = "Data Modification";
			// 
			// btnExecuteSQL4
			// 
			this.btnExecuteSQL4.Location = new System.Drawing.Point(258, 115);
			this.btnExecuteSQL4.Name = "btnExecuteSQL4";
			this.btnExecuteSQL4.Size = new System.Drawing.Size(224, 71);
			this.btnExecuteSQL4.TabIndex = 14;
			this.btnExecuteSQL4.Text = "ExecuteSQL(cmd) using Parameters";
			this.btnExecuteSQL4.UseVisualStyleBackColor = true;
			this.btnExecuteSQL4.Click += new System.EventHandler(this.btnExecuteSQL4_Click);
			// 
			// btnExecuteSQL2
			// 
			this.btnExecuteSQL2.Location = new System.Drawing.Point(258, 25);
			this.btnExecuteSQL2.Name = "btnExecuteSQL2";
			this.btnExecuteSQL2.Size = new System.Drawing.Size(224, 71);
			this.btnExecuteSQL2.TabIndex = 13;
			this.btnExecuteSQL2.Text = "ExecuteSQL(cmd)";
			this.btnExecuteSQL2.UseVisualStyleBackColor = true;
			this.btnExecuteSQL2.Click += new System.EventHandler(this.btnExecuteSQL2_Click);
			// 
			// btnExecuteSQL3
			// 
			this.btnExecuteSQL3.Location = new System.Drawing.Point(501, 25);
			this.btnExecuteSQL3.Name = "btnExecuteSQL3";
			this.btnExecuteSQL3.Size = new System.Drawing.Size(224, 71);
			this.btnExecuteSQL3.TabIndex = 12;
			this.btnExecuteSQL3.Text = "ExecuteSQL(SQL, ConnectString)";
			this.btnExecuteSQL3.UseVisualStyleBackColor = true;
			this.btnExecuteSQL3.Click += new System.EventHandler(this.btnExecuteSQL3_Click);
			// 
			// btnExecuteSQL1
			// 
			this.btnExecuteSQL1.Location = new System.Drawing.Point(20, 25);
			this.btnExecuteSQL1.Name = "btnExecuteSQL1";
			this.btnExecuteSQL1.Size = new System.Drawing.Size(224, 71);
			this.btnExecuteSQL1.TabIndex = 11;
			this.btnExecuteSQL1.Text = "ExecuteSQL(cmd, DisposeOfCommand)";
			this.btnExecuteSQL1.UseVisualStyleBackColor = true;
			this.btnExecuteSQL1.Click += new System.EventHandler(this.btnExecuteSQL1_Click);
			// 
			// txtResult
			// 
			this.txtResult.Location = new System.Drawing.Point(177, 210);
			this.txtResult.Name = "txtResult";
			this.txtResult.Size = new System.Drawing.Size(77, 26);
			this.txtResult.TabIndex = 3;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(16, 216);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(61, 20);
			this.label2.TabIndex = 2;
			this.label2.Text = "Result";
			// 
			// txtSELECT
			// 
			this.txtSELECT.Location = new System.Drawing.Point(165, 49);
			this.txtSELECT.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.txtSELECT.Name = "txtSELECT";
			this.txtSELECT.Size = new System.Drawing.Size(636, 26);
			this.txtSELECT.TabIndex = 4;
			this.txtSELECT.Text = "SELECT * FROM tblProducts";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(4, 54);
			this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(77, 20);
			this.label3.TabIndex = 3;
			this.label3.Text = "SELECT";
			// 
			// txtScalar
			// 
			this.txtScalar.Location = new System.Drawing.Point(165, 85);
			this.txtScalar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.txtScalar.Name = "txtScalar";
			this.txtScalar.Size = new System.Drawing.Size(636, 26);
			this.txtScalar.TabIndex = 6;
			this.txtScalar.Text = "SELECT Count(*) FROM tblProducts";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(4, 90);
			this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(133, 20);
			this.label4.TabIndex = 5;
			this.label4.Text = "SELECT Scalar";
			// 
			// tabPage3
			// 
			this.tabPage3.Controls.Add(this.btnInterface1);
			this.tabPage3.Location = new System.Drawing.Point(4, 29);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Size = new System.Drawing.Size(817, 352);
			this.tabPage3.TabIndex = 2;
			this.tabPage3.Text = "Interfaces";
			this.tabPage3.UseVisualStyleBackColor = true;
			// 
			// btnInterface1
			// 
			this.btnInterface1.Location = new System.Drawing.Point(19, 20);
			this.btnInterface1.Name = "btnInterface1";
			this.btnInterface1.Size = new System.Drawing.Size(224, 71);
			this.btnInterface1.TabIndex = 11;
			this.btnInterface1.Text = "Interface Example 1";
			this.btnInterface1.UseVisualStyleBackColor = true;
			this.btnInterface1.Click += new System.EventHandler(this.btnInterface1_Click);
			// 
			// frmMain
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(848, 525);
			this.Controls.Add(this.txtScalar);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.txtSELECT);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.tabControl1);
			this.Controls.Add(this.txtConnectString);
			this.Controls.Add(this.label1);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.Name = "frmMain";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Test NTier DataLayer Class";
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.grpRetrieve.ResumeLayout(false);
			this.grpRetrieve.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.grdResults)).EndInit();
			this.tabPage2.ResumeLayout(false);
			this.grpDataModifcation.ResumeLayout(false);
			this.grpDataModifcation.PerformLayout();
			this.tabPage3.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtConnectString;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.GroupBox grpRetrieve;
		private System.Windows.Forms.Button btnGetDataReader;
		private System.Windows.Forms.Button btnGetDataTable;
		private System.Windows.Forms.DataGridView grdResults;
		private System.Windows.Forms.Button btnExecuteScalar;
		private System.Windows.Forms.Button btnGetDataSet;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.GroupBox grpDataModifcation;
		private System.Windows.Forms.Button btnExecuteSQL4;
		private System.Windows.Forms.Button btnExecuteSQL2;
		private System.Windows.Forms.Button btnExecuteSQL3;
		private System.Windows.Forms.Button btnExecuteSQL1;
		private System.Windows.Forms.TextBox txtResult;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtSELECT;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtScalar;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ListBox lstProducts;
		private System.Windows.Forms.TextBox txtScalarResult;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.Button btnInterface1;
	}
}

