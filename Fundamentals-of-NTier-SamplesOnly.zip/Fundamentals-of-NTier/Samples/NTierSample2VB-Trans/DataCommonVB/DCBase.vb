Public Enum DCTransType
  NA
  Insert
  Update
  Delete
End Enum

<Serializable()> Public MustInherit Class DCBase
  Private mstrSQL As String = String.Empty
  Private mcmd As IDbCommand
  Private mTransType As DCTransType
  Private mstrConnectString As String

  Public Property ConnectString() As String
    Get
      Return mstrConnectString
    End Get
    Set(ByVal value As String)
      mstrConnectString = value
    End Set
  End Property

  Public Property SQL() As String
    Get
      Return mstrSQL
    End Get
    Set(ByVal value As String)
      mstrSQL = value
    End Set
  End Property

  Public Property TransType() As DCTransType
    Get
      Return mTransType
    End Get
    Set(ByVal value As DCTransType)
      mTransType = value
    End Set
  End Property

  Public Property CommandObject() As IDbCommand
    Get
      Return mcmd
    End Get
    Set(ByVal value As IDbCommand)
      mcmd = value
    End Set
  End Property

  Public Overridable Sub PrepareForTransaction()
    mcmd = DataLayer.CreateCommand(mstrSQL, mstrConnectString)
  End Sub

  Public MustOverride Sub Validate()
  Public MustOverride Function Insert() As Integer
  Public MustOverride Function Update() As Integer
  Public MustOverride Function Delete() As Integer
End Class
