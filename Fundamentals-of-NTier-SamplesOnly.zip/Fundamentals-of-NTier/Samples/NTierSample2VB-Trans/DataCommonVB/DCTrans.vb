Public Class DCTrans
  Inherits System.Collections.Generic.List(Of DCBase)

  Private mstrConnectString As String

  Public Sub New(ByVal ConnectString As String)
    mstrConnectString = ConnectString
  End Sub

  Public Sub Execute()
    Dim trn As IDbTransaction = Nothing
    Dim cnn As IDbConnection = Nothing

    Try
      cnn = DataLayer.CreateConnection(mstrConnectString)
      cnn.Open()
      trn = cnn.BeginTransaction()

      For Each dc As DCBase In Me
        ' Prepare Command Object for Transaction
        dc.ConnectString = mstrConnectString
        dc.PrepareForTransaction()
        ' Set Transaction/Connection on Command Object
        dc.CommandObject.Connection = cnn
        dc.CommandObject.Transaction = trn

        Select Case dc.TransType
          Case DCTransType.Insert
            dc.Insert()

          Case DCTransType.Update
            dc.Update()

          Case DCTransType.Delete
            dc.Delete()

        End Select
      Next

      trn.Commit()

    Catch ex As Exception
      If trn IsNot Nothing Then
        trn.Rollback()
      End If

      Throw ex

    Finally
      If cnn IsNot Nothing Then
        cnn.Close()
        cnn.Dispose()
      End If
      If trn IsNot Nothing Then
        trn.Dispose()
      End If

    End Try
  End Sub
End Class
