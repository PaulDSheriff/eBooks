Imports NTierData
Imports DataCommonVB

Public Class frmMain

  Private Sub btnTrans_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTrans.Click
    TransSample()
  End Sub

  Private Sub TransSample()
    Dim pt As New ProductTransSample
    Dim boProd1 As New Products
    Dim boProd2 As New Products

    Try
      boProd1.Cost = 100
      boProd1.Discontinued = False
      boProd1.Introduced = Now.ToString()
      boProd1.Price = 200
      boProd1.ProductName = "A New Product #1"

      boProd2.Cost = 10
      boProd2.Discontinued = False
      boProd2.Introduced = Now.ToString()
      boProd2.Price = 20
      boProd2.ProductName = "A New Product #2"

      pt.InsertTwoProducts(boProd1, boProd2)

      MessageBox.Show("Transaction Completed Successfully")

    Catch ex As Exception
      MessageBox.Show(ex.Message)

    End Try
  End Sub

  Private Sub btnSample1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSample1.Click
    Dim frm As New frmProducts

    frm.Show()
  End Sub
End Class