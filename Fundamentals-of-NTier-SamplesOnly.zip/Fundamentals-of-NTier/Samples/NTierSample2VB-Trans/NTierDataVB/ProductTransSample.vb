Imports ConfigCommon

Public Class ProductTransSample
  Public Sub InsertTwoProducts(ByVal boProd1 As Products, ByVal boProd2 As Products)
    Dim trn As DCTrans

    Try
      trn = New DCTrans(AppConfig.ConnectString)
      boProd1.TransType = DCTransType.Insert
      trn.Add(boProd1)
      boProd2.TransType = DCTransType.Insert
      trn.Add(boProd2)
      trn.Execute()

    Catch ex As Exception
      Throw ex

    End Try
  End Sub
End Class
