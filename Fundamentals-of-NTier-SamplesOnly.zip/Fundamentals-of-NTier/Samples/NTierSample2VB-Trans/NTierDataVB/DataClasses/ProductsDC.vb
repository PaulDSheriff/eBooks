Imports DataCommonVB

<Serializable()> Public MustInherit Class ProductsDC
  Inherits DCBase

  Public Schema As ProductsDC.SchemaStruct

  Public Sub New()
    Schema = New ProductsDC.SchemaStruct()

    Schema.ObjectName = "tblProducts"
    Schema.ProductId = "iProduct_id"
    Schema.ProductName = "sProductName"
    Schema.Discontinued = "bDiscontinued"
    Schema.Introduced = "dtIntroduced"
    Schema.Price = "cPrice"
    Schema.Cost = "cCost"
  End Sub

#Region "Private Member Variables"
  Private mintProductId As Integer
  Private mstrProductName As String
  Private mstrIntroduced As String
  Private mdecCost As Decimal
  Private mdecPrice As Decimal
  Private mboolDiscontinued As Boolean
#End Region

#Region "Column Properties"
  Property ProductId() As Integer
    Get
      Return mintProductId
    End Get

    Set(ByVal Value As Integer)
      mintProductId = Value
    End Set
  End Property

  Property ProductName() As String
    Get
      Return mstrProductName
    End Get

    Set(ByVal Value As String)
      mstrProductName = Value
    End Set
  End Property

  Property Introduced() As String
    Get
      Return mstrIntroduced
    End Get

    Set(ByVal Value As String)
      mstrIntroduced = Value
    End Set
  End Property

  Property Cost() As Decimal
    Get
      Return mdecCost
    End Get

    Set(ByVal Value As Decimal)
      mdecCost = Value
    End Set
  End Property

  Property Price() As Decimal
    Get
      Return mdecPrice
    End Get

    Set(ByVal Value As Decimal)
      mdecPrice = Value
    End Set
  End Property

  Property Discontinued() As Boolean
    Get
      Return mboolDiscontinued
    End Get

    Set(ByVal Value As Boolean)
      mboolDiscontinued = Value
    End Set
  End Property
#End Region

#Region "Data Retrieval Methods"
  Public Function GetProducts() As DataSet
    Dim ds As DataSet

    MyBase.SQL = "SELECT * FROM tblProducts"

    ' Use the DataLayer to Build DataSet
    ds = DataLayer.GetDataSet(MyBase.SQL, MyBase.ConnectString)

    Return ds
  End Function

  Public Function GetProduct(ByVal ProductID As Integer) As DataSet
    Dim ds As DataSet = Nothing

    MyBase.SQL = "SELECT * FROM tblProducts"
    MyBase.SQL &= " WHERE iProduct_id = " + ProductID.ToString()

    ' Retrieve DataTable from Data Layer
    ds = DataLayer.GetDataSet(MyBase.SQL, MyBase.ConnectString)

    Return ds
  End Function

  Public Function Load(ByVal ProductID As Integer) As Boolean
    Dim ds As DataSet = Nothing
    Dim dr As DataRow
    Dim boolRet As Boolean = False

    ds = GetProduct(ProductID)

    If ds IsNot Nothing Then
      If ds.Tables.Count > 0 Then
        boolRet = True

        dr = ds.Tables(0).Rows(0)

        mintProductId = Convert.ToInt32(dr(Me.Schema.ProductId))
        mstrProductName = dr(Me.Schema.ProductName).ToString()
        mstrIntroduced = dr(Me.Schema.Introduced).ToString()
        mdecCost = Convert.ToDecimal(dr(Me.Schema.Cost))
        mdecPrice = Convert.ToDecimal(dr(Me.Schema.Price))
        mboolDiscontinued = Convert.ToBoolean(dr(Me.Schema.Discontinued))
      End If
    End If

    Return boolRet
  End Function
#End Region

#Region "Data Modification Methods"
  Public Overrides Sub Validate()
    Dim strMsg As String = String.Empty

    If mstrProductName.Trim() = String.Empty Then
      strMsg &= "Product Name Must Be Filled In" & Environment.NewLine
    End If

    If mstrIntroduced.Trim() <> String.Empty Then
      If Not IsDate(mstrIntroduced) Then
        strMsg &= "Date Introduced is not a valid Date" & Environment.NewLine
      End If
    End If

    If strMsg <> String.Empty Then
      Throw New BusinessRuleException(strMsg)
    End If
  End Sub

  Public Overrides Function Insert() As Integer
    ' Check Business Rules
    Validate()

    MyBase.SQL = "INSERT INTO tblProducts(sProductName, "
    MyBase.SQL &= " dtIntroduced, cCost, cPrice, bDiscontinued) "
    MyBase.SQL &= "VALUES(@sProductName, @dtIntroduced, "
    MyBase.SQL &= " @cCost, @cPrice, @bDiscontinued) "

    If MyBase.TransType = DCTransType.NA Then
      MyBase.CommandObject = DataLayer.CreateCommand(MyBase.SQL, MyBase.ConnectString)
    Else
      MyBase.CommandObject.CommandText = MyBase.SQL
    End If

    FillInParameters(MyBase.CommandObject)

    Return DataLayer.ExecuteSQL(MyBase.CommandObject, (MyBase.TransType = DCTransType.NA))
  End Function

  Public Overrides Function Update() As Integer
    ' Check Business Rules
    Validate()

    MyBase.SQL = "UPDATE tblProducts "
    MyBase.SQL &= "SET sProductName = @sProductName,"
    MyBase.SQL &= " dtIntroduced = @dtIntroduced, "
    MyBase.SQL &= " cCost = @cCost, "
    MyBase.SQL &= " cPrice = @cPrice, "
    MyBase.SQL &= " bDiscontinued = @bDiscontinued "
    MyBase.SQL &= " WHERE iProduct_id = @iProduct_id "

    If MyBase.TransType = DCTransType.NA Then
      MyBase.CommandObject = DataLayer.CreateCommand(MyBase.SQL, MyBase.ConnectString)
    Else
      MyBase.CommandObject.CommandText = MyBase.SQL
    End If

    FillInParameters(MyBase.CommandObject)

    Return DataLayer.ExecuteSQL(MyBase.CommandObject, (MyBase.TransType = DCTransType.NA))
  End Function

  Public Overrides Function Delete() As Integer
    MyBase.SQL = "DELETE FROM tblProducts "
    MyBase.SQL &= " WHERE iProduct_id = @iProduct_id "

    If MyBase.TransType = DCTransType.NA Then
      MyBase.CommandObject = DataLayer.CreateCommand(MyBase.SQL, MyBase.ConnectString)
    Else
      MyBase.CommandObject.CommandText = MyBase.SQL
    End If

    FillInParameters(MyBase.CommandObject)

    Return DataLayer.ExecuteSQL(MyBase.CommandObject, (MyBase.TransType = DCTransType.NA))
  End Function

  Protected Sub FillInParameters(ByVal cmd As IDbCommand)
    cmd.Parameters.Add(DataLayer.CreateParameter( _
     "@iProduct_id", DbType.Int32, mintProductId))
    cmd.Parameters.Add(DataLayer.CreateParameter( _
     "@sProductName", DbType.String, mstrProductName))
    cmd.Parameters.Add(DataLayer.CreateParameter( _
     "@dtIntroduced", DbType.DateTime, mstrIntroduced))
    cmd.Parameters.Add(DataLayer.CreateParameter( _
     "@cCost", DbType.Decimal, mdecCost))
    cmd.Parameters.Add(DataLayer.CreateParameter( _
     "@cPrice", DbType.Decimal, mdecPrice))
    cmd.Parameters.Add(DataLayer.CreateParameter( _
     "@bDiscontinued", DbType.Decimal, mboolDiscontinued))
  End Sub
#End Region

#Region "Schema Structure to return Object and Column Names"
  <Serializable()> Public Structure SchemaStruct
    Public ObjectName As String
    Public ProductId As String
    Public ProductName As String
    Public Introduced As String
    Public Cost As String
    Public Price As String
    Public Discontinued As String
  End Structure
#End Region
End Class


