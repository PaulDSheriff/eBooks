using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace NTierSample2CS
{
	class AppException
	{
		public static void Publish(Exception ex)
		{
			MessageBox.Show(ex.Message);
		}

		public static void Publish(string Message)
		{
			MessageBox.Show(Message);
		}
	}
}
