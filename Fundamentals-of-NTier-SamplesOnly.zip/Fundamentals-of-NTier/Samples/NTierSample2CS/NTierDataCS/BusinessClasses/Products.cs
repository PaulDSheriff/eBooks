using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

using ConfigCommonCS;
using DataCommonCS;

namespace NTierDataCS
{
	[Serializable]
public class Products : ProductsDC
{
	#region "Constructors"
	public Products()
	{
		base.ConnectString = AppConfig.ConnectString;
	}

	public Products(string ConnectString)
	{
		base.ConnectString = ConnectString;
	}
	#endregion

	#region "Validate Method"
	public override void Validate()
	{
		string strMsg = string.Empty;

		try
		{
			// Check data class business rules
			base.Validate();

		}
		catch (BusinessRuleException ex)
		{
			// Get Business Rule Messages
			strMsg = ex.Message;
		}

		//*******************************************************
		//* CHECK YOUR BUSINESS RULES HERE
		if (base.Cost < 0 || base.Cost > 999)
		{
			strMsg += "Cost must be greater than $0.00 and less than $1,000.00" + Environment.NewLine;
		}
		if (base.Price < 0 || base.Price > 999)
		{
			strMsg += "Price must be greater than $0.00 and less than $1,000.00" + Environment.NewLine;
		}
		if (base.Cost > base.Price)
		{
			strMsg += "Price must be greater than the Cost of the Product" + Environment.NewLine;
		}

		if (strMsg != String.Empty)
		{
			throw new BusinessRuleException(strMsg);
		}
	}
	#endregion

	#region "Custom Methods"

	#endregion

}
}
