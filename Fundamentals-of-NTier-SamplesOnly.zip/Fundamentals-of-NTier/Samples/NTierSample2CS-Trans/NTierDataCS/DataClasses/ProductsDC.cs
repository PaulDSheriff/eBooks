using System;
using System.Collections.Generic;
using System.Text;

using System.Data;
using DataCommonCS;

namespace NTierDataCS
{
  [Serializable]
  public abstract class ProductsDC : DCBase
  {
    public ProductsDC.SchemaStruct Schema;

    public ProductsDC()
    {
      Schema = new ProductsDC.SchemaStruct();

      Schema.ObjectName = "tblProducts";
      Schema.ProductId = "iProduct_id";
      Schema.ProductName = "sProductName";
      Schema.Discontinued = "bDiscontinued";
      Schema.Introduced = "dtIntroduced";
      Schema.Price = "cPrice";
      Schema.Cost = "cCost";
    }

    #region "Private fields"
    private int mintProductId;
    private string mstrProductName;
    private string mstrIntroduced;
    private decimal mdecCost;
    private decimal mdecPrice;
    private bool mboolDiscontinued;
    #endregion

    #region "Column Properties"
    public int ProductId
    {
      get { return mintProductId; }
      set { mintProductId = value; }
    }

    public string ProductName
    {
      get { return mstrProductName; }
      set { mstrProductName = value; }
    }

    public string Introduced
    {
      get { return mstrIntroduced; }
      set { mstrIntroduced = value; }
    }

    public decimal Cost
    {
      get { return mdecCost; }
      set { mdecCost = value; }
    }

    public decimal Price
    {
      get { return mdecPrice; }
      set { mdecPrice = value; }
    }

    public bool Discontinued
    {
      get { return mboolDiscontinued; }
      set { mboolDiscontinued = value; }
    }
    #endregion

    #region "Data Retrieval Methods"
    public DataSet GetProducts()
    {
      DataSet ds = null;

      base.SQL = "SELECT * FROM tblProducts";

      // Use the DataLayer to Build DataTable
      ds = DataLayer.GetDataSet(base.SQL, base.ConnectString);

      return ds;
    }

    public DataSet GetProduct(int ProductID)
    {
      DataSet ds = null;

      base.SQL = "SELECT * FROM tblProducts";
      base.SQL += " WHERE iProduct_id = " + ProductID.ToString();

      // Use the DataLayer to Build DataSet
      ds = DataLayer.GetDataSet(base.SQL, base.ConnectString);

      return ds;
    }

    public bool Load(int ProductID)
    {
      DataSet ds = null;
      DataRow dr;
      bool boolRet = false;

      ds = GetProduct(ProductID);
      if (ds != null)
      {
        if (ds.Tables.Count > 0)
        {
          boolRet = true;

          dr = ds.Tables[0].Rows[0];

          mintProductId = Convert.ToInt32(dr[this.Schema.ProductId]);
          mstrProductName = dr[this.Schema.ProductName].ToString();
          mstrIntroduced = dr[this.Schema.Introduced].ToString();
          mdecCost = Convert.ToDecimal(dr[this.Schema.Cost]);
          mdecPrice = Convert.ToDecimal(dr[this.Schema.Price]);
          mboolDiscontinued = Convert.ToBoolean(dr[this.Schema.Discontinued]);
        }
      }
      return boolRet;
    }
    #endregion

    #region "Data Modification Methods"
    public override void Validate()
    {
      string strMsg = string.Empty;

      if (mstrProductName.Trim() == string.Empty)
      {
        strMsg += "Product Name Must Be Filled In" + Environment.NewLine;
      }

      if (mstrIntroduced.Trim() != string.Empty)
      {
        if (!IsDate(mstrIntroduced))
        {
          strMsg += "Date Introduced is not a valid Date" + Environment.NewLine;
        }
      }

      if (strMsg != string.Empty)
      {
        throw new BusinessRuleException(strMsg);
      }
    }

    protected bool IsDate(string Value)
    {
      DateTime dt;
      bool boolRet;

      try
      {
        dt = Convert.ToDateTime(Value);
        boolRet = true;
      }
      catch
      {
        boolRet = false;
      }

      return boolRet;
    }

    public override int Insert()
    {
      // Check Business Rules
      Validate();

      base.SQL = "INSERT INTO tblProducts(sProductName, ";
      base.SQL += " dtIntroduced, cCost, cPrice, bDiscontinued) ";
      base.SQL += "VALUES(@sProductName, @dtIntroduced, ";
      base.SQL += " @cCost, @cPrice, @bDiscontinued) ";

      if (base.TransType == DCTransType.NA)
      {
        base.CommandObject = DataLayer.CreateCommand(base.SQL, base.ConnectString);
      }
      else
      {
        base.CommandObject.CommandText = base.SQL;
      }

      FillInParameters(base.CommandObject);

      return DataLayer.ExecuteSQL(base.CommandObject, 
        (base.TransType == DCTransType.NA));
    }

    public override int Update()
    {
      // Check Business Rules
      Validate();

      base.SQL = "UPDATE tblProducts ";
      base.SQL += "SET sProductName = @sProductName,";
      base.SQL += " dtIntroduced = @dtIntroduced, ";
      base.SQL += " cCost = @cCost, ";
      base.SQL += " cPrice = @cPrice, ";
      base.SQL += " bDiscontinued = @bDiscontinued ";
      base.SQL += " WHERE iProduct_id = @iProduct_id ";

      if (base.TransType == DCTransType.NA)
      {
        base.CommandObject = DataLayer.CreateCommand(base.SQL, base.ConnectString);
      }
      else
      {
        base.CommandObject.CommandText = base.SQL;
      }

      FillInParameters(base.CommandObject);

      return DataLayer.ExecuteSQL(base.CommandObject,
        (base.TransType == DCTransType.NA));
    }

    public override int Delete()
    {
      base.SQL = "DELETE FROM tblProducts ";
      base.SQL += " WHERE iProduct_id = @iProduct_id ";

      if (base.TransType == DCTransType.NA)
      {
        base.CommandObject = DataLayer.CreateCommand(base.SQL, base.ConnectString);
      }
      else
      {
        base.CommandObject.CommandText = base.SQL;
      }

      FillInParameters(base.CommandObject);

      return DataLayer.ExecuteSQL(base.CommandObject,
        (base.TransType == DCTransType.NA));
    }

    protected void FillInParameters(IDbCommand cmd)
    {
      cmd.Parameters.Add(DataLayer.CreateParameter(
       "@iProduct_id", DbType.Int32, mintProductId));
      cmd.Parameters.Add(DataLayer.CreateParameter(
       "@sProductName", DbType.String, mstrProductName));
      cmd.Parameters.Add(DataLayer.CreateParameter(
       "@dtIntroduced", DbType.DateTime, mstrIntroduced));
      cmd.Parameters.Add(DataLayer.CreateParameter(
       "@cCost", DbType.Decimal, mdecCost));
      cmd.Parameters.Add(DataLayer.CreateParameter(
       "@cPrice", DbType.Decimal, mdecPrice));
      cmd.Parameters.Add(DataLayer.CreateParameter(
       "@bDiscontinued", DbType.Decimal, mboolDiscontinued));
    }
    #endregion

    #region "Schema Structure to return Object and Column Names"
    [Serializable]
    public struct SchemaStruct
    {
      public string ObjectName;
      public string ProductId;
      public string ProductName;
      public string Introduced;
      public string Cost;
      public string Price;
      public string Discontinued;
    }
    #endregion
  }
}
