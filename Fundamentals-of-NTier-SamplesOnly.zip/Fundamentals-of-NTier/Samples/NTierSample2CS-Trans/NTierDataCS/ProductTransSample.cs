using System;
using System.Collections.Generic;
using System.Text;

using DataCommonCS;
using ConfigCommonCS;

namespace NTierDataCS
{
  public class ProductTransSample
  {
    public void InsertTwoProducts(Products boProd1, Products boProd2)
    {
      DCTrans trn;

      try
      {
        trn = new DCTrans(AppConfig.ConnectString);
        boProd1.TransType = DCTransType.Insert;
        trn.Add(boProd1);
        boProd2.TransType = DCTransType.Insert;
        trn.Add(boProd2);
        trn.Execute();
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }
  }
}
