using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using NTierDataCS;

namespace NTierSample2CS
{
  public partial class frmMain : Form
  {
    public frmMain()
    {
      InitializeComponent();
    }

    private void btnSample1_Click(object sender, EventArgs e)
    {
      frmProducts frm = new frmProducts();

      frm.Show();
    }

    private void btnTrans_Click(object sender, EventArgs e)
    {
      TransSample();
    }

    private void TransSample()
    {
      ProductTransSample pt = new ProductTransSample();
      Products boProd1 = new Products();
      Products boProd2 = new Products();

      try
      {
        boProd1.Cost = 100;
        boProd1.Discontinued = false;
        boProd1.Introduced = DateTime.Now.ToString();
        boProd1.Price = 200;
        boProd1.ProductName = "A New Product #1";

        boProd2.Cost = 10;
        boProd2.Discontinued = false;
        boProd2.Introduced = DateTime.Now.ToString();
        boProd2.Price = 20;
        boProd2.ProductName = "A New Product #2";

        pt.InsertTwoProducts(boProd1, boProd2);

        MessageBox.Show("Transaction Completed Successfully");

      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
    }
  }
}