namespace NTierSample2CS
{
	partial class frmMain
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.btnSample1 = new System.Windows.Forms.Button();
      this.btnTrans = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // btnSample1
      // 
      this.btnSample1.Location = new System.Drawing.Point(11, 12);
      this.btnSample1.Name = "btnSample1";
      this.btnSample1.Size = new System.Drawing.Size(122, 55);
      this.btnSample1.TabIndex = 5;
      this.btnSample1.Text = "Sample 1";
      this.btnSample1.UseVisualStyleBackColor = true;
      this.btnSample1.Click += new System.EventHandler(this.btnSample1_Click);
      // 
      // btnTrans
      // 
      this.btnTrans.Location = new System.Drawing.Point(152, 12);
      this.btnTrans.Name = "btnTrans";
      this.btnTrans.Size = new System.Drawing.Size(122, 55);
      this.btnTrans.TabIndex = 6;
      this.btnTrans.Text = "Transaction";
      this.btnTrans.UseVisualStyleBackColor = true;
      this.btnTrans.Click += new System.EventHandler(this.btnTrans_Click);
      // 
      // frmMain
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(427, 78);
      this.Controls.Add(this.btnTrans);
      this.Controls.Add(this.btnSample1);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.Name = "frmMain";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "N-Tier Samples";
      this.ResumeLayout(false);

		}

		#endregion

		internal System.Windows.Forms.Button btnSample1;
    internal System.Windows.Forms.Button btnTrans;
	}
}

