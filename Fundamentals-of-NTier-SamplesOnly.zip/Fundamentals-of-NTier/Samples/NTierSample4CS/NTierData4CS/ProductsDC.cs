using System;
using System.Collections.Generic;
using System.Text;

using DataCommonCS;
using System.Data;

namespace NTierData4CS
{
	public abstract class ProductsDC
	{
		private string mstrConnectString;

		public string ConnectString
		{
			get { return mstrConnectString; }
			set { mstrConnectString = value; }
		}

		#region "Data Retrieval Methods"
		public DataSet GetProducts()
		{
			DataSet ds = new DataSet();
			string strSQL;

			strSQL = "SELECT * FROM tblProducts";

			// Use the DataLayer to Build DataTable
			ds = DataLayer.GetDataSet(strSQL, mstrConnectString);

			return ds;
		}

		public DataSet GetProduct(ProductsState prod)
		{
			DataSet ds = null;
			string strSQL;

			strSQL = "SELECT * FROM tblProducts";
			strSQL += " WHERE iProduct_id = " + prod.ProductId.ToString();

			ds = DataLayer.GetDataSet(strSQL, mstrConnectString);

			return ds;
		}

		public bool Load(ProductsState prod)
		{
			DataSet ds;
			DataRow dr;
			bool boolRet = false;

			ds = GetProduct(prod);
			if (ds != null)
			{
				if (ds.Tables.Count > 0)
				{
					boolRet = true;

					dr = ds.Tables[0].Rows[0];

					prod.ProductId = Convert.ToInt32(dr[prod.Schema.ProductId]);
					prod.ProductName = dr[prod.Schema.ProductName].ToString();
					prod.Introduced = dr[prod.Schema.Introduced].ToString();
					prod.Cost = Convert.ToDecimal(dr[prod.Schema.Cost]);
					prod.Price = Convert.ToDecimal(dr[prod.Schema.Price]);
					prod.Discontinued = Convert.ToBoolean(dr[prod.Schema.Discontinued]);
				}
			}
			return boolRet;
		}
		#endregion

		#region "Data Modification Methods"
		public virtual void Validate(ProductsState prod)
		{
			string strMsg = string.Empty;

			if (prod.ProductName.Trim() == string.Empty)
			{
				strMsg += "Product Name Must Be Filled In" + Environment.NewLine;
			}

			if (prod.Introduced.Trim() != string.Empty)
			{
				if (!AppCommon.IsDate(prod.Introduced))
				{
					strMsg += "Date Introduced is not a valid Date" + Environment.NewLine;
				}
			}

			if (strMsg != string.Empty)
			{
				throw new BusinessRuleException(strMsg);
			}
		}

		public int Insert(ProductsState prod)
		{
			IDbCommand cmd;
			string strSQL;

			// Check Business Rules
			Validate(prod);

			strSQL = "INSERT INTO tblProducts( ";
			strSQL += "sProductName, dtIntroduced, cCost, cPrice, bDiscontinued) ";
			strSQL += "VALUES(@sProductName, @dtIntroduced, @cCost, @cPrice, @bDiscontinued) ";

			cmd = DataLayer.CreateCommand(strSQL, mstrConnectString);

			FillInParameters(prod, cmd);

			return DataLayer.ExecuteSQL(cmd, true);
		}

		public int Update(ProductsState prod)
		{
			IDbCommand cmd;
			string strSQL;

			// Check Business Rules
			Validate(prod);

			strSQL = "UPDATE tblProducts ";
			strSQL += "SET sProductName = @sProductName,";
			strSQL += " dtIntroduced = @dtIntroduced, ";
			strSQL += " cCost = @cCost, ";
			strSQL += " cPrice = @cPrice, ";
			strSQL += " bDiscontinued = @bDiscontinued ";
			strSQL += " WHERE iProduct_id = @iProduct_id ";

			cmd = DataLayer.CreateCommand(strSQL, mstrConnectString);

			FillInParameters(prod, cmd);

			return DataLayer.ExecuteSQL(cmd, true);
		}

		public int Delete(ProductsState prod)
		{
			IDbCommand cmd;
			string strSQL;

			strSQL = "DELETE FROM tblProducts ";
			strSQL += " WHERE iProduct_id = @iProduct_id ";

			cmd = DataLayer.CreateCommand(strSQL, mstrConnectString);

			FillInParameters(prod, cmd);

			return DataLayer.ExecuteSQL(cmd, true);
		}

		protected void FillInParameters(ProductsState prod, IDbCommand cmd)
		{
			cmd.Parameters.Add(DataLayer.CreateParameter(
			 "@" + prod.Schema.ProductId, DbType.Int32, prod.ProductId));
			cmd.Parameters.Add(DataLayer.CreateParameter(
			 "@" + prod.Schema.ProductName, DbType.String, prod.ProductName));
			cmd.Parameters.Add(DataLayer.CreateParameter(
			 "@" + prod.Schema.Introduced, DbType.DateTime, prod.Introduced));
			cmd.Parameters.Add(DataLayer.CreateParameter(
			 "@" + prod.Schema.Cost, DbType.Decimal, prod.Cost));
			cmd.Parameters.Add(DataLayer.CreateParameter(
			 "@" + prod.Schema.Price, DbType.Decimal, prod.Price));
			cmd.Parameters.Add(DataLayer.CreateParameter(
			 "@" + prod.Schema.Discontinued, DbType.Decimal, prod.Discontinued));
		}
		#endregion
	}
}
