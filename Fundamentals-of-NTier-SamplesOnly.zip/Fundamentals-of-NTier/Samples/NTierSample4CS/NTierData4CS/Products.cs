using System;
using System.Collections.Generic;
using System.Text;

using System.Data;
using ConfigCommonCS;

namespace NTierData4CS
{
	public class Products : ProductsDC
	{
		#region "Constructors"
		public Products()
		{
			base.ConnectString = AppConfig.ConnectString;
		}

		public Products(string ConnectString)
		{
			base.ConnectString = ConnectString;
		}
		#endregion

		#region "Validate Method"
		public override void Validate(ProductsState prod)
		{
			string strMsg = string.Empty;

			try
			{
				// Check data class business rules
				base.Validate(prod);

			}
			catch (BusinessRuleException ex)
			{
				// Get Business Rule Messages
				strMsg = ex.Message;
			}

			//*******************************************************
			//* CHECK YOUR BUSINESS RULES HERE
			if (prod.Cost < 0 || prod.Cost > 999)
			{
				strMsg += "Cost must be greater than $0.00 and less than $1,000.00" + Environment.NewLine;
			}
			if (prod.Price < 0 || prod.Price > 999)
			{
				strMsg += "Price must be greater than $0.00 and less than $1,000.00" + Environment.NewLine;
			}
			if (prod.Cost > prod.Price)
			{
				strMsg += "Price must be greater than the Cost of the Product" + Environment.NewLine;
			}

			if (strMsg != String.Empty)
			{
				throw new BusinessRuleException(strMsg);
			}
		}
		#endregion

		#region "Custom Methods"

		#endregion

	}
}
