using System;
using System.Collections.Generic;
using System.Text;

namespace NTierData4CS
{
	class AppCommon
	{
		public static bool IsDate(string Value)
		{
			DateTime dt;
			bool boolRet;

			try
			{
				dt = Convert.ToDateTime(Value);
				boolRet = true;
			}
			catch
			{
				boolRet = false;
			}

			return boolRet;
		}
	}
}
