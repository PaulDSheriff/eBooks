using System;
using System.Collections.Generic;
using System.Text;

namespace NTierData4CS
{
	[Serializable]
	public class ProductsState
	{
		public SchemaStruct Schema;

		#region "Constructors"
		public ProductsState()
		{
			Schema = new SchemaStruct();

			Schema.ObjectName = "tblProducts";
			Schema.ProductId = "iProduct_id";
			Schema.ProductName = "sProductName";
			Schema.Discontinued = "bDiscontinued";
			Schema.Introduced = "dtIntroduced";
			Schema.Price = "cPrice";
			Schema.Cost = "cCost";
		}
		#endregion

		#region "Private fields"
		private int mintProductId;
		private string mstrProductName;
		private string mstrIntroduced;
		private decimal mdecCost;
		private decimal mdecPrice;
		private bool mboolDiscontinued;
		#endregion

		#region "Column Properties"
		public int ProductId
		{
			get { return mintProductId; }
			set { mintProductId = value; }
		}

		public string ProductName
		{
			get { return mstrProductName; }
			set { mstrProductName = value; }
		}

		public string Introduced
		{
			get { return mstrIntroduced; }
			set { mstrIntroduced = value; }
		}

		public decimal Cost
		{
			get { return mdecCost; }
			set { mdecCost = value; }
		}

		public decimal Price
		{
			get { return mdecPrice; }
			set { mdecPrice = value; }
		}

		public bool Discontinued
		{
			get { return mboolDiscontinued; }
			set { mboolDiscontinued = value; }
		}
		#endregion

		#region "Schema Structure to return Object and Column Names"
		[Serializable]
		public struct SchemaStruct
		{
			public string ObjectName;
			public string ProductId;
			public string ProductName;
			public string Introduced;
			public string Cost;
			public string Price;
			public string Discontinued;
		}
		#endregion
	}
}
