using System;
using System.Collections.Generic;
using System.Text;

namespace NTierData4CS
{
	[Serializable] public class BusinessRuleException : ApplicationException
	{
		public BusinessRuleException() : base()
		{
		}

		public BusinessRuleException(string msg) : base(msg)
		{
		}

		public BusinessRuleException(string msg, Exception ex) : base(msg, ex)
		{
		}

		public string MessageForWebDisplay
		{
			get { return base.Message.Replace(Environment.NewLine, "<br>"); }
		}
	}
}
