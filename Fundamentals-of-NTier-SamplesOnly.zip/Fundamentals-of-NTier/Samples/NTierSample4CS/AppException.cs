using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace NTierSample4CS
{
	class AppException
	{
		public static void Publish(Exception ex)
		{
			// TODO: Put whatever publishing you want here
			MessageBox.Show(ex.Message);
		}

		public static void Publish(string Message)
		{
			// TODO: Put whatever publishing you want here
			MessageBox.Show(Message);
		}
	}
}
