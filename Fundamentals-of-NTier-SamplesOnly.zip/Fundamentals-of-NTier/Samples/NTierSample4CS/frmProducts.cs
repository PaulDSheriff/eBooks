using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using NTierData4CS;

namespace NTierSample4CS
{
	public partial class frmProducts : NTierSample4CS.frmProductBase
	{
		Products mprod;
		ProductsState mprodState;

		public frmProducts()
		{
			InitializeComponent();
		}

		private void frmProducts_Load(object sender, EventArgs e)
		{
			mprod = new Products();
			mprodState = new ProductsState();

			ProductsLoad();

			this.SetNormalButtonState();
		}

		private void lstProducts_SelectedIndexChanged(object sender, EventArgs e)
		{
			FormShow();

			this.SetNormalButtonState();
		}

		private void ProductsLoad()
		{
			try
			{
				// Use Schema class to return column names
				lstProducts.ValueMember = mprodState.Schema.ProductId;
				lstProducts.DisplayMember = mprodState.Schema.ProductName;

				lstProducts.DataSource = mprod.GetProducts().Tables[0];
			}
			catch (Exception ex)
			{
				AppException.Publish(ex);

			}
		}

		protected override void FormShow()
		{
			try
			{
				// Get Products Class
				mprodState.ProductId = Convert.ToInt32(lstProducts.SelectedValue);

				if (mprod.Load(mprodState))
				{
					lblProductID.Text = mprodState.ProductId.ToString();
					txtProductName.Text = mprodState.ProductName;
					dtpDateIntroduced.Value = Convert.ToDateTime(mprodState.Introduced);
					txtCost.Text = mprodState.Cost.ToString();
					txtPrice.Text = mprodState.Price.ToString();
					chkDiscontinued.Checked = mprodState.Discontinued;
				}
				else
				{
					this.ClearFormControls();
				}

			}
			catch (Exception ex)
			{
				AppException.Publish(ex);

			}
		}

		private void FormMoveToDataClass()
		{

			if (lblProductID.Text.Trim() != "")
				mprodState.ProductId = Convert.ToInt32(lblProductID.Text);

			mprodState.ProductName = txtProductName.Text;
			mprodState.Introduced = dtpDateIntroduced.Value.ToString();
			mprodState.Cost = Convert.ToDecimal(txtCost.Text);
			mprodState.Price = Convert.ToDecimal(txtPrice.Text);
			mprodState.Discontinued = chkDiscontinued.Checked;
		}

		private bool DataAdd()
		{
			bool boolRet = false;
			string strMsg = string.Empty;

			FormMoveToDataClass();

			try
			{
				if (mprod.Insert(mprodState) > 0)
				{
					boolRet = true;

					strMsg = "Successful Insert";
				}
				else
				{
					boolRet = false;

					strMsg = "INSERT DID NOT SUCCEED";
				}

				MessageBox.Show(strMsg);
			}

			// Check for Business Rule Failures
			catch (BusinessRuleException ex)
			{
				MessageBox.Show(ex.Message);
			}

			catch (Exception ex)
			{
				AppException.Publish(ex);
			}

			return boolRet;
		}

		private bool DataUpdate()
		{
			bool boolRet = false;
			string strMsg = string.Empty;

			FormMoveToDataClass();

			try
			{
				if (mprod.Update(mprodState) > 0)
				{
					boolRet = true;

					strMsg = "Successful Update";
				}
				else
				{
					boolRet = false;

					strMsg = "UPDATE DID NOT SUCCEED";
				}

				MessageBox.Show(strMsg);
			}

			// Check for Business Rule Failures
			catch (BusinessRuleException ex)
			{
				MessageBox.Show(ex.Message);
			}

			catch (Exception ex)
			{
				AppException.Publish(ex);
			}

			return boolRet;
		}

		private bool DataDelete()
		{
			bool boolRet = false;
			string strMsg = string.Empty;

			try
			{
				mprodState.ProductId = Convert.ToInt32(lblProductID.Text);

				if (mprod.Delete(mprodState) > 0)
				{
					boolRet = true;

					strMsg = "Successful Delete";
				}
				else
				{
					boolRet = false;

					strMsg = "DELETE DID NOT SUCCEED";
				}

				MessageBox.Show(strMsg);
			}
			catch (Exception ex)
			{
				AppException.Publish(ex);
			}

			return boolRet;
		}

		protected override void btnNew_Click(object sender, EventArgs e)
		{
			base.btnNew_Click(sender, e);

			txtProductName.Focus();
		}

		private void btnSave_Click(object sender, EventArgs e)
		{
			bool boolSucceed;

			if (lblProductID.Text == "")
			{
				boolSucceed = DataAdd();
			}
			else
			{
				boolSucceed = DataUpdate();
			}

			if (boolSucceed)
			{
				// Reload Products
				ProductsLoad();

				this.SetNormalButtonState();
			}
		}

		private void btnDelete_Click(object sender, EventArgs e)
		{
			if (MessageBox.Show("Delete this product?", "Delete?", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
			{
				if (DataDelete())
					ProductsLoad();
			}
		}
	}
}

