Public Class DataLayer
#Region "Data Retrieval Methods"
	Public Shared Function GetDataSet(ByVal SQL As String, _
	 ByVal ConnectString As String) As DataSet
		Dim ds As New DataSet
		Dim da As IDbDataAdapter

		' Create Data Adapter
		da = CreateDataAdapter(SQL, ConnectString)

		da.Fill(ds)

		Return ds
	End Function

	Public Shared Function GetDataSet(ByVal cmd As IDbCommand) As DataSet
		Dim ds As New DataSet
		Dim da As IDbDataAdapter

		' Create Data Adapter
		da = CreateDataAdapter(cmd)

		da.Fill(ds)

		Return ds
	End Function

	Public Shared Function GetDataTable(ByVal SQL As String, _
	 ByVal ConnectString As String) As DataTable
		Dim ds As DataSet
		Dim dt As DataTable = Nothing

		ds = GetDataSet(SQL, ConnectString)

		If ds.Tables.Count > 0 Then
			dt = ds.Tables(0)
		End If

		Return dt
	End Function

	Public Shared Function GetDataReader(ByVal SQL As String, _
	 ByVal ConnectString As String) _
	 As IDataReader

		Dim dr As IDataReader
		Dim cmd As IDbCommand = Nothing

		Try
			' Create Command with Connection Object
			cmd = CreateCommand(SQL, ConnectString)

			' Create the DataReader
			dr = cmd.ExecuteReader( _
			 CommandBehavior.CloseConnection)

		Catch
			' If there is an exception, close the connection
			If cmd.Connection.State <> ConnectionState.Closed Then
				cmd.Connection.Close()
				cmd.Connection.Dispose()
			End If

			' Dispose of the Command
			cmd.Dispose()

			' Rethrow the exception
			Throw
		End Try

		Return dr
	End Function

	Public Shared Function ExecuteScalar( _
	ByVal SQL As String, _
	ByVal ConnectString As String) As Object

		Dim cmd As IDbCommand = Nothing
		Dim value As Object = Nothing

		Try
			' Create Command with Connection Object
			cmd = CreateCommand(SQL, ConnectString)

			' Execute SQL
			value = cmd.ExecuteScalar()

		Catch
			Throw

		Finally
			' Close the connection
			If cmd.Connection.State = ConnectionState.Open Then
				cmd.Connection.Close()
			End If
			' Dispose of the Objects
			cmd.Connection.Dispose()
			cmd.Dispose()
		End Try

		Return value
	End Function
#End Region

#Region "Data Modification Methods"
	Public Shared Function ExecuteSQL(ByVal cmd As IDbCommand, _
	 ByVal DisposeOfCommand As Boolean) As Integer
		Dim intRows As Integer = 0
		Dim boolOpen As Boolean = False

		Try
			' Open the Connection
			If cmd.Connection.State <> ConnectionState.Open Then
				cmd.Connection.Open()
			Else
				boolOpen = Not DisposeOfCommand
			End If

			' Execute SQL
			intRows = cmd.ExecuteNonQuery()
		Catch
			Throw

		Finally
			If Not boolOpen Then
				' Close the connection
				If cmd.Connection.State = ConnectionState.Open Then
					cmd.Connection.Close()
				End If
				' Dispose of the Objects
				cmd.Connection.Dispose()
			End If
			If DisposeOfCommand Then
				cmd.Dispose()
			End If
		End Try

		Return intRows
	End Function

	Public Shared Function ExecuteSQL(ByVal cmd As IDbCommand) As Integer
		Return ExecuteSQL(cmd, False)
	End Function

	' The following ExecuteSQL method is for Dynamic SQL
	Public Shared Function ExecuteSQL( _
	ByVal SQL As String, _
	ByVal ConnectString As String) As Integer

		Dim cmd As IDbCommand = Nothing
		Dim intRows As Integer

		cmd = CreateCommand(SQL, ConnectString)

		' Execute SQL
		intRows = ExecuteSQL(cmd, True)

		Return intRows
	End Function
#End Region

#Region "Create Connection/Command/Parameter/DataAdapter Objects"
	Public Shared Function CreateConnection(ByVal ConnectString As String) As IDbConnection
		Dim cnn As IDbConnection

		cnn = DataProvider.CreateConnection()
		cnn.ConnectionString = ConnectString

		Return cnn
	End Function

	Public Shared Function CreateCommand(ByVal SQL As String) As IDbCommand
		Dim cmd As IDbCommand

		cmd = DataProvider.CreateCommand()

		cmd.CommandText = SQL

		Return cmd
	End Function

	Public Shared Function CreateCommand(ByVal SQL As String, ByVal ConnectString As String) As IDbCommand
		Return CreateCommand(SQL, ConnectString, True)
	End Function

	Public Shared Function CreateCommand(ByVal SQL As String, ByVal ConnectString As String, ByVal OpenConnection As Boolean) As IDbCommand
		Dim cmd As IDbCommand

		cmd = CreateCommand(SQL)

		cmd.Connection = CreateConnection(ConnectString)
		If OpenConnection Then
			cmd.Connection.Open()
		End If

		Return cmd
	End Function

	Public Shared Function CreateParameter(ByVal ParameterName As String) As IDataParameter
		Dim param As IDataParameter

		param = DataProvider.CreateParameter()
		param.ParameterName = ParameterName

		Return param
	End Function

	Public Shared Function CreateParameter(ByVal ParameterName As String, ByVal DataType As DbType) As IDataParameter
		Dim param As IDataParameter

		param = DataProvider.CreateParameter()
		param.DbType = DataType
		param.ParameterName = ParameterName

		Return param
	End Function

	Public Shared Function CreateParameter(ByVal ParameterName As String, ByVal DataType As DbType, ByVal Value As Object) As IDataParameter
		Dim param As IDataParameter

		param = DataProvider.CreateParameter()
		param.DbType = DataType
		param.Value = Value
		param.ParameterName = ParameterName

		Return param
	End Function

	Public Shared Function CreateDataAdapter(ByVal SQL As String, ByVal ConnectString As String) As IDbDataAdapter
		Dim da As IDbDataAdapter

		da = DataProvider.CreateDataAdapter()

		da.SelectCommand = CreateCommand(SQL, ConnectString, False)

		Return da
	End Function

	Public Shared Function CreateDataAdapter(ByVal cmd As IDbCommand) As IDbDataAdapter
		Dim da As IDbDataAdapter

		da = DataProvider.CreateDataAdapter()

		da.SelectCommand = cmd

		Return da
	End Function
#End Region
End Class
