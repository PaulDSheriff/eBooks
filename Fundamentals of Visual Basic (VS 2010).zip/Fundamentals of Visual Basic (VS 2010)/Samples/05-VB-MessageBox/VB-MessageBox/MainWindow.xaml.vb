﻿Class MainWindow 

    Private Sub btnSimple_Click(ByVal sender As Object, ByVal e As RoutedEventArgs) Handles btnSimple.Click
        MessageBox.Show("Do you want to quit?")
    End Sub

    Private Sub btnWithTitle_Click(ByVal sender As Object, ByVal e As .RoutedEventArgs) Handles btnWithTitle.Click
        MessageBox.Show("Do you want to quit?", "MessageBox Sample")
    End Sub

    Private Sub btnWithButtons_Click(ByVal sender As Object, ByVal e As RoutedEventArgs) Handles btnWithButtons.Click
        MessageBox.Show("Do you want to quit?", _
         "MessageBox Sample", _
         MessageBoxButton.YesNo, _
         MessageBoxImage.Question, _
         MessageBoxResult.OK)
    End Sub

    Private Sub btnWithResult_Click(ByVal sender As Object, ByVal e As RoutedEventArgs) Handles btnWithResult.Click
        Dim dr As MessageBoxResult

        dr = MessageBox.Show("Do you want to quit?", _
         "MessageBox Sample", _
         MessageBoxButton.YesNo, _
         MessageBoxImage.Question, _
         MessageBoxResult.Yes)

        Select Case dr
            Case MessageBoxResult.Yes
                Me.Close()

            Case MessageBoxResult.No
                ' Do Nothing at all

        End Select
    End Sub
End Class
