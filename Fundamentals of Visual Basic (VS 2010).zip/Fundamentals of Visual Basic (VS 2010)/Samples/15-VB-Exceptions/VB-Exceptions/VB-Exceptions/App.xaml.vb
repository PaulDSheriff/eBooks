﻿Imports System.Collections.Generic
Imports System.Configuration
Imports System.Data
Imports System.Linq
Imports System.Windows
Imports System.Windows.Threading

Namespace VB_Exceptions
    Partial Public Class App
        Inherits System.Windows.Application
        Public TurnOnGlobalExceptionHandling As Boolean = False

        Protected Overrides Sub OnStartup(ByVal e As StartupEventArgs)
            ' define application exception handler
            AddHandler System.Windows.Application.Current.DispatcherUnhandledException, AddressOf AppDispatcherUnhandledException

            ' defer other startup processing to base class
            MyBase.OnStartup(e)
        End Sub

        Private Sub AppDispatcherUnhandledException(ByVal sender As Object, ByVal e As DispatcherUnhandledExceptionEventArgs)
            If TurnOnGlobalExceptionHandling Then
                'do whatever you need to do with the exception
                'e.Exception
                MessageBox.Show(e.Exception.Message)

                e.Handled = True
            End If
        End Sub
    End Class
End Namespace