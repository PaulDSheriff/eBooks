﻿Imports System.IO
Imports System.Security
Imports System.Text
Imports System.Windows

Namespace VB_Exceptions
    Partial Public Class MainWindow
        Inherits Window
        Public Sub New()
            InitializeComponent()
        End Sub

#Region "Display Message Methods"
        Private Sub DisplayMessage(ByVal msg As String)
            tbMessage.Text = msg
        End Sub

        Private Sub DisplayMessage(ByVal ex As Exception)
            Dim sb As New StringBuilder()

            sb.Append("Data: " & Convert.ToString(ex.Data) & Environment.NewLine)
            sb.Append("HelpLink: " & ex.HelpLink & Environment.NewLine)
            sb.Append("Message: " & ex.Message & Environment.NewLine)
            sb.Append("Source: " & ex.Source & Environment.NewLine)
            sb.Append("StackTrace: " & ex.StackTrace & Environment.NewLine)
            sb.Append("TargetSite: " & Convert.ToString(ex.TargetSite) & Environment.NewLine)

            tbMessage.Text = sb.ToString()
        End Sub
#End Region

#Region "No Exception Handling"
        Private Sub btnNoHandling_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
            NoExceptionHandling()
        End Sub

        Private Sub NoExceptionHandling()
            Dim fileSize As Long
            Dim fs As FileStream

            ' No error handling? If there's an error, 
            ' you just get an unhandled exception.    
            fs = File.Open(txtFileName.Text, FileMode.Open)
            fileSize = fs.Length
            fs.Close()
        End Sub
#End Region

#Region "Simple Catch"
        Private Sub btnCatch_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
            SimpleCatch()
        End Sub

        Private Sub SimpleCatch()
            Dim fileSize As Long
            Dim fs As FileStream

            ' This is better, but not much. You
            ' don't really have any idea what 
            ' went wrong!
            Try
                fs = File.Open(txtFileName.Text, FileMode.Open)
                fileSize = fs.Length
                fs.Close()
            Catch
                DisplayMessage("Error occurred!")
            End Try
        End Sub
#End Region

#Region "Simple Exception"
        Private Sub btnSimple_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
            SimpleException()
        End Sub

        Private Sub SimpleException()
            Dim fileSize As Long
            Dim fs As FileStream

            ' Display the entire contents of the Exception object.
            Try
                fs = File.Open(txtFileName.Text, FileMode.Open)
                fileSize = fs.Length
                fs.Close()
            Catch ex As Exception
                ' DisplayMessage(ex.ToString();
                DisplayMessage(ex.Message)
            End Try
        End Sub
#End Region

#Region "Display Exception Properties"
        Private Sub btnProperties_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
            DisplayExceptionProperties()
        End Sub

        Private Sub DisplayExceptionProperties()
            Dim fileSize As Long
            Dim fs As FileStream

            ' Display the entire contents of the Exception object.
            Try
                fs = File.Open(txtFileName.Text, FileMode.Open)
                fileSize = fs.Length
                fs.Close()
            Catch ex As Exception
                DisplayMessage(ex)
            End Try
        End Sub
#End Region

#Region "Exception Bubbling"
        Private Sub btnBubbling_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
            ExceptionBubbling()
        End Sub

        Private Sub ExceptionBubbling()
            ' What happens to unhandled errors?
            Try
                MethodOne()
            Catch
                DisplayMessage("An error bubbled up from lower level procedure!")
            End Try
        End Sub

        Private Sub MethodOne()
            MethodTwo()
        End Sub

        Private Sub MethodTwo()
            MethodThree()
        End Sub

        Private Sub MethodThree()
            Dim fileSize As Long
            Dim fs As FileStream

            ' No error handling here!
            fs = File.Open(txtFileName.Text, FileMode.Open)
            fileSize = fs.Length
            fs.Close()
        End Sub
#End Region

#Region "Finally Block"
        Private Sub btnFinally_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
            TestFinally()
        End Sub

        Private Sub TestFinally()
            Dim fileSize As Long
            Dim fs As FileStream = Nothing

            Try
                fs = File.Open(txtFileName.Text, FileMode.Open)
                fileSize = fs.Length
            Catch ex As Exception
                DisplayMessage(ex.Message)
            Finally
                ' Close the file here
                If fs IsNot Nothing Then
                    fs.Close()
                End If
            End Try
        End Sub
#End Region

#Region "Multiple Catch Blocks"
        Private Sub btnMultiple_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
            MultipleExceptions()
        End Sub

        Private Sub MultipleExceptions()
            Dim fileSize As Long
            Dim fs As FileStream = Nothing

            ' Use the most specific exception that you can.
            ' To test this, change the file name to be:

            ' 1.) In a good location, but the file doesn't exist.
            ' 2.) On a drive that doesn't exist.
            ' 3.) In a path that doesn't exist.
            ' 4.) On a drive that isn't ready.

            Try
                fs = File.Open(txtFileName.Text, FileMode.Open)

                ' The code will match against the most specific error
                ' it can. Both FileNotFoundException and 
                ' DirectoryNotFoundException inherit from 
                ' IOException, and the code will use those first. 
                ' If they weren't here, the code would always fall 
                ' into(IOException) for those errors.        
                fileSize = fs.Length
            Catch ex As ArgumentNullException
                DisplayMessage("You passed in a Null argument." & ex.Message)
            Catch ex As ArgumentException
                DisplayMessage("You specified an invalid filename. " & "Make sure you enter something besides spaces." & ex.Message)
            Catch ex As FileNotFoundException
                DisplayMessage("The file you specified can't be found. " & "Please try again." & ex.Message)
            Catch ex As UnauthorizedAccessException
                DisplayMessage("You specified a folder name, not a file name." & ex.Message)
            Catch ex As DirectoryNotFoundException
                DisplayMessage("You specified a folder that doesn't exist " & "or can't be found." & ex.Message)
            Catch ex As SecurityException
                DisplayMessage("You don't have sufficient rights " & "to open the selected file." & ex.Message)
            Catch ex As IOException
                ' A generic exception handler, for any IO error
                ' that hasn't been caught yet. Here, it ought
                ' to just be that the drive isn't ready.
                DisplayMessage("The drive you selected is not ready. " & "Make sure the drive contains valid media." & ex.Message)
            Catch ex As Exception
                DisplayMessage("An unknown error occurred." & ex.Message)
            Finally
                ' finally runs no matter what else happens
                ' Close the file here
                If fs IsNot Nothing Then
                    fs.Close()
                End If
            End Try
        End Sub
#End Region

#Region "Throw Exception"
        Private Sub btnThrow_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
            ThrowException()
        End Sub

        Private Sub ThrowException()
            ' Catch an exception thrown by the called procedure.
            Try
                TestThrow()
            Catch ex As FileNotFoundException
                DisplayMessage("Error occurred: " & ex.Message)
                ' Use ex.InnerException to get to error
                ' that triggered this one.

                Try
                    DisplayMessage(ex.InnerException.Message)
                    ' DO nothing at all!
                Catch
                End Try
            Catch ex As Exception
                DisplayMessage(ex.Message)
            End Try
        End Sub

        Private Sub TestThrow()
            Dim fileSize As Long
            Dim fs As FileStream = Nothing

            ' No matter what happens, throw back 
            ' a File Not Found exception.
            Try
                fs = File.Open(txtFileName.Text, FileMode.Open)
                fileSize = fs.Length
            Catch ex As Exception
                Throw New FileNotFoundException("Unable to open the specified file.", ex)
            Finally
                ' finally runs no amtter what else happens
                ' Close the file here
                If fs IsNot Nothing Then
                    fs.Close()
                End If
            End Try
        End Sub
#End Region

#Region "Custom Exception"
        Private Sub btnCustom_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
            CustomException()
        End Sub

        Public Sub CustomException()
            Dim fileSize As Long = 0
            Dim fs As FileStream = Nothing

            Try
                fs = File.Open(txtFileName.Text, FileMode.Open, FileAccess.Read)
                fileSize = fs.Length
                If fileSize > 100 Then
                    '  Pass back the new exception. There's no
                    ' inner exception to pass back, so pass null
                    Throw (New FileTooLargeException("The file you selected is too large.", Nothing, fileSize))
                End If
            Catch ex As Exception
                DisplayMessage(ex.ToString())
            Finally
                ' Run this code no matter what happens.
                If fs IsNot Nothing Then
                    fs.Close()
                    ' Close file here
                End If
            End Try
        End Sub
#End Region

#Region "Global Exception Handling"
        Private Sub btnGlobal_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
            GlobalExceptionHandling()
        End Sub

        Private Sub GlobalExceptionHandling()
            ' NOTE: In order to test the Global Exception Handling
            ' you need to go into Tools | Options | Debugging | General
            ' and turn off the "Enable Just My Code".
            TryCast(Application.Current, App).TurnOnGlobalExceptionHandling = True

            NoExceptionHandling()
        End Sub
#End Region
    End Class
End Namespace