﻿Imports System.Text

Namespace VB_Exceptions
    Public Class FileTooLargeException
        Inherits Exception

        Private m_ClassName As String
        Private m_MethodName As String
        Private m_FileSize As Long

        Public Property ClassName() As String
            Get
                Return m_ClassName
            End Get
            Set(ByVal value As String)
                m_ClassName = value
            End Set
        End Property

        Public Property MethodName() As String
            Get
                Return m_MethodName
            End Get
            Set(ByVal value As String)
                m_MethodName = value
            End Set
        End Property

        Public Property FileSize() As Long
            Get
                Return m_FileSize
            End Get
            Set(ByVal value As Long)
                m_FileSize = value
            End Set
        End Property

        Public Sub New(ByVal message As String)
            MyBase.New(message)
        End Sub

        Public Sub New(ByVal message As String, ByVal innerException As Exception)
            MyBase.New(message, innerException)
        End Sub

        Public Sub New(ByVal message As String, ByVal innerException As Exception, ByVal size As Long)
            MyBase.New(message, innerException)
            FileSize = size
        End Sub

        Public Overrides Function ToString() As String
            Dim sb As New StringBuilder(256)

            sb.Append("Class Name: " & ClassName & Environment.NewLine)
            sb.Append("Method Name: " & MethodName & Environment.NewLine)
            sb.Append("File Size: " & FileSize.ToString() & Environment.NewLine)

            Return sb.ToString()
        End Function
    End Class
End Namespace