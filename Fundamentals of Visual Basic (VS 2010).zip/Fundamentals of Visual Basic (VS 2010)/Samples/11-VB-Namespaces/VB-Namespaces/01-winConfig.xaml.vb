﻿Imports System.Configuration

Public Class winConfig
	Private Sub btnConfig_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnConfig.Click
		txtStateCode.Text = ConfigurationManager.AppSettings("DefaultStateCode")
		txtEmpType.Text = ConfigurationManager.AppSettings("DefaultEmployeeType")
	End Sub

	Private Sub btnConnection_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnConnection.Click
		txtSandbox.Text = ConfigurationManager.ConnectionStrings("Sandbox").ConnectionString
		txtNorthwind.Text = ConfigurationManager.ConnectionStrings("Northwind").ConnectionString
	End Sub
End Class
