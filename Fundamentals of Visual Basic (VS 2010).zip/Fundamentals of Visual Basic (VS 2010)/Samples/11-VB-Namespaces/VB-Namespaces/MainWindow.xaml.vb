﻿Class MainWindow 

	Private Sub btnConfig_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnConfig.Click
		Dim win As New winConfig

		win.Show()
	End Sub

	Private Sub btnData_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnData.Click
		Dim win As New winData

		win.Show()
	End Sub

	Private Sub btnFile_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnFile.Click
		Dim win As New winFile

		win.Show()
	End Sub
End Class
