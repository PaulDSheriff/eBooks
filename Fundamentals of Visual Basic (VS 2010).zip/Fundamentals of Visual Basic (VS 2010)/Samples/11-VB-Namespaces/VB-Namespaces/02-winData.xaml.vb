﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration

Public Class winData
	Private Sub Window_Loaded(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles MyBase.Loaded
		txtConnectString.Text = ConfigurationManager.ConnectionStrings("Sandbox").ConnectionString
	End Sub

	Private Sub btnGetData_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnGetData.Click
		GetData()
	End Sub

	Private Sub GetData()
		Dim dt As New DataTable
		Dim da As SqlDataAdapter

		da = New SqlDataAdapter("SELECT * FROM Product", txtConnectString.Text)

		da.Fill(dt)

		lstData.DataContext = dt
	End Sub
End Class
