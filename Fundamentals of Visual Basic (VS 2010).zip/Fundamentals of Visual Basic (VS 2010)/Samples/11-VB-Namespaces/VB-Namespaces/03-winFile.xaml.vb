﻿Imports System.IO

Public Class winFile
	Private Sub Window_Loaded(sender As Object, e As RoutedEventArgs) Handles MyBase.Loaded
		txtFileName.Text = Environment.CurrentDirectory + "\Test.txt"
		txtFolderName.Text = Environment.SystemDirectory
	End Sub

	Private Sub btnWrite_Click(sender As Object, e As RoutedEventArgs) Handles btnWrite.Click
		WriteFile()
	End Sub

	Private Sub WriteFile()
		File.AppendAllText(txtFileName.Text, txtData.Text)
		MessageBox.Show("File Written.")
	End Sub

	Private Sub btnRead_Click(sender As Object, e As RoutedEventArgs) Handles btnRead.Click
		ReadFile()
	End Sub

	Private Sub ReadFile()
		tbTextRead.Text = File.ReadAllText(txtFileName.Text)
	End Sub

	Private Sub btnGetFiles_Click(sender As Object, e As RoutedEventArgs) Handles btnGetFiles.Click
		GetFilesFromFolder()
	End Sub

	Private Sub GetFilesFromFolder()
		lstFiles.ItemsSource = Directory.GetFiles(txtFolderName.Text)
	End Sub
End Class
