﻿Public Class Employee
#Region "Constructors"
    Public Sub New()

    End Sub
    Private eID As Integer
    Private eFirstName As String
    Private eLastName As String

    Public Sub New(ByVal firstName As String)
        firstName = firstName
    End Sub
#End Region

    Public Property ID() As Integer
        Get
            Return eID
        End Get
        Set(ByVal value As Integer)
            eID = value
        End Set
    End Property

    Public Property FirstName() As String
        Get
            Return eFirstName
        End Get
        Set(ByVal value As String)
            eFirstName = value
        End Set
    End Property

    Public Property LastName() As String
        Get
            Return eLastName
        End Get
        Set(ByVal value As String)
            eLastName = value
        End Set
    End Property


    Public Function IsValid() As Boolean
        Return (LastName.Trim() <> String.Empty)
    End Function
End Class
