﻿Imports System.Collections.Generic
Imports System.Configuration
Imports System.Data
Imports System.Linq
Imports System.Windows

Namespace VB_Debug
    ''' <summary>
    ''' Interaction logic for Appl.xaml
    ''' </summary>
    Partial Public Class App
        Inherits Application

    End Class
End Namespace