﻿Imports System.Text

Class MainWindow
#Region "Locals Window"
    Private Sub btnLocalsWindow_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        LocalsWindowSample()
    End Sub

    Private Sub LocalsWindowSample()
        Dim IsValueOk As Boolean = False
        Dim aChar As Char = ControlChars.NullChar
        Dim MyByte As Byte = 0
        Dim BeginDate As DateTime = Nothing
        Dim StartTime As DateTime = Nothing
        Dim index As Short = 0
        Dim pk As Integer = 0
        Dim pkLong As Long = 0
        Dim quantity As Single = 0

        Debugger.Break()
    End Sub
#End Region

#Region "Autos Window"
    Private Sub btnAutosWindow_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        AutosWindow()
    End Sub

    Public Sub AutosWindow()
        Dim IsValueOk As Boolean = False
        Dim aChar As Char = ControlChars.NullChar
        Dim MyByte As Byte = 0
        Dim BeginDate As DateTime = Nothing
        Dim StartTime As DateTime = Nothing
        Dim index As Short = 0
        Dim pk As Integer = 0
        Dim pkLong As Long = 0
        Dim quantity As Single = 0
        Dim amount As Double = 0
        Dim price As Decimal = Nothing
        Dim name As String = Nothing

        aChar = Convert.ToChar("A")
        IsValueOk = True
        MyByte = 1
        BeginDate = Convert.ToDateTime("01/09/2011")
        StartTime = Convert.ToDateTime("01/01/0001")
        index = 10
        pk = 100000
        pkLong = 29393838383L
        quantity = Convert.ToSingle(2.5)
        amount = 3.2233
        price = Convert.ToDecimal(500.65)
        name = "Paul"

        Debugger.Break()
    End Sub

#End Region

#Region "Call Stack Window"
    Private Sub btnCallStack_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        FirstMethod()
    End Sub

    Private Sub FirstMethod()
        SecondMethod()
    End Sub

    Private Sub SecondMethod()
        ThirdMethod()
    End Sub

    Private Sub ThirdMethod()
        FourthMethod()
    End Sub

    Private Sub FourthMethod()
        FifthMethod()
    End Sub

    Private Sub FifthMethod()
        ' When you get here go to Debug | Windows | Call Stack to see how you got here.
        Debugger.Break()
    End Sub
#End Region

#Region "Drag & Drop into Watch Window"
    Private Sub btnWatchWindow_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        Debugger.Break()

        ' Show drag & drop & changing values
        WatchvsImmediate()
    End Sub
#End Region

#Region "Watch vs Immediate Window"
    Private Shared mNumber As Integer = 0

    Private Sub btnWatchVsImmediate_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        Debugger.Break()

        WatchvsImmediate()
    End Sub

    Private Sub WatchvsImmediate()
        mNumber = 1
        MainWindow.IncrementNumber()
    End Sub

    Private Shared Function IncrementNumber() As Integer
        mNumber += 1

        If mNumber = 4 Then
            Console.WriteLine("mNumber = 4")
        End If

        Return mNumber
    End Function
#End Region

#Region "Autos Window: Working with Classes"
    Private Sub btnWorkingWithClasses_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        WorkingWithClasses()
    End Sub

    Private Sub WorkingWithClasses()
        Dim emp As New Employee() With {.FirstName = "John", .LastName = "Smith", .ID = 1}
        Debugger.Break()
    End Sub
#End Region

#Region "Immediate Window"
    Private Sub btnImmediateWindow_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        Dim index As Integer = 0

        Debugger.Break()

        index += 1
        ' Open the Immediate Window and try entering some commands
        ' For example: ? 1 + 3
        '              ? index
        '              index = 4;  // Sets the local variable
        '              ? index     // Will now print 4
    End Sub
#End Region

#Region "Command Window"
    Private Sub btnCommandWindow_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        Dim index As Integer = 0

        Debugger.Break()

        index += 1
        ' Open the Command Window and try entering some commands
        ' For example: ? 1 + 3
        '              ? index
        '              index = 4;  // Sets the local variable
        '              ? index     // Will now print 4
    End Sub
#End Region

#Region "Thread Window"
    Private Sub btnThreadWindow_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        ' Open the Threads Window
        Debugger.Break()
    End Sub
#End Region

#Region "Modules Window"
    Private Sub btnModulesWindow_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        ' Open the Modules Window
        Debugger.Break()
    End Sub
#End Region

#Region "ForLoop Breakpoints"
    Private Sub btnForLoopBreakPoints_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        ForLoopBreaks()
    End Sub

    Private Sub ForLoopBreaks()
        For index As Integer = 0 To 9
            Console.WriteLine("Loop index: " & index.ToString())
        Next
    End Sub
#End Region

#Region "Break at Function"
    Private Sub btnBreakAtFunction_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        ' Select Debug | New Breakpoint | Break at Function...
        BreakHereSample()
    End Sub

    Private Sub BreakHereSample()
        MessageBox.Show("Hello")
    End Sub
    Private Sub BreakHere(ByVal msg As String)
        MessageBox.Show(msg)
    End Sub

    Private Sub BreakHere(ByVal msg As String, ByVal caption As String)
        MessageBox.Show(msg, caption)
    End Sub

    Private Sub BreakHere(ByVal msg As String, ByVal caption As String, ByVal writeMsg As String)
        MessageBox.Show(msg, caption)
        Console.WriteLine(writeMsg)
    End Sub
#End Region

#Region "Hit Count Sample"
    Private Sub btnHitCount_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        HitCountSample()
    End Sub

    Private Sub HitCountSample()
        ' Set Hit count on index variable
        For index As Integer = 0 To 9
            Console.WriteLine("Loop index: " & index.ToString())
        Next
    End Sub
#End Region

#Region "Conditional Break Sample"
    Private Sub btnConditionalBreaks_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        ConditionalBreakSample()
    End Sub

    Private Sub ConditionalBreakSample()
        Dim sb As New StringBuilder(1024)
        Dim lastId As Integer

        Dim xElem = XElement.Load(GetEmployeeFile())

        ' Get All Employees 





        Dim emps = From emp In xElem.Descendants("Employee") Select New Employee With { _
        .ID = Convert.ToInt32(emp.Element("id").Value), _
        .FirstName = emp.Element("FirstName").Value, _
        .LastName = emp.Element("LastName").Value}


        'Break where emp.id==3
        For Each emp As Employee In emps
            lastId = emp.ID
            sb.AppendFormat("id={0}", emp.ID.ToString())
            sb.AppendFormat(" - FirstName={0}", emp.FirstName)
            sb.AppendFormat(" - LastName={0}", emp.LastName)
            sb.Append(Environment.NewLine)
        Next
    End Sub
#End Region

#Region "Change Value Sample"
    Private Sub btnChangeValues_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        ChangeValue()
    End Sub

    Private Sub ChangeValue()
        ' Set breakpoint and change index on the fly using the Immediate Window
        For index As Integer = 0 To 9
            Console.WriteLine("Loop index: " & index.ToString())
        Next
    End Sub
#End Region

#Region "Call Method Sample"
    Private Sub btnCallMethod_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        CallMethodSample()
    End Sub

    Private Sub CallMethodSample()
        Dim emp As New Employee() With { _
         .FirstName = "John", _
         .LastName = "Smith", _
         .ID = 1 _
        }

        ' Set a conditional breakpoint here by calling emp.IsValid() == false
        Console.WriteLine(emp.LastName)

        emp.LastName = String.Empty

        ' Set a conditional breakpoint here by calling emp.IsValid() == false
        Console.WriteLine(emp.LastName)
    End Sub
#End Region

#Region "Set Next Statement"
    Private Sub btnSetNextStatement_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        SetNextStatement()
    End Sub

    Private Sub SetNextStatement()
        Dim sb As New StringBuilder(1024)
        Dim xElem = XElement.Load(GetEmployeeFile())

        ' Get All Employees 
        Dim emps = From emp In xElem.Descendants("Employee") Select New Employee With { _
        .ID = Convert.ToInt32(emp.Element("id").Value), _
        .FirstName = emp.Element("FirstName").Value, _
        .LastName = emp.Element("LastName").Value _
       }

        Debugger.Break()

        For Each emp As Employee In emps
            sb.AppendFormat("id={0}", emp.id.ToString())
            sb.AppendFormat(" - FirstName={0}", emp.FirstName)
            sb.AppendFormat(" - LastName={0}", emp.LastName)
            sb.Append(Environment.NewLine)
        Next

        Console.WriteLine("Finished")
    End Sub
#End Region

#Region "DataTips Sample"
    Private Sub btnDataTips_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        DataTipsSample()
    End Sub

    Private Sub DataTipsSample()
        Dim xElem = XElement.Load(GetEmployeeFile())

        Debugger.Break()
    End Sub
#End Region

#Region "Support Methods"
    Public Shared Function GetCurrentDirectory() As String
        Dim ret As String

        ret = AppDomain.CurrentDomain.BaseDirectory
        If ret.IndexOf("\bin") > 0 Then
            ret = ret.Substring(0, ret.LastIndexOf("\bin"))
        End If

        Return ret
    End Function

    Public Shared Function GetEmployeeFile() As String
        Dim strFile As String

        strFile = GetCurrentDirectory()
        strFile += "\XML\Employee.xml"

        Return strFile
    End Function
#End Region

#Region "Tracepoint Sample"
    Private Sub btnTracePoints_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        TracepointSample()
    End Sub

    Private Sub TracepointSample()
        ' Set Tracepoint
        For index As Integer = 0 To 9
            Console.WriteLine("Loop index: " & index.ToString())
        Next
    End Sub
#End Region

#Region "Debug Class"
    Private Sub btnDebugClass_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        Dim win As New _01_winDebugClass()

        win.Show()
    End Sub
#End Region

#Region "Trace Class"
    Private Sub btnTraceClass_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        TraceSample()
    End Sub

    Private Sub TraceSample()
        Trace.WriteLine("This is Trace 1")
        Trace.WriteLine("This is Trace 2")
    End Sub
#End Region

End Class
