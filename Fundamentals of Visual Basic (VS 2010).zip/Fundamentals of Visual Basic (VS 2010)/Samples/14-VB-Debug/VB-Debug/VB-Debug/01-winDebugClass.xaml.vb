﻿Public Class _01_winDebugClass

    Private Sub btnWriteLine_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
        WriteLineSample()
    End Sub
    Private Sub WriteLineSample()
        Debug.Write("No CRLF after this...")
        Debug.WriteLine("Number: " + txtNumber.Text)
    End Sub

    Private Sub btnWriteLineIf_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
        WriteLineIfSample()
    End Sub
    Private Sub WriteLineIfSample()
        Dim num As Integer
        num = Convert.ToInt32(txtNumber.Text)
        Debug.WriteLineIf(num >= 0 AndAlso num <= 5, "You input a correct number")
    End Sub

    Private Sub btnAssert_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
        AssertSample()
    End Sub

    Private Sub AssertSample()
        Dim num As Integer
        num = Convert.ToInt32(txtNumber.Text)
        Debug.Assert(num >= 0 AndAlso num <= 5, _
            "Number must be between 0 and 5", "This assertion occured in the btnAssert_Click event procedure in the winDebugClass window.")




    End Sub



End Class
