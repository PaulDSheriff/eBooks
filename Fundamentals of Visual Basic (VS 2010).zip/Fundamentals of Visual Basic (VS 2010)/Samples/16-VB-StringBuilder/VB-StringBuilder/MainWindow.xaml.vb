﻿' The StringBuilder class is in this namespace
Imports System.Text

Class MainWindow
	Private msb As StringBuilder

	Private Sub DisplayMessage(msg As String)
		tbMessage.Text = msg
	End Sub

	Private Sub btnCreate_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnCreate.Click
		CreateSample(txtSentence.Text)
	End Sub

    Private Sub CreateSample(ByVal value As String)
        ' Create string and put in initial value
        msb = New StringBuilder(value)

        DisplayMessage(msb.ToString())
    End Sub

	Private Sub btnCreate2_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnCreate2.Click
		CreateSample2(txtSentence.Text)
	End Sub

	Private Sub CreateSample2(value As String)
		' Allocate 100 bytes of storage to start
		msb = New StringBuilder(value, 100)

		DisplayMessage(msb.ToString())
	End Sub

	Private Sub btnCreate3_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnCreate3.Click
		CreateSample3()
	End Sub

	Private Sub CreateSample3()
		' Allocate 100 bytes of storage to start and 200 maximum
		msb = New StringBuilder(100, 200)

		DisplayMessage(msb.ToString())
	End Sub

	Private Sub btnAppend_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnAppend.Click
		AppendSample(txtSentence.Text)
	End Sub

	Private Sub AppendSample(value As String)
		msb = New StringBuilder()

		msb.Append(value)

		DisplayMessage(msb.ToString())
	End Sub

	Private Sub btnCapacity_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnCapacity.Click
		CapacitySample(txtSentence.Text)
	End Sub

	Private Sub CapacitySample(value As String)
		msb = New StringBuilder(value)

		msb.Append(Environment.NewLine)
		msb.Append("Length is: " & msb.Length.ToString())
		msb.Append(Environment.NewLine)
		msb.Append("Capacity is: " & msb.Capacity.ToString())
		msb.Append(Environment.NewLine)
		msb.Append("Maximum Capacity is: " & msb.MaxCapacity.ToString())

		DisplayMessage(msb.ToString())
	End Sub

	Private Sub btnAppendFormat_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnAppendFormat.Click
		AppendFormatSample(txtSentence.Text)
	End Sub

	Private Sub AppendFormatSample(value As String)
		msb = New StringBuilder(value)

		msb.Append(Environment.NewLine)
		msb.AppendFormat("{0}: {1}", "Capacity is", msb.Capacity)
		msb.Append(Environment.NewLine)
		msb.AppendFormat("{0}: {1}", "Length is", msb.Length)

		DisplayMessage(msb.ToString())
	End Sub

	Private Sub btnChars_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnChars.Click
		CharsSample(txtSentence.Text)
	End Sub

	Private Sub CharsSample(value As String)
		msb = New StringBuilder(value)

		' Change some individual characters
		msb.Chars(0) = Convert.ToChar(",")
		msb.Chars(10) = Convert.ToChar(".")

		DisplayMessage(msb.ToString())
	End Sub

	Private Sub btnInsert_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnInsert.Click
		InsertSample(txtSentence.Text)
	End Sub

	Private Sub InsertSample(value As String)
		msb = New StringBuilder(value)

		msb.Insert(0, "PREFIXED: ")

		DisplayMessage(msb.ToString())
	End Sub

	Private Sub btnRemove_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnRemove.Click
		RemoveSample(txtSentence.Text)
	End Sub

	Private Sub RemoveSample(value As String)
		msb = New StringBuilder(value)
		msb.Remove(0, 10)

		DisplayMessage(msb.ToString())
	End Sub

	Private Sub btnReplace_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnReplace.Click
		ReplaceSample(txtSentence.Text)
	End Sub

	Private Sub ReplaceSample(value As String)
		msb = New StringBuilder(value)

		' Change some values
		msb.Replace(".", ".PERIOD.")
		msb.Replace("This ", "Changed ")

		DisplayMessage(msb.ToString())
	End Sub
End Class
