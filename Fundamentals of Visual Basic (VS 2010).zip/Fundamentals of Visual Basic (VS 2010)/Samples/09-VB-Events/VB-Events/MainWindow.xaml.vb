﻿Class MainWindow
  Private Sub Window_Loaded(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles MyBase.Loaded
    Me.WindowState = Windows.WindowState.Maximized
    DisplayMessage("Window_Loaded Event")
  End Sub

  Private Sub Window_Activated(sender As System.Object, e As System.EventArgs) Handles MyBase.Activated
    DisplayMessage("Window_Activated Event")
  End Sub

  Private Sub Window_SizeChanged(sender As System.Object, e As System.Windows.SizeChangedEventArgs) Handles MyBase.SizeChanged
    DisplayMessage("Window_SizeChanged Event")
  End Sub

  Private Sub Window_Closing(sender As System.Object, e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
    DisplayMessage("Window_Closing Event")
  End Sub

  Private Sub txtFirst_TextChanged(sender As System.Object, e As System.Windows.Controls.TextChangedEventArgs) Handles txtFirst.TextChanged
    DisplayMessage("txtFirst_TextChanged Event")
  End Sub

  Private Sub cboStates_SelectionChanged(sender As System.Object, e As System.Windows.Controls.SelectionChangedEventArgs) Handles cboStates.SelectionChanged
    DisplayMessage("cboStates_SelectionChanged Event: " + DirectCast(cboStates.SelectedItem, ComboBoxItem).Content.ToString())
  End Sub

  Private Sub rdoMale_Checked(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles rdoMale.Checked
    DisplayMessage("rdoMale_Checked Event")
  End Sub

  Private Sub rdoFemale_Checked(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles rdoFemale.Checked
    DisplayMessage("rdoFemale_Checked Event")
  End Sub

  Private Sub chkHealthCare_Checked(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles chkHealthCare.Checked
    DisplayMessage("chkHealthCare_Checked Event")
  End Sub

  Private Sub chk401k_Checked(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles chk401k.Checked
    DisplayMessage("chk401k_Checked Event")
  End Sub

  Private Sub chkBonus_Checked(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles chkBonus.Checked
    DisplayMessage("chkBonus_Checked Event")
  End Sub

  Private Sub chkHealthCare_Unchecked(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles chkHealthCare.Unchecked
    DisplayMessage("chkHealthCare_Unchecked Event")
  End Sub

  Private Sub chk401k_Unchecked(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles chk401k.Unchecked
    DisplayMessage("chk401k_Unchecked Event")
  End Sub

  Private Sub chkBonus_Unchecked(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles chkBonus.Unchecked
    DisplayMessage("chkBonus_Unchecked Event")
  End Sub

  Private Sub tabEmployee_SelectionChanged(sender As System.Object, e As System.Windows.Controls.SelectionChangedEventArgs) Handles tabEmployee.SelectionChanged
    DisplayMessage("tabEmployee_SelectionChanged Event")
    If tabGeneral.IsSelected Then
      DisplayMessage("General Tab Item Selected")
    ElseIf tabOther.IsSelected Then
      DisplayMessage("Other Tab Item Selected")
    End If
  End Sub

  Private Sub DisplayMessage(msg As String)
    Debug.WriteLine(msg)
  End Sub
End Class