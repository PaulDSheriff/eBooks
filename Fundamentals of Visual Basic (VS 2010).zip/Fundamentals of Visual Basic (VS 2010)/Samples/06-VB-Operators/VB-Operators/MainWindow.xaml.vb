﻿Class MainWindow 

  Private Sub btnAddition_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnAddition.Click
    AdditionSample()
  End Sub

  Private Sub AdditionSample()
    Dim value1 As Integer = 2
    Dim value2 As Integer = 2

    tbAddition.Text = Convert.ToString(value1 + value2)
  End Sub

  Private Sub btnSubtraction_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnSubtraction.Click
    SubtractionSample()
  End Sub

  Private Sub SubtractionSample()
    Dim value1 As Integer = 2
    Dim value2 As Integer = 2

    tbSubtraction.Text = Convert.ToString(value1 - value2)
  End Sub

  Private Sub btnMultiplication_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnMultiplication.Click
    MultiplicationSample()
  End Sub

  Private Sub MultiplicationSample()
    Dim value1 As Integer = 2
    Dim value2 As Integer = 2

    tbMultiplication.Text = Convert.ToString(value1 * value2)
  End Sub

  Private Sub btnDivision_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnDivision.Click
    DivisionSample()
  End Sub

  Private Sub DivisionSample()
    Dim value1 As Integer = 10
    Dim value2 As Integer = 2

    tbDivision.Text = Convert.ToString(value1 / value2)
  End Sub

  Private Sub btnIntegerDivision_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnIntegerDivision.Click
    IntegerDivisionSample()
  End Sub

  Private Sub IntegerDivisionSample()
    Dim value1 As Integer = 9
    Dim value2 As Integer = 2

    tbIntegerDivision.Text = Convert.ToString(value1 \ value2)
  End Sub

  Private Sub btnModulus_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnModulus.Click
    ModulusSample()
  End Sub

  Private Sub ModulusSample()
    Dim value1 As Integer = 9
    Dim value2 As Integer = 2

    tbModulus.Text = Convert.ToString(value1 Mod value2)
  End Sub

  Private Sub btnExponentiation_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnExponentiation.Click
    ExponentiationSample()
  End Sub

  Private Sub ExponentiationSample()
    Dim value1 As Integer = 2
    Dim value2 As Integer = 4

    tbExponentiation.Text = Convert.ToString(value1 ^ value2)
  End Sub
End Class
