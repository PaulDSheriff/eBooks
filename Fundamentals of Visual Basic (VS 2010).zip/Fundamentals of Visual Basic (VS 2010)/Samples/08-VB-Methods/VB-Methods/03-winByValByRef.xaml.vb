﻿Public Class winByValByRef

  Private Sub btnByVal_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnByVal.Click
    ByValExample()
  End Sub

  Private Sub ByValExample()
    Dim ret As Integer
    Dim value As String

    ret = 10
    value = "Bill"

    ByValProcedure(ret, value)

    Debug.WriteLine("ret = " & ret.ToString())
    Debug.WriteLine("value = " & value.ToString())
  End Sub

  Private Sub ByValProcedure(ByVal arg1 As Integer, ByVal arg2 As String)
    arg1 = 20
    arg2 = "Gates"
  End Sub

  Private Sub btnByRef_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnByRef.Click
    ByRefExample()
  End Sub

  Private Sub ByRefExample()
    Dim ret As Integer
    Dim value As String

    ret = 10
    value = "Bill"

    ByRefProcedure(ret, value)

    Debug.WriteLine("ret = " & ret.ToString())
    Debug.WriteLine("value = " & value.ToString())
  End Sub

  Private Sub ByRefProcedure(ByRef arg1 As Integer, ByRef arg2 As String)
    arg1 = 20
    arg2 = "Gates"
  End Sub
End Class
