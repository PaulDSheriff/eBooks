﻿Public Class winMethods

  Private Sub btnString_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnString.Click
    StringMethods()
  End Sub

  Private Sub StringMethods()
    Dim value As String

    value = "Bill"

    Debug.WriteLine(value.Length)
    Debug.WriteLine(value.IndexOf("i"))
    Debug.WriteLine(value.LastIndexOf("l"))
    Debug.WriteLine(value.EndsWith("g"))
    Debug.WriteLine(value.Insert(4, " Gates"))
    value = value.Insert(4, " Gates")
    Debug.WriteLine(value.Remove(4, 5))
    Debug.WriteLine(value.PadLeft(10))
    Debug.WriteLine(value.PadRight(10))
    Debug.WriteLine(value.Replace("i", "TT"))
    Debug.WriteLine(value.Replace("TT", "i"))
    Debug.WriteLine(value.Substring(2, 2))
    Debug.WriteLine(value.ToLower())
    Debug.WriteLine(value.ToUpper())
    Debug.WriteLine(value.Trim())
  End Sub

  Private Sub btnNumeric_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnNumeric.Click
    NumericMethods()
  End Sub

  Private Sub NumericMethods()
    Dim value As Integer

    value = 10

    Debug.WriteLine(Integer.MaxValue)
    Debug.WriteLine(Integer.MinValue)
    Debug.WriteLine(value.ToString())
  End Sub

  Private Sub btnDate_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnDate.Click
    DateMethods()
  End Sub

  Private Sub DateMethods()
    Dim value As Date

		value = #1/1/2011 12:00:00 PM#

    Debug.WriteLine(value.AddDays(10))
    Debug.WriteLine(value.AddYears(2))
    Debug.WriteLine(value.AddMinutes(10))
    Debug.WriteLine(value.Date)
    Debug.WriteLine(value.Day)
    Debug.WriteLine(value.DayOfWeek)
    Debug.WriteLine(value.DayOfYear)
    Debug.WriteLine(value.Hour)
    Debug.WriteLine(value.Minute)
    Debug.WriteLine(value.Month)
    Debug.WriteLine(value.Year)
    Debug.WriteLine(value.ToString())
    If IsDate(value) Then
      MessageBox.Show("Valid Date")
    Else
      MessageBox.Show("Invalid Date")
    End If
  End Sub
End Class
