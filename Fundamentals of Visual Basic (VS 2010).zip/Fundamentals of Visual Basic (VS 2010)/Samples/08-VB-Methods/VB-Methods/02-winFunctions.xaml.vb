﻿Public Class winFunctions

	Private Sub btnDisplay_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnDisplay.Click
		EmployeeDisplay()
	End Sub

	Private Sub EmployeeDisplay()
		Dim name As String

		name = EmployeeName("Bill", "Gates")
		MessageBox.Show(name)

		MessageBox.Show(EmployeeName(txtFirst.Text, _
		 txtLast.Text))
	End Sub

	Public Function EmployeeName( _
	 ByVal firstName As String, _
	 ByVal lastName As String) As String
		Dim ret As String

		ret = "My Last Name is " & lastName
		ret &= " and my first name is " & firstName

		Return ret
	End Function
End Class
