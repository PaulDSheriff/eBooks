﻿Public Class winProcedures

  Private Sub btnDisplay_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnDisplay.Click
    EmployeeName(txtFirst.Text, txtLast.Text)
  End Sub

  Public Sub EmployeeName(ByVal firstName As String, _
   ByVal lastName As String)
    Dim empName As String

    empName = "My Last Name is " & lastName
    empName &= " and my First Name is " & firstName

    MessageBox.Show(empName)
  End Sub
End Class
