﻿Class MainWindow 

  Private Sub btnProcedures_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnProcedures.Click
    Dim win As New winProcedures

    win.Show()
  End Sub

  Private Sub btnFunctions_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnFunctions.Click
    Dim win As New winFunctions

    win.Show()
  End Sub

  Private Sub btnByValRef_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnByValRef.Click
    Dim win As New winByValByRef

    win.Show()
  End Sub

  Private Sub btnMethods_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnMethods.Click
    Dim win As New winMethods

    win.Show()
  End Sub
End Class
