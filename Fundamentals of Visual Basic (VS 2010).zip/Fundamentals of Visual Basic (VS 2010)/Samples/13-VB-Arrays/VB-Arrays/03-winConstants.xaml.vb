﻿Public Class winConstants
  Private Const SECRET_VALUE As Integer = 42

  Private Sub btnLocal_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnLocal.Click
    LocalConstants()
  End Sub

  Private Sub LocalConstants()
    Dim sales(2, 2) As Decimal
    Const MONTH As Integer = 0
    Const AMOUNT As Integer = 1

    sales(0, MONTH) = 1
    sales(0, AMOUNT) = 50000

    sales(1, MONTH) = 2
    sales(1, AMOUNT) = 55000

    sales(2, MONTH) = 3
    sales(2, AMOUNT) = 60000

    Debug.WriteLine( _
     String.Format("January Sales: {0}", sales(0, AMOUNT)))

    Debug.WriteLine( _
     String.Format("February Sales: {0}", sales(1, AMOUNT)))
  End Sub

  Private Sub btnMember_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnMember.Click
    MessageBox.Show("The Secret Value is: " + SECRET_VALUE.ToString())
  End Sub
End Class
