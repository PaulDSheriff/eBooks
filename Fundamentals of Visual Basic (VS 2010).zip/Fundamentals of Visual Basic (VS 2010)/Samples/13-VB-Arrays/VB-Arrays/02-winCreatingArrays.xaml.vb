﻿Public Class winCreatingArrays

	Private Sub btnFixedSize_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnFixedSize.Click
		FixedArray()
	End Sub

	Private Sub FixedArray()
		Dim names(2) As String

		names(0) = "Ken"
		names(1) = "Paul"
		names(2) = "Michael"

		For Each name As String In names
			Debug.WriteLine(name)
		Next
	End Sub

	Private Sub btnDynamic_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnDynamic.Click
		DynamicArrays()
	End Sub

	Private Sub DynamicArrays()
		Dim values As Integer()

		' Dynamically create 3 elements

		values = New Integer(2) {}

		values(0) = 10
		values(1) = 20
		values(2) = 30

		For Each value As Integer In values
			Debug.WriteLine( _
			 String.Format("value={0}", value))
		Next
	End Sub
	Private Sub btnInitializing_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnInitializing.Click
		InitArray()
	End Sub

	Private Sub InitArray()
		Dim values As Integer() = {10, 20, 30, 40}

		For Each value As Integer In values
			Debug.WriteLine( _
			 String.Format("value={0}", value))
		Next
	End Sub


	Private Sub btnReferences_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnReferences.Click
		ArrayRef()
	End Sub

	Private Sub ArrayRef()
		Dim values As Integer() = New Integer(2) {}
		Dim newValues As Integer()

		values(0) = 10
		values(1) = 20
		values(2) = 30

		newValues = values

		newValues(0) = 50

		For Each value As Integer In values
			Debug.WriteLine( _
			 String.Format("value={0}", value))
		Next

		For Each value As Integer In newValues
			Debug.WriteLine(String.Format("value={0}", value))
		Next
	End Sub


	Private Sub btnCopying_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnCopying.Click
		CopyArray()
	End Sub

	Private Sub CopyArray()
		Dim values As Integer() = New Integer(2) {}
		Dim newValues As Integer()

		values(0) = 10
		values(1) = 20
		values(2) = 30

		ReDim newValues(values.Length - 1)

		Array.Copy(values, newvalues, values.Length - 1)

		newValues(0) = 50

		For Each value As Integer In values
			Debug.WriteLine( _
			 String.Format("values={0}", value))
		Next

		For Each value As Integer In newValues
			Debug.WriteLine(String.Format("new value={0}", value))
		Next
	End Sub


	Private Sub btnCloning_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnCloning.Click
		CloneArray()
	End Sub

	Private Sub CloneArray()
		Dim values As Integer() = New Integer(2) {}
		Dim newValues As Integer()

		values(0) = 10
		values(1) = 20
		values(2) = 30

		' Need to DirectCast because Clone returns an object array
		newValues = DirectCast(values.Clone(), Integer())

		newValues(0) = 50

		For Each value As Integer In values
			Debug.WriteLine( _
			 String.Format("values={0}", value))
		Next

		For Each value As Integer In newValues
			Debug.WriteLine( _
			 String.Format("new value={0}", value))
		Next

	End Sub


	Private Sub btnPassing_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnPassing.Click
		ArrayPassExample()
	End Sub

	Private Sub ArrayPassExample()
		Dim names(2) As String

		names(0) = "Ken"
		names(1) = "Paul"
		names(2) = "Michael"

		ArrayWrite(names, "names")
	End Sub


	Private Sub ArrayWrite(ByVal values() As Object, _
	 ByVal arrayName As String)
		Dim index As Integer

		For index = 0 To values.Length - 1
			Debug.WriteLine(String.Format("{0}({1})={2}", arrayName, index, values(index)))
		Next
	End Sub

	Private Sub btnSorting_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnSorting.Click
		SortExample()
	End Sub

	Private Sub SortExample()
		Dim names As String() = New String(2) {}

		names(0) = "Ken"
		names(1) = "Paul"
		names(2) = "Michael"

		Array.Sort(names)

		ArrayWrite(names, "names")
	End Sub

	Private Sub btnSearching_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnSearching.Click
		SearchExample()
	End Sub

	Private Sub SearchExample()
		Dim names As String() = New String(2) {}
		Dim index As Integer

		names(0) = "Ken"
		names(1) = "Paul"
		names(2) = "Michael"

		index = Array.IndexOf(names, "Paul")

		MessageBox.Show("Found at position: " & index.ToString())
	End Sub

	Private Sub btnMultiDimensional_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnMultiDimensional.Click
		MultiDimArray()
	End Sub

	Private Sub MultiDimArray()
		Dim sales(2, 2) As Decimal

		sales(0, 0) = 1
		sales(0, 1) = 50000

		sales(1, 0) = 2
		sales(1, 1) = 55000

		sales(2, 0) = 3
		sales(2, 1) = 60000

		Debug.WriteLine( _
		 String.Format("January Sales: {0}", sales(0, 1)))

		Debug.WriteLine( _
		 String.Format("February Sales: {0}", sales(1, 1)))
	End Sub
End Class
