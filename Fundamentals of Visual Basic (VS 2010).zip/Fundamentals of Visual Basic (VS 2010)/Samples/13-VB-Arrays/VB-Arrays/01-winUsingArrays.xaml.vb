﻿Public Class winUsingArrays
  Private Sub Window_Loaded(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles MyBase.Loaded
    txtLines.Text = "This is line 1" & Environment.NewLine
    txtLines.Text &= "This is line 2" & Environment.NewLine
    txtLines.Text &= "This is line 3" & Environment.NewLine
    txtLines.Text &= "This is line 4" & Environment.NewLine
  End Sub

  Private Sub btnStringToArray_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnStringToArray.Click
    StringToArray()
  End Sub

  Private Sub StringToArray()
    Dim values() As String
    Dim names As String
        Dim index As Integer = 0

    names = "Ken,Michael,Bruce,Paul"

    values = names.Split(",".ToCharArray())

    For index = 0 To values.Length - 1
      Debug.WriteLine(values(index))
    Next
  End Sub

  Private Sub btnFiles_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnFiles.Click
    GetFiles()
  End Sub

  Private Sub GetFiles()
    Dim files() As String


    files = System.IO.Directory.GetFiles("D:\")

        For Each name As String In files
            Debug.WriteLine(name)
        Next
  End Sub

  Private Sub btnFolders_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnFolders.Click
    GetFolders()
  End Sub

  Private Sub GetFolders()
    Dim folders() As String


    folders = System.IO.Directory.GetDirectories("D:\")

        For Each name As String In folders
            Debug.WriteLine(name)
        Next
  End Sub

  Private Sub btnLinesInTextBox_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnLinesInTextBox.Click
    LinesInTextBox()
  End Sub

  Private Sub LinesInTextBox()
    Dim lines() As String

    ' Create Array to size of lines
    ReDim lines(txtLines.LineCount)

    For index As Integer = 0 To txtLines.LineCount - 1
      lines(index) = txtLines.GetLineText(index)
    Next

    ' Display Each Line
        For Each line As String In lines
            Debug.Write(line)
        Next
  End Sub
End Class
