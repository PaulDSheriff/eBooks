﻿Class MainWindow 
	Private Sub btnUsingArrays_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnUsingArrays.Click
		Dim win As New winUsingArrays

		win.Show()
	End Sub

  Private Sub btnCreatingArrays_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnCreatingArrays.Click
    Dim win As New winCreatingArrays

		win.Show()
  End Sub

  Private Sub btnConstants_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnConstants.Click
    Dim win As New winConstants

    win.Show()
  End Sub
End Class
