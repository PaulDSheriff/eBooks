﻿Public Class winWithEndWith

  Private Sub btnWith1_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnWith1.Click
    With Me
      .Title = "A New Form Title"
      .WindowState = Windows.WindowState.Maximized
    End With
  End Sub

  Private Sub btnWith2_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnWith2.Click
    Dim emp As New Employee

    With emp
			.FirstName = "Bruce"
			.LastName = "Jones"
    End With
  End Sub
End Class
