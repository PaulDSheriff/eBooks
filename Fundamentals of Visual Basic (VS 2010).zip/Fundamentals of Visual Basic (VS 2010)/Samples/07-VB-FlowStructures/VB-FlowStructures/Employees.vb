﻿Imports System.Collections.Generic

Public Class Employees
  Inherits List(Of Employee)

End Class
