﻿Public Class winDecision

  Private Sub DisplayMessage(msg As String)
    tbMessage.Text = msg
  End Sub

  Private Sub btnSingleLineIf_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnSingleLineIf.Click
    SingeLineIf()
  End Sub

  Private Sub SingeLineIf()
    If txtLastName.Text = "" Then DisplayMessage("Last Name Must Be Filled in")
  End Sub

  Private Sub btnNormalIf_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnNormalIf.Click
    NormalIf()
  End Sub

  Private Sub NormalIf()
    If txtLastName.Text = "" Then
      DisplayMessage("Last Name Must Be Filled in")
    End If
  End Sub

  Private Sub btnElse_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnElse.Click
    ElseIfSample()
  End Sub

  Private Sub ElseIfSample()
    If txtLastName.Text = "" Then
      DisplayMessage("Last Name Must Be Filled in")
    Else
      DisplayMessage("Thank you for a Last Name")
    End If
  End Sub

  Private Sub btnElseIf_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnElseIf.Click
    ElseIfElse()
  End Sub

  Private Sub ElseIfElse()
    If txtLastName.Text = "Sheriff" Then
      DisplayMessage("Hello Paul")
    ElseIf txtLastName.Text = "Getz" Then
      DisplayMessage("Hello Ken")
    ElseIf txtLastName.Text = "Gates" Then
      DisplayMessage("Hello Bill")
    End If
  End Sub

  Private Sub btnIIF_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnIIF.Click
    IIfSample()
  End Sub

  Private Sub IIfSample()
    DisplayMessage(Convert.ToString( _
     IIf(txtLastName.Text = "Gates", "Hello Bill", "Hello Whoever")))
  End Sub

  Private Sub btnSelectCase_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnSelectCase.Click
    SelectCaseSample()
  End Sub

  Private Sub SelectCaseSample()
    Select Case txtLastName.Text
      Case "Sheriff"
        DisplayMessage("Hello Paul")
      Case "Getz"
        DisplayMessage("Hello Ken")
      Case "Gates"
        DisplayMessage("Hello Bill")
      Case Else
        DisplayMessage("Hello Whoever")
    End Select
  End Sub

  Private Sub btnSelectCaseComma_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnSelectCaseComma.Click
    SelectCaseCommaSample()
  End Sub

  Private Sub SelectCaseCommaSample()
    Select Case txtLastName.Text
      Case "Sheriff", "Getz", "Gates"
        DisplayMessage("Hello " & txtLastName.Text)
      Case Else
        DisplayMessage("Hello Whoever")
    End Select
  End Sub

  Private Sub btnSelectCaseTo_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnSelectCaseTo.Click
    SelectCaseToSample()
  End Sub

  Private Sub SelectCaseToSample()
    Dim decValue As Decimal

    decValue = 51000

    Select Case decValue
      Case 40000 To 50000
        DisplayMessage("Good Salary")
      Case 50001 To 70000
        DisplayMessage("Better Salary")
      Case 70001 To 120000
        DisplayMessage("Great Salary")
    End Select
  End Sub

  Private Sub btnConditionalCompile_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnConditionalCompile.Click
    ConditionalCompile()
  End Sub

  Private Sub ConditionalCompile()
#If DEBUG Then
    DisplayMessage("We have compiled to Debug mode")
#Else
    DisplayMessage("We have compiled to Release mode")
#End If
  End Sub

  ' Declare a conditional constant
#Const conLanguage = 1

  Private Sub btnLanguage_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnLanguage.Click
    LanguageExample()
  End Sub

  Private Sub LanguageExample()
#If conLanguage = 1 Then
    DisplayMessage("Good Morning, Mr. Gates")
#Else
    DisplayMessage("Guten Morgen, Herr Gates")
#End If
  End Sub
End Class
