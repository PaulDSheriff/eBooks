﻿Public Class winForNext

  Private Sub btnForNext_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnForNext.Click
    ForNext()
  End Sub

  Private Sub ForNext()
    Dim intLoop As Integer

    For intLoop = 0 To 10
      Debug.WriteLine(intLoop)
    Next
  End Sub

  Private Sub btnForNextStep_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnForNextStep.Click
    ForNextStep()
  End Sub

  Private Sub ForNextStep()
    Dim intLoop As Integer

    For intLoop = 0 To 20 Step 2
      Debug.WriteLine(intLoop)
    Next
  End Sub

  Private Sub btnForNextStepMinus_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnForNextStepMinus.Click
    ForNextStepMinus()
  End Sub

  Private Sub ForNextStepMinus()
    Dim intLoop As Integer

    For intLoop = 50 To 0 Step -5
      Debug.WriteLine(intLoop)
    Next
  End Sub

  Private Sub btnForEach_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnForEach.Click
    ForEach()
  End Sub

  Private Sub ForEach()
    Dim list As New Employees
    Dim emp As Employee

    emp = New Employee()
    emp.FirstName = "Paul"
    emp.LastName = "Sheriff"

    list.Add(emp)

    emp = New Employee()
    emp.FirstName = "Ken"
    emp.LastName = "Getz"

    list.Add(emp)

    emp = New Employee()
    emp.FirstName = "Bill"
    emp.LastName = "Gates"

    list.Add(emp)

    For Each item As Employee In list
      Debug.WriteLine(item.FirstName)
    Next
  End Sub
End Class
