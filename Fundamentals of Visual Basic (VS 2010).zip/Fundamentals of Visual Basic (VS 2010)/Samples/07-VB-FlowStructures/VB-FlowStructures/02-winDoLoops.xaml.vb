﻿Public Class winDoLoops

  Private Sub btnDoWhile_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnDoWhile.Click
    DoWhile()
  End Sub

  Private Sub DoWhile()
    Dim index As Integer

    Do While index < 10
      index += 1

      Debug.WriteLine(index)
    Loop
  End Sub

  Private Sub btnLoopWhile_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnLoopWhile.Click
    LoopWhile()
  End Sub

  Private Sub LoopWhile()
    Dim index As Integer

    Do
      index += 1

      Debug.WriteLine(index)
    Loop While index < 10
  End Sub

  Private Sub btnDoUntil_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnDoUntil.Click
    DoUntil()
  End Sub

  Private Sub DoUntil()
    Dim index As Integer

    Do Until index > 10
      index += 1
      Debug.WriteLine(index)
    Loop
  End Sub

  Private Sub btnLoopUntil_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnLoopUntil.Click
    LoopUntil()
  End Sub

  Private Sub LoopUntil()
    Dim index As Integer

    Do
      index += 1
      Debug.WriteLine(index)
    Loop Until index > 10
  End Sub
End Class
