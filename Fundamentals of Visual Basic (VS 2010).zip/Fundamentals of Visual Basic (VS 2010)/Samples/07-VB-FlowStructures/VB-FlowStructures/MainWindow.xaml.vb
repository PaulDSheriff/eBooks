﻿Class MainWindow 

  Private Sub btnDecision_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnDecision.Click
    Dim win As New winDecision

    win.Show()
  End Sub

  Private Sub btnDoLoops_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnDoLoops.Click
    Dim win As New winDoLoops

    win.Show()
  End Sub

  Private Sub btnForNext_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnForNext.Click
    Dim win As New winForNext

    win.Show()
  End Sub

  Private Sub btnWithEndWith_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnWithEndWith.Click
    Dim win As New winWithEndWith

    win.Show()
  End Sub
End Class
