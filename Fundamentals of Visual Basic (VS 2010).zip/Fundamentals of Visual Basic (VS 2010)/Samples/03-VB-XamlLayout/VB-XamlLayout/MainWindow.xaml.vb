﻿Class MainWindow 
  Private Sub btnGridMargins_Click(sender As Object, e As RoutedEventArgs)
    Dim win As New GridUsingMargins()

    win.Show()
  End Sub

  Private Sub btnGridRowsColumns_Click(sender As Object, e As RoutedEventArgs)
    Dim win As New GridUsingRowsColumns()

    win.Show()
  End Sub

  Private Sub btnCanvas_Click(sender As Object, e As RoutedEventArgs)
    Dim win As New UsingCanvas()

    win.Show()
  End Sub

  Private Sub btnStackPanel_Click(sender As Object, e As RoutedEventArgs)
    Dim win As New UsingStackPanel()

    win.Show()
  End Sub
End Class
