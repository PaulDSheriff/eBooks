﻿Public Class Employee
  Private mFullName As String
  Private mFirstName As String
  Private mLastName As String

  Private Sub CreateFullName()
    mFullName = mFirstName + " " + mLastName
  End Sub
End Class
