﻿Option Strict Off

Class MainWindow
  Private mName As String = "Paul"

  Private Sub btnDeclarations_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnDeclarations.Click
    VariableDeclaration()
  End Sub

  Public Sub VariableDeclaration()
    Dim IsValueOk As Boolean
    Dim aChar As Char
    Dim MyByte As Byte
    Dim BeginDate As Date
    Dim StartTime As Date
    Dim index As Short
    Dim pk As Integer
    Dim pkLong As Long
    Dim quantity As Single
    Dim amount As Double
    Dim price As Decimal
    Dim name As String

    aChar = Convert.ToChar("A")
    IsValueOk = True
    MyByte = 1
    BeginDate = #9/1/1998#
    StartTime = #10:10:00 AM#
    index = 10
    pk = 100000
    pkLong = 29393838383
    quantity = 2.5
    amount = 3.2233
    price = Convert.ToDecimal(500.65)
    name = "Paul"
  End Sub

  Private Sub btnProcedureScope_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnProcedureScope.Click
    ProcedureScope()
  End Sub

  Private Sub ProcedureScope()
    Dim index As Integer

    For index = 0 To 10
      Debug.WriteLine(index)
    Next

    ' You can still see intLoop
    Debug.WriteLine(index)
  End Sub

  Private Sub btnBlockScope_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnBlockScope.Click
    BlockScope()
  End Sub

  Private Sub BlockScope()
    If True Then
      Dim index As Integer

      For index = 0 To 10
        Debug.WriteLine(index)
      Next
    End If

    ' index is not visible, the following will not compile
    ' Debug.WriteLine(index)
  End Sub

  Private Sub btnMemberScope_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnMemberScope.Click
    MemberExample()
  End Sub

  Private Sub MemberExample()
    Debug.WriteLine(mName)

    mName = "John"

    Debug.WriteLine(mName)
  End Sub

  Private Sub btnStatic_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnStatic.Click
    StaticExample()
  End Sub

  Private Sub StaticExample()
    Static statValue As Integer

    statValue += 1

    Debug.WriteLine(statValue.ToString())
  End Sub

  Private Sub btnObject_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnObject.Click
    ObjectExample()
    ObjectProblem()
  End Sub

  Private Sub ObjectExample()
    Dim value As Object

    value = 10

    Debug.WriteLine(value)

    value = "Hi There"
    Debug.WriteLine(value)
  End Sub

  Private Sub ObjectProblem()
    Dim o1 As Object
    Dim o2 As Object

    o1 = "1"
    o2 = 2

    ' This only works with 'Option Strict Off' set at the top of this file
    ' By default Option Strict should be 'On'
    Debug.WriteLine(o1 + o2)

    o1 = "1"
    o2 = "2"

    Debug.WriteLine(o1 + o2)
  End Sub
End Class
