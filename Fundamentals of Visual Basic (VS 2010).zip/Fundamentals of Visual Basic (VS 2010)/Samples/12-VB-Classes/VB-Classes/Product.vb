﻿Public Class Product
	Public Property ProductId As Integer
	Public Property ProductName As String
	Public Property ProductType As String
	Public Property Price As Decimal
	Public Property Image As String
	Public Property IsOnSpecial As Boolean
End Class
