﻿Imports System.Globalization

Public Class DateThings
	Public Sub New()
		TheDate = DateTime.Now
	End Sub

	Public Sub New(dt As Date)
		TheDate = dt
	End Sub

	Private mTheDate As Date

	Public Property TheDate() As Date
		Get
			Return mTheDate
		End Get
		Set(ByVal value As Date)
			mTheDate = value
		End Set
	End Property

	Public ReadOnly Property MonthName() As String
		Get
			Dim info As New DateTimeFormatInfo()
			Dim months As String() = Nothing

			months = info.MonthNames

			Return months(mTheDate.Month - 1)
		End Get
	End Property

	Public Function SqlFormatted() As String
		Return TheDate.ToString("yyyy-MM-dd HH:mm:ss")
	End Function

	Public Function MonthStart() As DateTime
		Dim ret As DateTime

		ret = New DateTime(TheDate.Year, TheDate.Month, 1, _
		 TheDate.Hour, TheDate.Minute, TheDate.Second, _
		 TheDate.Millisecond, CultureInfo.CurrentCulture.Calendar)

		Return ret
	End Function

	Public Function MonthEnd() As DateTime
		Dim lastDay As Integer = 0
		Dim ret As DateTime

		lastDay = DateTime.DaysInMonth(TheDate.Year, TheDate.Month)

		ret = New DateTime(TheDate.Year, TheDate.Month, lastDay, _
		 TheDate.Hour, TheDate.Minute, TheDate.Second, _
		 TheDate.Millisecond, CultureInfo.CurrentCulture.Calendar)


		Return ret
	End Function

	Public Function YearStart() As DateTime
		Dim dt As DateTime

		dt = New DateTime(TheDate.Year, 1, 1, TheDate.Hour, _
		 TheDate.Minute, TheDate.Second, _
		 TheDate.Millisecond, CultureInfo.CurrentCulture.Calendar)

		Return dt
	End Function

	Public Function YearEnd() As DateTime
		Dim ret As DateTime

		ret = New DateTime(TheDate.Year, 12, 31, TheDate.Hour, _
		 TheDate.Minute, TheDate.Second, _
		 TheDate.Millisecond, CultureInfo.CurrentCulture.Calendar)

		Return ret
	End Function
End Class