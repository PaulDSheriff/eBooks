﻿Class MainWindow 
	Private Sub btnDateThings_Click(sender As Object, e As RoutedEventArgs)
		Dim win As New winDate()

		win.Show()
	End Sub

	Private Sub btnLinq_Click(sender As Object, e As RoutedEventArgs)
		Dim win As New winLinq()

		win.Show()
	End Sub

	Private Sub btnLinqToXml_Click(sender As Object, e As RoutedEventArgs)
		Dim win As New winXml()

		win.Show()
	End Sub

	Private Sub btnCollections_Click(sender As Object, e As RoutedEventArgs)
		Dim win As New winCollections()

		win.Show()
	End Sub
End Class
