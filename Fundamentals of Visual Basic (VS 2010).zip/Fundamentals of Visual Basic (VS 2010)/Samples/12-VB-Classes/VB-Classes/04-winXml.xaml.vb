﻿Public Class winXml
#Region "GetCurrentDirectory Method"
	''' <summary>
	''' Returns the current directory the program is running in. If running in Visual Studio, this method removes the \bin folder. NO ending slash is applied to the end of this directory path.
	''' </summary>
	''' <returns>The current directory.</returns>
	Public Shared Function GetCurrentDirectory() As String
		Dim ret As String = Nothing

		ret = AppDomain.CurrentDomain.BaseDirectory
		If ret.IndexOf("\bin") > 0 Then
			ret = ret.Substring(0, ret.LastIndexOf("\bin"))
		End If
		If ret.EndsWith("\") Then
			ret = ret.Substring(0, ret.Length - 1)
		End If

		Return ret
	End Function
#End Region

	Private Sub btnReadAll_Click(sender As Object, e As RoutedEventArgs)
		ReadAll()
	End Sub

	Private Sub ReadAll()
		Dim xdoc As XDocument

		xdoc = XDocument.Load(GetCurrentDirectory() & "\Xml\Product.xml")

		txtXML.Text = String.Empty
		txtXML.Text = xdoc.ToString()
	End Sub

	Private Sub btnReadOneRow_Click(sender As Object, e As RoutedEventArgs)
		GetOneRow()
	End Sub

	Private Sub GetOneRow()
		Dim xelem As XElement

		xelem = XElement.Load(GetCurrentDirectory() & "\Xml\Product.xml")

		Dim prod = (From p In xelem.Descendants("Product") _
					Where p.Element("ProductId").Value = "1" _
					Select p).Single()

		If prod IsNot Nothing Then
			txtXML.Text = String.Empty
			txtXML.Text = prod.Element("ProductName").Value
		End If
	End Sub

	Private Sub btnReadOneRowAttrib_Click(sender As Object, e As RoutedEventArgs)
		GetOneRowAttribute()
	End Sub

	Private Sub GetOneRowAttribute()
		Dim xelem As XElement

		xelem = XElement.Load(GetCurrentDirectory() & "\Xml\ProductAttributes.xml")

		Dim prod = (From p In xelem.Elements("Product") _
			 Where p.Attribute("ProductId").Value = "2" _
			 Select p).Single()

		If prod IsNot Nothing Then
			txtXML.Text = String.Empty
			txtXML.Text = prod.Attribute("ProductName").Value
		End If
	End Sub

	Private Sub btnLoadClass_Click(sender As Object, e As RoutedEventArgs)
		LoadAClass()
	End Sub

	Private Sub LoadAClass()
		Dim xelem As XElement

		xelem = XElement.Load(GetCurrentDirectory() & "\Xml\Product.xml")

		Dim items = From prod In xelem.Descendants("Product") _
					Select New Product() With { _
		 .ProductId = Convert.ToInt32(prod.Element("ProductId").Value), _
		 .ProductName = prod.Element("ProductName").Value, _
		 .ProductType = prod.Element("ProductType").Value, _
		 .Price = Convert.ToDecimal(prod.Element("Price").Value), _
		 .Image = prod.Element("Image").Value, _
		 .IsOnSpecial = Convert.ToBoolean(prod.Element("IsOnSpecial").Value) _
		}

		txtXML.Text = String.Empty
		For Each item As Product In items
			txtXML.AppendText(item.ProductName + Environment.NewLine)
		Next
	End Sub

	Private Sub btnAggregates_Click(sender As Object, e As RoutedEventArgs)
		Aggregates()
	End Sub

	Private Sub Aggregates()
		Dim xelem As XElement

		xelem = XElement.Load(GetCurrentDirectory() & "\Xml\Product.xml")

		Dim maxPrice = (From mnu In xelem.Descendants("Product") Select Convert.ToDecimal(mnu.Element("Price").Value)).Max()

		Dim minPrice = (From mnu In xelem.Descendants("Product") Select Convert.ToDecimal(mnu.Element("Price").Value)).Min()

		Dim sumPrice = (From mnu In xelem.Descendants("Product") Select Convert.ToDecimal(mnu.Element("Price").Value)).Sum()

		txtXML.Text = String.Empty
		txtXML.AppendText(("Max Price: " & maxPrice.ToString("c")) + Environment.NewLine)
		txtXML.AppendText(("Min Price: " & minPrice.ToString("c")) + Environment.NewLine)
		txtXML.AppendText(("Sum Price: " & sumPrice.ToString("c")) + Environment.NewLine)
	End Sub
End Class
