﻿Imports System.Collections.Specialized

Public Class winCollections
  Private Sub btnArrayList_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnArrayList.Click
    ArrayListSample()
  End Sub

  Private Sub ArrayListSample()
    Dim al As New ArrayList

    al.Add("A String")
    al.Add(42)
    al.Add(#1/1/2011#)

    For Each value As Object In al
      Debug.WriteLine(value)
    Next
  End Sub

  Private Sub btnNameValueCollection_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnNameValueCollection.Click
    NameValueCollectionSample()
  End Sub

  Private Sub NameValueCollectionSample()
    Dim nv As New NameValueCollection

    nv.Add("string", "A String")
    nv.Add("number", 42.ToString())
    nv.Add("date", #1/1/2011#.ToString())

    For Each key As String In nv.Keys
      Debug.Write("Key: " + key)
      Debug.WriteLine("  Value: " + nv.Item(key))
    Next
  End Sub

  Private Sub btnList1_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnList1.Click
    GenericListSample1()
  End Sub

  Private Sub GenericListSample1()
    Dim list As New List(Of String)

    list.Add("String 1")
    list.Add("String 2")
    list.Add("String 3")
    list.Add("String 4")

    ' The following will not work
    'list.Add(42)

    For Each value As String In list
      Debug.WriteLine(value)
    Next
  End Sub

  Private Sub btnList2_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnList2.Click
    GenericListSample2()
  End Sub

  Private Sub GenericListSample2()
    Dim emps As New Employees
    Dim emp As Employee

    emp = New Employee()
    emp.FirstName = "Paul"
    emp.LastName = "Sheriff"

    emps.Add(emp)

    emp = New Employee()
    emp.FirstName = "Ken"
    emp.LastName = "Getz"

    emps.Add(emp)

    emp = New Employee()
    emp.FirstName = "Bill"
    emp.LastName = "Gates"

    emps.Add(emp)

    ' The following will not work
    'emps.Add(42)

    For Each item As Employee In emps
      Debug.WriteLine(item.FirstName)
    Next
  End Sub
End Class
