﻿Class MainWindow 

	Private Sub btnLogin_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnLogin.Click
		Dim win As New winLogin()

		win.Owner = Me
		win.ShowDialog()
		If win.DialogResult.HasValue And win.DialogResult.Value Then
			MessageBox.Show("User Logged In")
		Else
			Me.Close()
		End If
	End Sub
End Class
