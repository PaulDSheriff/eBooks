﻿Public Class winLogin
    Private Sub btnLogin_Click(ByVal sender As Object, ByVal e As RoutedEventArgs) Handles btnLogin.Click
        ' Must set this to get window to close
        DialogResult = True

        ' NOTE: It is not necessary to write any code 
        '       in the Cancel button Click event procedure
    End Sub
End Class
